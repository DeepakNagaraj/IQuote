insert into articles(id, name, category, tags, author) values (1, 'JdbcTemplate Example', 'spring', 'spring,jdbcTemplate', 'Joe');
insert into articles(id, name, category, tags, author) values (2, 'Camel JMS Example', 'camel', 'camel,jms', 'Sam');
insert into articles(id, name, category, tags, author) values (3, 'Camel JDBC Example', 'camel', 'camel,jdbc', 'Joe');