package com.boeing.ai.sqisvelocity.epd.messages;

public class EPDServiceMessage {
	private Queue queue;

    private Epd epd;

    private Shoporder shoporder;

    private Airplane airplane;

    public Queue getQueue ()
    {
        return queue;
    }

    public void setQueue (Queue queue)
    {
        this.queue = queue;
    }

    public Epd getEpd ()
    {
        return epd;
    }

    public void setEpd (Epd epd)
    {
        this.epd = epd;
    }

    public Shoporder getShoporder ()
    {
        return shoporder;
    }

    public void setShoporder (Shoporder shoporder)
    {
        this.shoporder = shoporder;
    }

    public Airplane getAirplane ()
    {
        return airplane;
    }

    public void setAirplane (Airplane airplane)
    {
        this.airplane = airplane;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [queue = "+queue+", epd = "+epd+", shoporder = "+shoporder+", airplane = "+airplane+"]";
    }
}
