package com.boeing.ai.sqisvelocity.epd.messages;

public class Defect
{
    private String featureWhereFound;

    private String waterLineMinMaxLocation;

    private String rootCause;

    private String taskWhereProduced;

    private String whereSupplierCode;

    private String uniqueDefectWhereProduced;

    private String subComponent;

    private String location;

    private String wccWhereProduced;

    private String uniqueDefect3WhereFound;

    private String buttockLineMinMaxLocation;

    private String defectItemId;

    private String positionWhereProduced;

    private String whereSupplierName;

    private String descriptionWhereFound;

    private String component;

    private String ataSubjectCode;

    private String uniqueDefect2WhereProduced;

    private String uniqueDefect2WhereFound;

    private String descriptionWhereProduced;

    private String workLocationWhereProduced;

    private String mesCompanyWhereProduced;

    private String otherLocation;

    private String defectItemQty;

    private String actionTaken;

    private String subLocation;

    private String resolutionGroup;

    private String defectsPerItem;

    private String defectNo;

    private String uniqueDefect3WhereProduced;

    private String stationMinMaxLocation;

    private String supplierRecordType;

    private String shopIdentified;

    private String process;

    private String ataChapterCode;

    private String producedShop;

    private String subProcess;

    private String ataSectionCode;

    private String mbuWhereProduced;

    private String featureWhereProduced;

    private String defectOrderId;

    private String causeGroup;

    private SupplierInfo supplierInfo;

    private String uniqueDefectWhereFound;

    private String accWhereProduced;

    public String getFeatureWhereFound ()
    {
        return featureWhereFound;
    }

    public void setFeatureWhereFound (String featureWhereFound)
    {
        this.featureWhereFound = featureWhereFound;
    }

    public String getWaterLineMinMaxLocation ()
    {
        return waterLineMinMaxLocation;
    }

    public void setWaterLineMinMaxLocation (String waterLineMinMaxLocation)
    {
        this.waterLineMinMaxLocation = waterLineMinMaxLocation;
    }

    public String getRootCause ()
    {
        return rootCause;
    }

    public void setRootCause (String rootCause)
    {
        this.rootCause = rootCause;
    }

    public String getTaskWhereProduced ()
    {
        return taskWhereProduced;
    }

    public void setTaskWhereProduced (String taskWhereProduced)
    {
        this.taskWhereProduced = taskWhereProduced;
    }

    public String getWhereSupplierCode ()
    {
        return whereSupplierCode;
    }

    public void setWhereSupplierCode (String whereSupplierCode)
    {
        this.whereSupplierCode = whereSupplierCode;
    }

    public String getUniqueDefectWhereProduced ()
    {
        return uniqueDefectWhereProduced;
    }

    public void setUniqueDefectWhereProduced (String uniqueDefectWhereProduced)
    {
        this.uniqueDefectWhereProduced = uniqueDefectWhereProduced;
    }

    public String getSubComponent ()
    {
        return subComponent;
    }

    public void setSubComponent (String subComponent)
    {
        this.subComponent = subComponent;
    }

    public String getLocation ()
    {
        return location;
    }

    public void setLocation (String location)
    {
        this.location = location;
    }

    public String getWccWhereProduced ()
    {
        return wccWhereProduced;
    }

    public void setWccWhereProduced (String wccWhereProduced)
    {
        this.wccWhereProduced = wccWhereProduced;
    }

    public String getUniqueDefect3WhereFound ()
    {
        return uniqueDefect3WhereFound;
    }

    public void setUniqueDefect3WhereFound (String uniqueDefect3WhereFound)
    {
        this.uniqueDefect3WhereFound = uniqueDefect3WhereFound;
    }

    public String getButtockLineMinMaxLocation ()
    {
        return buttockLineMinMaxLocation;
    }

    public void setButtockLineMinMaxLocation (String buttockLineMinMaxLocation)
    {
        this.buttockLineMinMaxLocation = buttockLineMinMaxLocation;
    }

    public String getDefectItemId ()
    {
        return defectItemId;
    }

    public void setDefectItemId (String defectItemId)
    {
        this.defectItemId = defectItemId;
    }

    public String getPositionWhereProduced ()
    {
        return positionWhereProduced;
    }

    public void setPositionWhereProduced (String positionWhereProduced)
    {
        this.positionWhereProduced = positionWhereProduced;
    }

    public String getWhereSupplierName ()
    {
        return whereSupplierName;
    }

    public void setWhereSupplierName (String whereSupplierName)
    {
        this.whereSupplierName = whereSupplierName;
    }

    public String getDescriptionWhereFound ()
    {
        return descriptionWhereFound;
    }

    public void setDescriptionWhereFound (String descriptionWhereFound)
    {
        this.descriptionWhereFound = descriptionWhereFound;
    }

    public String getComponent ()
    {
        return component;
    }

    public void setComponent (String component)
    {
        this.component = component;
    }

    public String getAtaSubjectCode ()
    {
        return ataSubjectCode;
    }

    public void setAtaSubjectCode (String ataSubjectCode)
    {
        this.ataSubjectCode = ataSubjectCode;
    }

    public String getUniqueDefect2WhereProduced ()
    {
        return uniqueDefect2WhereProduced;
    }

    public void setUniqueDefect2WhereProduced (String uniqueDefect2WhereProduced)
    {
        this.uniqueDefect2WhereProduced = uniqueDefect2WhereProduced;
    }

    public String getUniqueDefect2WhereFound ()
    {
        return uniqueDefect2WhereFound;
    }

    public void setUniqueDefect2WhereFound (String uniqueDefect2WhereFound)
    {
        this.uniqueDefect2WhereFound = uniqueDefect2WhereFound;
    }

    public String getDescriptionWhereProduced ()
    {
        return descriptionWhereProduced;
    }

    public void setDescriptionWhereProduced (String descriptionWhereProduced)
    {
        this.descriptionWhereProduced = descriptionWhereProduced;
    }

    public String getWorkLocationWhereProduced ()
    {
        return workLocationWhereProduced;
    }

    public void setWorkLocationWhereProduced (String workLocationWhereProduced)
    {
        this.workLocationWhereProduced = workLocationWhereProduced;
    }

    public String getMesCompanyWhereProduced ()
    {
        return mesCompanyWhereProduced;
    }

    public void setMesCompanyWhereProduced (String mesCompanyWhereProduced)
    {
        this.mesCompanyWhereProduced = mesCompanyWhereProduced;
    }

    public String getOtherLocation ()
    {
        return otherLocation;
    }

    public void setOtherLocation (String otherLocation)
    {
        this.otherLocation = otherLocation;
    }

    public String getDefectItemQty ()
    {
        return defectItemQty;
    }

    public void setDefectItemQty (String defectItemQty)
    {
        this.defectItemQty = defectItemQty;
    }

    public String getActionTaken ()
    {
        return actionTaken;
    }

    public void setActionTaken (String actionTaken)
    {
        this.actionTaken = actionTaken;
    }

    public String getSubLocation ()
    {
        return subLocation;
    }

    public void setSubLocation (String subLocation)
    {
        this.subLocation = subLocation;
    }

    public String getResolutionGroup ()
    {
        return resolutionGroup;
    }

    public void setResolutionGroup (String resolutionGroup)
    {
        this.resolutionGroup = resolutionGroup;
    }

    public String getDefectsPerItem ()
    {
        return defectsPerItem;
    }

    public void setDefectsPerItem (String defectsPerItem)
    {
        this.defectsPerItem = defectsPerItem;
    }

    public String getDefectNo ()
    {
        return defectNo;
    }

    public void setDefectNo (String defectNo)
    {
        this.defectNo = defectNo;
    }

    public String getUniqueDefect3WhereProduced ()
    {
        return uniqueDefect3WhereProduced;
    }

    public void setUniqueDefect3WhereProduced (String uniqueDefect3WhereProduced)
    {
        this.uniqueDefect3WhereProduced = uniqueDefect3WhereProduced;
    }

    public String getStationMinMaxLocation ()
    {
        return stationMinMaxLocation;
    }

    public void setStationMinMaxLocation (String stationMinMaxLocation)
    {
        this.stationMinMaxLocation = stationMinMaxLocation;
    }

    public String getSupplierRecordType ()
    {
        return supplierRecordType;
    }

    public void setSupplierRecordType (String supplierRecordType)
    {
        this.supplierRecordType = supplierRecordType;
    }

    public String getShopIdentified ()
    {
        return shopIdentified;
    }

    public void setShopIdentified (String shopIdentified)
    {
        this.shopIdentified = shopIdentified;
    }

    public String getProcess ()
    {
        return process;
    }

    public void setProcess (String process)
    {
        this.process = process;
    }

    public String getAtaChapterCode ()
    {
        return ataChapterCode;
    }

    public void setAtaChapterCode (String ataChapterCode)
    {
        this.ataChapterCode = ataChapterCode;
    }

    public String getProducedShop ()
    {
        return producedShop;
    }

    public void setProducedShop (String producedShop)
    {
        this.producedShop = producedShop;
    }

    public String getSubProcess ()
    {
        return subProcess;
    }

    public void setSubProcess (String subProcess)
    {
        this.subProcess = subProcess;
    }

    public String getAtaSectionCode ()
    {
        return ataSectionCode;
    }

    public void setAtaSectionCode (String ataSectionCode)
    {
        this.ataSectionCode = ataSectionCode;
    }

    public String getMbuWhereProduced ()
    {
        return mbuWhereProduced;
    }

    public void setMbuWhereProduced (String mbuWhereProduced)
    {
        this.mbuWhereProduced = mbuWhereProduced;
    }

    public String getFeatureWhereProduced ()
    {
        return featureWhereProduced;
    }

    public void setFeatureWhereProduced (String featureWhereProduced)
    {
        this.featureWhereProduced = featureWhereProduced;
    }

    public String getDefectOrderId ()
    {
        return defectOrderId;
    }

    public void setDefectOrderId (String defectOrderId)
    {
        this.defectOrderId = defectOrderId;
    }

    public String getCauseGroup ()
    {
        return causeGroup;
    }

    public void setCauseGroup (String causeGroup)
    {
        this.causeGroup = causeGroup;
    }

    public SupplierInfo getSupplierInfo ()
    {
        return supplierInfo;
    }

    public void setSupplierInfo (SupplierInfo supplierInfo)
    {
        this.supplierInfo = supplierInfo;
    }

    public String getUniqueDefectWhereFound ()
    {
        return uniqueDefectWhereFound;
    }

    public void setUniqueDefectWhereFound (String uniqueDefectWhereFound)
    {
        this.uniqueDefectWhereFound = uniqueDefectWhereFound;
    }

    public String getAccWhereProduced ()
    {
        return accWhereProduced;
    }

    public void setAccWhereProduced (String accWhereProduced)
    {
        this.accWhereProduced = accWhereProduced;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [featureWhereFound = "+featureWhereFound+", waterLineMinMaxLocation = "+waterLineMinMaxLocation+", rootCause = "+rootCause+", taskWhereProduced = "+taskWhereProduced+", whereSupplierCode = "+whereSupplierCode+", uniqueDefectWhereProduced = "+uniqueDefectWhereProduced+", subComponent = "+subComponent+", location = "+location+", wccWhereProduced = "+wccWhereProduced+", uniqueDefect3WhereFound = "+uniqueDefect3WhereFound+", buttockLineMinMaxLocation = "+buttockLineMinMaxLocation+", defectItemId = "+defectItemId+", positionWhereProduced = "+positionWhereProduced+", whereSupplierName = "+whereSupplierName+", descriptionWhereFound = "+descriptionWhereFound+", component = "+component+", ataSubjectCode = "+ataSubjectCode+", uniqueDefect2WhereProduced = "+uniqueDefect2WhereProduced+", uniqueDefect2WhereFound = "+uniqueDefect2WhereFound+", descriptionWhereProduced = "+descriptionWhereProduced+", workLocationWhereProduced = "+workLocationWhereProduced+", mesCompanyWhereProduced = "+mesCompanyWhereProduced+", otherLocation = "+otherLocation+", defectItemQty = "+defectItemQty+", actionTaken = "+actionTaken+", subLocation = "+subLocation+", resolutionGroup = "+resolutionGroup+", defectsPerItem = "+defectsPerItem+", defectNo = "+defectNo+", uniqueDefect3WhereProduced = "+uniqueDefect3WhereProduced+", stationMinMaxLocation = "+stationMinMaxLocation+", supplierRecordType = "+supplierRecordType+", shopIdentified = "+shopIdentified+", process = "+process+", ataChapterCode = "+ataChapterCode+", producedShop = "+producedShop+", subProcess = "+subProcess+", ataSectionCode = "+ataSectionCode+", mbuWhereProduced = "+mbuWhereProduced+", featureWhereProduced = "+featureWhereProduced+", defectOrderId = "+defectOrderId+", causeGroup = "+causeGroup+", supplierInfo = "+supplierInfo+", uniqueDefectWhereFound = "+uniqueDefectWhereFound+", accWhereProduced = "+accWhereProduced+"]";
    }
}
