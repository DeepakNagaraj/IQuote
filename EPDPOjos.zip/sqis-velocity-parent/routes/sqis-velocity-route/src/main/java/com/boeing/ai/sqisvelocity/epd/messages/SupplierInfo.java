package com.boeing.ai.sqisvelocity.epd.messages;

public class SupplierInfo
{
    private String contractDate;

    private String purchaseContractNo;

    private String fob;

    private String receiptNo;

    private String supplierInformationText;

    private String supplierOriginationDate;

    private String authorizeToShip;

    public String getContractDate ()
    {
        return contractDate;
    }

    public void setContractDate (String contractDate)
    {
        this.contractDate = contractDate;
    }

    public String getPurchaseContractNo ()
    {
        return purchaseContractNo;
    }

    public void setPurchaseContractNo (String purchaseContractNo)
    {
        this.purchaseContractNo = purchaseContractNo;
    }

    public String getFob ()
    {
        return fob;
    }

    public void setFob (String fob)
    {
        this.fob = fob;
    }

    public String getReceiptNo ()
    {
        return receiptNo;
    }

    public void setReceiptNo (String receiptNo)
    {
        this.receiptNo = receiptNo;
    }

    public String getSupplierInformationText ()
    {
        return supplierInformationText;
    }

    public void setSupplierInformationText (String supplierInformationText)
    {
        this.supplierInformationText = supplierInformationText;
    }

    public String getSupplierOriginationDate ()
    {
        return supplierOriginationDate;
    }

    public void setSupplierOriginationDate (String supplierOriginationDate)
    {
        this.supplierOriginationDate = supplierOriginationDate;
    }

    public String getAuthorizeToShip ()
    {
        return authorizeToShip;
    }

    public void setAuthorizeToShip (String authorizeToShip)
    {
        this.authorizeToShip = authorizeToShip;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [contractDate = "+contractDate+", purchaseContractNo = "+purchaseContractNo+", fob = "+fob+", receiptNo = "+receiptNo+", supplierInformationText = "+supplierInformationText+", supplierOriginationDate = "+supplierOriginationDate+", authorizeToShip = "+authorizeToShip+"]";
    }
}