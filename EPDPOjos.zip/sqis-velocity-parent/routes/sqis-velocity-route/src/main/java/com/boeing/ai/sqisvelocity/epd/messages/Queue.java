package com.boeing.ai.sqisvelocity.epd.messages;

public class Queue
{
    private String subAreaQueue;

    private String mesCompanyQueue;

    private String areaQueue;

    public String getSubAreaQueue ()
    {
        return subAreaQueue;
    }

    public void setSubAreaQueue (String subAreaQueue)
    {
        this.subAreaQueue = subAreaQueue;
    }

    public String getMesCompanyQueue ()
    {
        return mesCompanyQueue;
    }

    public void setMesCompanyQueue (String mesCompanyQueue)
    {
        this.mesCompanyQueue = mesCompanyQueue;
    }

    public String getAreaQueue ()
    {
        return areaQueue;
    }

    public void setAreaQueue (String areaQueue)
    {
        this.areaQueue = areaQueue;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [subAreaQueue = "+subAreaQueue+", mesCompanyQueue = "+mesCompanyQueue+", areaQueue = "+areaQueue+"]";
    }
}
			