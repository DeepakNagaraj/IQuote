package com.boeing.ai.sqisvelocity.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class HeaderConstructor implements Processor{

	@Override
	public void process(Exchange exchange) throws Exception {
		
		Date date = new Date();
		SimpleDateFormat form = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
		String timestamp = form.format(date);
		// TODO Auto-generated method stub
		exchange.getIn().setHeader("ch-service", "ch-generateToken");
		exchange.getIn().setHeader("ch-timestamp", timestamp);
		exchange.getIn().setHeader("ch-datasensitivity", "EAR");
		exchange.getIn().setHeader("ch-action", "POST /api/v1/mesusers/authenticate");
		exchange.getIn().setHeader("ch-globaltransactionid", UUID.randomUUID());

	}
	
	
}
