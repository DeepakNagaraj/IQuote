package com.boeing.ai.sqisvelocity.epd.messages;

public class AttachmentList
{
    private String attachmentURL;

    private String attachmentITAR;

    private String attachmentCRC;

    private String attachmentMime;

    private String attachmentEncoding;

    private String attachmentObject;

    private String isShared;

    private String[] attachmentECCN;

    private String attachmentID;

    private String attachmentName;

    private String attachmentType;

    private String attachmentSize;

    public String getAttachmentURL ()
    {
        return attachmentURL;
    }

    public void setAttachmentURL (String attachmentURL)
    {
        this.attachmentURL = attachmentURL;
    }

    public String getAttachmentITAR ()
    {
        return attachmentITAR;
    }

    public void setAttachmentITAR (String attachmentITAR)
    {
        this.attachmentITAR = attachmentITAR;
    }

    public String getAttachmentCRC ()
    {
        return attachmentCRC;
    }

    public void setAttachmentCRC (String attachmentCRC)
    {
        this.attachmentCRC = attachmentCRC;
    }

    public String getAttachmentMime ()
    {
        return attachmentMime;
    }

    public void setAttachmentMime (String attachmentMime)
    {
        this.attachmentMime = attachmentMime;
    }

    public String getAttachmentEncoding ()
    {
        return attachmentEncoding;
    }

    public void setAttachmentEncoding (String attachmentEncoding)
    {
        this.attachmentEncoding = attachmentEncoding;
    }

    public String getAttachmentObject ()
    {
        return attachmentObject;
    }

    public void setAttachmentObject (String attachmentObject)
    {
        this.attachmentObject = attachmentObject;
    }

    public String getIsShared ()
    {
        return isShared;
    }

    public void setIsShared (String isShared)
    {
        this.isShared = isShared;
    }

    public String[] getAttachmentECCN ()
    {
        return attachmentECCN;
    }

    public void setAttachmentECCN (String[] attachmentECCN)
    {
        this.attachmentECCN = attachmentECCN;
    }

    public String getAttachmentID ()
    {
        return attachmentID;
    }

    public void setAttachmentID (String attachmentID)
    {
        this.attachmentID = attachmentID;
    }

    public String getAttachmentName ()
    {
        return attachmentName;
    }

    public void setAttachmentName (String attachmentName)
    {
        this.attachmentName = attachmentName;
    }

    public String getAttachmentType ()
    {
        return attachmentType;
    }

    public void setAttachmentType (String attachmentType)
    {
        this.attachmentType = attachmentType;
    }

    public String getAttachmentSize ()
    {
        return attachmentSize;
    }

    public void setAttachmentSize (String attachmentSize)
    {
        this.attachmentSize = attachmentSize;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [attachmentURL = "+attachmentURL+", attachmentITAR = "+attachmentITAR+", attachmentCRC = "+attachmentCRC+", attachmentMime = "+attachmentMime+", attachmentEncoding = "+attachmentEncoding+", attachmentObject = "+attachmentObject+", isShared = "+isShared+", attachmentECCN = "+attachmentECCN+", attachmentID = "+attachmentID+", attachmentName = "+attachmentName+", attachmentType = "+attachmentType+", attachmentSize = "+attachmentSize+"]";
    }
}