package com.boeing.ai.sqisvelocity.epd.messages;

public class Airplane
{
    private String model;

    private String aircraftIdentificationNo;

    public String getModel ()
    {
        return model;
    }

    public void setModel (String model)
    {
        this.model = model;
    }

    public String getAircraftIdentificationNo ()
    {
        return aircraftIdentificationNo;
    }

    public void setAircraftIdentificationNo (String aircraftIdentificationNo)
    {
        this.aircraftIdentificationNo = aircraftIdentificationNo;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [model = "+model+", aircraftIdentificationNo = "+aircraftIdentificationNo+"]";
    }
}
			
			