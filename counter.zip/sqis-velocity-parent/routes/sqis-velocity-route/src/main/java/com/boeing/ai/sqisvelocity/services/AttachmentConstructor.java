package com.boeing.ai.sqisvelocity.services;

import java.io.File;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;

public class AttachmentConstructor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		Message in = exchange.getIn();		
		File file = new File("src/data/Payload.json");
		System.out.println("File Name "+file.getName());
		System.out.println("File length "+file.length());
		/*DataHandler dh = new DataHandler(new FileDataSource(file));
		in.addAttachment("", dh);*/
		exchange.getIn().setBody(file);
	}

}
