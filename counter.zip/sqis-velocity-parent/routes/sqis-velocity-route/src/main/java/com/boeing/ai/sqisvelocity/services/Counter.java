package com.boeing.ai.sqisvelocity.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class Counter implements Processor{

	@Override
	public void process(Exchange exchg) throws Exception {
		//TBD based on some condition decrement the values
		
		String countstr = (String) exchg.getIn().getHeader("counter");
		int count =Integer.parseInt(countstr);
		count=--count;
		System.out.println("counter bean "+count);
		exchg.getIn().setHeader("counter", count);
	}

}
