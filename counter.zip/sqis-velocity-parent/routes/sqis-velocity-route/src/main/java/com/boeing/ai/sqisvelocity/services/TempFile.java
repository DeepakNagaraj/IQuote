package com.boeing.ai.sqisvelocity.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class TempFile {
	 private File tempFile;
	    private String originalFilename;


	    public TempFile(InputStream in, String originalFilename) throws IOException {
	        this.originalFilename = originalFilename;
	        this.init(in);

	    }

	    private void init(InputStream in) throws IOException {

	        tempFile = File.createTempFile("tempFile", ".tmp");
	        tempFile.deleteOnExit();

	        FileOutputStream fout = null;

	        try {

	            fout = new FileOutputStream(tempFile);
	            int c;

	            while ((c = in.read()) != -1) {
	                fout.write(c);
	            }

	        }finally {
	            if (in != null) {
	                in.close();
	            }
	            if (fout != null) {
	                fout.close();
	            }
	        }
	    }

	    public File getTempFile() {
	        return tempFile;
	    }

	    public String getOriginalFilename() {
	        return originalFilename;
	    }
}
