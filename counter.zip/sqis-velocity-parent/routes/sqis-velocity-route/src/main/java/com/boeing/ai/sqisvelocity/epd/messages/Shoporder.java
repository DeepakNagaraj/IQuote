package com.boeing.ai.sqisvelocity.epd.messages;

public class Shoporder
{
    private String lineNumber;

    private String shopOrderIdentifier;

    private String currentAssignedWorkCenter;

    public String getLineNumber ()
    {
        return lineNumber;
    }

    public void setLineNumber (String lineNumber)
    {
        this.lineNumber = lineNumber;
    }

    public String getShopOrderIdentifier ()
    {
        return shopOrderIdentifier;
    }

    public void setShopOrderIdentifier (String shopOrderIdentifier)
    {
        this.shopOrderIdentifier = shopOrderIdentifier;
    }

    public String getCurrentAssignedWorkCenter ()
    {
        return currentAssignedWorkCenter;
    }

    public void setCurrentAssignedWorkCenter (String currentAssignedWorkCenter)
    {
        this.currentAssignedWorkCenter = currentAssignedWorkCenter;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [lineNumber = "+lineNumber+", shopOrderIdentifier = "+shopOrderIdentifier+", currentAssignedWorkCenter = "+currentAssignedWorkCenter+"]";
    }
}
		