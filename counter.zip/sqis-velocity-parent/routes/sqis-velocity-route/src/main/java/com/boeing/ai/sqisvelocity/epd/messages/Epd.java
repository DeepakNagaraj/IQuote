package com.boeing.ai.sqisvelocity.epd.messages;

public class Epd
{
    private String shortItemIdSerialId;

    private String boeingPOPosition;

    private String itemID;

    private String msdsProductWeightUnit;

    private String foundShop;

    private Defect[] defect;

    private String recordSubRecordType;

    private String supplierInitiationDate;

    private String operStep;

    private String shipDate;

    private String pos;

    private String supplierDisposition;

    private String incompleteEngChanges;

    private String physicalItemLocation;

    private String shortItemShipDate;

    private String supplierContactEmail;

    private String[] eccn;

    private String shipToOtherSupplier;

    private String incompleteOperations;

    private String estAdditionalFlowTime;

    private String recordOfCollaborativeAgreement;

    private String boeingMSDSN;

    private String exportControl;

    private String serialID;

    private String faaConformity;

    private String previousConformedPart;

    private String uniqueID;

    private AttachmentList[] attachmentList;

    private String shippedToSupplierCode;

    private String wcc;

    private String removedFromLineNo;

    private String installationHardwareProvidedQty;

    private String multipleItemsOpenSS;

    private String newOnDockDate;

    private String installationLoosePartsReqdQty;

    private String shipToBoeing;

    private String supplierContactPhone;

    private String qtyShort;

    private String incompleteFunctionalTest;

    private String pmiCodeName;

    private String workLoc;

    private String effectOnTraffic;

    private String mesCompany;

    private String apDescription;

    private String installationHardwareProvided;

    private String validationRequired;

    private String jobQty;

    private String installationLoosePartsReqd;

    private String supplierRecommendation;

    private String coordinateSystem;

    private String msdsProuctWeight;

    private String task;

    private String supplierContact;

    private String supplierCorrectiveAction;

    private String boeingPO;

    private String partneredManagedInventory;

    private String erpCompany;

    private String productionRepair;

    private String shortItemId;

    private String acc;

    private String shipDateIfComplete;

    private String discrepancyText;

    private String itemDescription;

    private String usedOnItemId;

    private String supplierRecordID;

    private String timeDaysGained;

    private String[] supplierAccessValue;

    private String relOrder;

    private String discrepantQty;

    public String getShortItemIdSerialId ()
    {
        return shortItemIdSerialId;
    }

    public void setShortItemIdSerialId (String shortItemIdSerialId)
    {
        this.shortItemIdSerialId = shortItemIdSerialId;
    }

    public String getBoeingPOPosition ()
    {
        return boeingPOPosition;
    }

    public void setBoeingPOPosition (String boeingPOPosition)
    {
        this.boeingPOPosition = boeingPOPosition;
    }

    public String getItemID ()
    {
        return itemID;
    }

    public void setItemID (String itemID)
    {
        this.itemID = itemID;
    }

    public String getMsdsProductWeightUnit ()
    {
        return msdsProductWeightUnit;
    }

    public void setMsdsProductWeightUnit (String msdsProductWeightUnit)
    {
        this.msdsProductWeightUnit = msdsProductWeightUnit;
    }

    public String getFoundShop ()
    {
        return foundShop;
    }

    public void setFoundShop (String foundShop)
    {
        this.foundShop = foundShop;
    }

    public Defect[] getDefect ()
    {
        return defect;
    }

    public void setDefect (Defect[] defect)
    {
        this.defect = defect;
    }

    public String getRecordSubRecordType ()
    {
        return recordSubRecordType;
    }

    public void setRecordSubRecordType (String recordSubRecordType)
    {
        this.recordSubRecordType = recordSubRecordType;
    }

    public String getSupplierInitiationDate ()
    {
        return supplierInitiationDate;
    }

    public void setSupplierInitiationDate (String supplierInitiationDate)
    {
        this.supplierInitiationDate = supplierInitiationDate;
    }

    public String getOperStep ()
    {
        return operStep;
    }

    public void setOperStep (String operStep)
    {
        this.operStep = operStep;
    }

    public String getShipDate ()
    {
        return shipDate;
    }

    public void setShipDate (String shipDate)
    {
        this.shipDate = shipDate;
    }

    public String getPos ()
    {
        return pos;
    }

    public void setPos (String pos)
    {
        this.pos = pos;
    }

    public String getSupplierDisposition ()
    {
        return supplierDisposition;
    }

    public void setSupplierDisposition (String supplierDisposition)
    {
        this.supplierDisposition = supplierDisposition;
    }

    public String getIncompleteEngChanges ()
    {
        return incompleteEngChanges;
    }

    public void setIncompleteEngChanges (String incompleteEngChanges)
    {
        this.incompleteEngChanges = incompleteEngChanges;
    }

    public String getPhysicalItemLocation ()
    {
        return physicalItemLocation;
    }

    public void setPhysicalItemLocation (String physicalItemLocation)
    {
        this.physicalItemLocation = physicalItemLocation;
    }

    public String getShortItemShipDate ()
    {
        return shortItemShipDate;
    }

    public void setShortItemShipDate (String shortItemShipDate)
    {
        this.shortItemShipDate = shortItemShipDate;
    }

    public String getSupplierContactEmail ()
    {
        return supplierContactEmail;
    }

    public void setSupplierContactEmail (String supplierContactEmail)
    {
        this.supplierContactEmail = supplierContactEmail;
    }

    public String[] getEccn ()
    {
        return eccn;
    }

    public void setEccn (String[] eccn)
    {
        this.eccn = eccn;
    }

    public String getShipToOtherSupplier ()
    {
        return shipToOtherSupplier;
    }

    public void setShipToOtherSupplier (String shipToOtherSupplier)
    {
        this.shipToOtherSupplier = shipToOtherSupplier;
    }

    public String getIncompleteOperations ()
    {
        return incompleteOperations;
    }

    public void setIncompleteOperations (String incompleteOperations)
    {
        this.incompleteOperations = incompleteOperations;
    }

    public String getEstAdditionalFlowTime ()
    {
        return estAdditionalFlowTime;
    }

    public void setEstAdditionalFlowTime (String estAdditionalFlowTime)
    {
        this.estAdditionalFlowTime = estAdditionalFlowTime;
    }

    public String getRecordOfCollaborativeAgreement ()
    {
        return recordOfCollaborativeAgreement;
    }

    public void setRecordOfCollaborativeAgreement (String recordOfCollaborativeAgreement)
    {
        this.recordOfCollaborativeAgreement = recordOfCollaborativeAgreement;
    }

    public String getBoeingMSDSN ()
    {
        return boeingMSDSN;
    }

    public void setBoeingMSDSN (String boeingMSDSN)
    {
        this.boeingMSDSN = boeingMSDSN;
    }

    public String getExportControl ()
    {
        return exportControl;
    }

    public void setExportControl (String exportControl)
    {
        this.exportControl = exportControl;
    }

    public String getSerialID ()
    {
        return serialID;
    }

    public void setSerialID (String serialID)
    {
        this.serialID = serialID;
    }

    public String getFaaConformity ()
    {
        return faaConformity;
    }

    public void setFaaConformity (String faaConformity)
    {
        this.faaConformity = faaConformity;
    }

    public String getPreviousConformedPart ()
    {
        return previousConformedPart;
    }

    public void setPreviousConformedPart (String previousConformedPart)
    {
        this.previousConformedPart = previousConformedPart;
    }

    public String getUniqueID ()
    {
        return uniqueID;
    }

    public void setUniqueID (String uniqueID)
    {
        this.uniqueID = uniqueID;
    }

    public AttachmentList[] getAttachmentList ()
    {
        return attachmentList;
    }

    public void setAttachmentList (AttachmentList[] attachmentList)
    {
        this.attachmentList = attachmentList;
    }

    public String getShippedToSupplierCode ()
    {
        return shippedToSupplierCode;
    }

    public void setShippedToSupplierCode (String shippedToSupplierCode)
    {
        this.shippedToSupplierCode = shippedToSupplierCode;
    }

    public String getWcc ()
    {
        return wcc;
    }

    public void setWcc (String wcc)
    {
        this.wcc = wcc;
    }

    public String getRemovedFromLineNo ()
    {
        return removedFromLineNo;
    }

    public void setRemovedFromLineNo (String removedFromLineNo)
    {
        this.removedFromLineNo = removedFromLineNo;
    }

    public String getInstallationHardwareProvidedQty ()
    {
        return installationHardwareProvidedQty;
    }

    public void setInstallationHardwareProvidedQty (String installationHardwareProvidedQty)
    {
        this.installationHardwareProvidedQty = installationHardwareProvidedQty;
    }

    public String getMultipleItemsOpenSS ()
    {
        return multipleItemsOpenSS;
    }

    public void setMultipleItemsOpenSS (String multipleItemsOpenSS)
    {
        this.multipleItemsOpenSS = multipleItemsOpenSS;
    }

    public String getNewOnDockDate ()
    {
        return newOnDockDate;
    }

    public void setNewOnDockDate (String newOnDockDate)
    {
        this.newOnDockDate = newOnDockDate;
    }

    public String getInstallationLoosePartsReqdQty ()
    {
        return installationLoosePartsReqdQty;
    }

    public void setInstallationLoosePartsReqdQty (String installationLoosePartsReqdQty)
    {
        this.installationLoosePartsReqdQty = installationLoosePartsReqdQty;
    }

    public String getShipToBoeing ()
    {
        return shipToBoeing;
    }

    public void setShipToBoeing (String shipToBoeing)
    {
        this.shipToBoeing = shipToBoeing;
    }

    public String getSupplierContactPhone ()
    {
        return supplierContactPhone;
    }

    public void setSupplierContactPhone (String supplierContactPhone)
    {
        this.supplierContactPhone = supplierContactPhone;
    }

    public String getQtyShort ()
    {
        return qtyShort;
    }

    public void setQtyShort (String qtyShort)
    {
        this.qtyShort = qtyShort;
    }

    public String getIncompleteFunctionalTest ()
    {
        return incompleteFunctionalTest;
    }

    public void setIncompleteFunctionalTest (String incompleteFunctionalTest)
    {
        this.incompleteFunctionalTest = incompleteFunctionalTest;
    }

    public String getPmiCodeName ()
    {
        return pmiCodeName;
    }

    public void setPmiCodeName (String pmiCodeName)
    {
        this.pmiCodeName = pmiCodeName;
    }

    public String getWorkLoc ()
    {
        return workLoc;
    }

    public void setWorkLoc (String workLoc)
    {
        this.workLoc = workLoc;
    }

    public String getEffectOnTraffic ()
    {
        return effectOnTraffic;
    }

    public void setEffectOnTraffic (String effectOnTraffic)
    {
        this.effectOnTraffic = effectOnTraffic;
    }

    public String getMesCompany ()
    {
        return mesCompany;
    }

    public void setMesCompany (String mesCompany)
    {
        this.mesCompany = mesCompany;
    }

    public String getApDescription ()
    {
        return apDescription;
    }

    public void setApDescription (String apDescription)
    {
        this.apDescription = apDescription;
    }

    public String getInstallationHardwareProvided ()
    {
        return installationHardwareProvided;
    }

    public void setInstallationHardwareProvided (String installationHardwareProvided)
    {
        this.installationHardwareProvided = installationHardwareProvided;
    }

    public String getValidationRequired ()
    {
        return validationRequired;
    }

    public void setValidationRequired (String validationRequired)
    {
        this.validationRequired = validationRequired;
    }

    public String getJobQty ()
    {
        return jobQty;
    }

    public void setJobQty (String jobQty)
    {
        this.jobQty = jobQty;
    }

    public String getInstallationLoosePartsReqd ()
    {
        return installationLoosePartsReqd;
    }

    public void setInstallationLoosePartsReqd (String installationLoosePartsReqd)
    {
        this.installationLoosePartsReqd = installationLoosePartsReqd;
    }

    public String getSupplierRecommendation ()
    {
        return supplierRecommendation;
    }

    public void setSupplierRecommendation (String supplierRecommendation)
    {
        this.supplierRecommendation = supplierRecommendation;
    }

    public String getCoordinateSystem ()
    {
        return coordinateSystem;
    }

    public void setCoordinateSystem (String coordinateSystem)
    {
        this.coordinateSystem = coordinateSystem;
    }

    public String getMsdsProuctWeight ()
    {
        return msdsProuctWeight;
    }

    public void setMsdsProuctWeight (String msdsProuctWeight)
    {
        this.msdsProuctWeight = msdsProuctWeight;
    }

    public String getTask ()
    {
        return task;
    }

    public void setTask (String task)
    {
        this.task = task;
    }

    public String getSupplierContact ()
    {
        return supplierContact;
    }

    public void setSupplierContact (String supplierContact)
    {
        this.supplierContact = supplierContact;
    }

    public String getSupplierCorrectiveAction ()
    {
        return supplierCorrectiveAction;
    }

    public void setSupplierCorrectiveAction (String supplierCorrectiveAction)
    {
        this.supplierCorrectiveAction = supplierCorrectiveAction;
    }

    public String getBoeingPO ()
    {
        return boeingPO;
    }

    public void setBoeingPO (String boeingPO)
    {
        this.boeingPO = boeingPO;
    }

    public String getPartneredManagedInventory ()
    {
        return partneredManagedInventory;
    }

    public void setPartneredManagedInventory (String partneredManagedInventory)
    {
        this.partneredManagedInventory = partneredManagedInventory;
    }

    public String getErpCompany ()
    {
        return erpCompany;
    }

    public void setErpCompany (String erpCompany)
    {
        this.erpCompany = erpCompany;
    }

    public String getProductionRepair ()
    {
        return productionRepair;
    }

    public void setProductionRepair (String productionRepair)
    {
        this.productionRepair = productionRepair;
    }

    public String getShortItemId ()
    {
        return shortItemId;
    }

    public void setShortItemId (String shortItemId)
    {
        this.shortItemId = shortItemId;
    }

    public String getAcc ()
    {
        return acc;
    }

    public void setAcc (String acc)
    {
        this.acc = acc;
    }

    public String getShipDateIfComplete ()
    {
        return shipDateIfComplete;
    }

    public void setShipDateIfComplete (String shipDateIfComplete)
    {
        this.shipDateIfComplete = shipDateIfComplete;
    }

    public String getDiscrepancyText ()
    {
        return discrepancyText;
    }

    public void setDiscrepancyText (String discrepancyText)
    {
        this.discrepancyText = discrepancyText;
    }

    public String getItemDescription ()
    {
        return itemDescription;
    }

    public void setItemDescription (String itemDescription)
    {
        this.itemDescription = itemDescription;
    }

    public String getUsedOnItemId ()
    {
        return usedOnItemId;
    }

    public void setUsedOnItemId (String usedOnItemId)
    {
        this.usedOnItemId = usedOnItemId;
    }

    public String getSupplierRecordID ()
    {
        return supplierRecordID;
    }

    public void setSupplierRecordID (String supplierRecordID)
    {
        this.supplierRecordID = supplierRecordID;
    }

    public String getTimeDaysGained ()
    {
        return timeDaysGained;
    }

    public void setTimeDaysGained (String timeDaysGained)
    {
        this.timeDaysGained = timeDaysGained;
    }

    public String[] getSupplierAccessValue ()
    {
        return supplierAccessValue;
    }

    public void setSupplierAccessValue (String[] supplierAccessValue)
    {
        this.supplierAccessValue = supplierAccessValue;
    }

    public String getRelOrder ()
    {
        return relOrder;
    }

    public void setRelOrder (String relOrder)
    {
        this.relOrder = relOrder;
    }

    public String getDiscrepantQty ()
    {
        return discrepantQty;
    }

    public void setDiscrepantQty (String discrepantQty)
    {
        this.discrepantQty = discrepantQty;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [shortItemIdSerialId = "+shortItemIdSerialId+", boeingPOPosition = "+boeingPOPosition+", itemID = "+itemID+", msdsProductWeightUnit = "+msdsProductWeightUnit+", foundShop = "+foundShop+", defect = "+defect+", recordSubRecordType = "+recordSubRecordType+", supplierInitiationDate = "+supplierInitiationDate+", operStep = "+operStep+", shipDate = "+shipDate+", pos = "+pos+", supplierDisposition = "+supplierDisposition+", incompleteEngChanges = "+incompleteEngChanges+", physicalItemLocation = "+physicalItemLocation+", shortItemShipDate = "+shortItemShipDate+", supplierContactEmail = "+supplierContactEmail+", eccn = "+eccn+", shipToOtherSupplier = "+shipToOtherSupplier+", incompleteOperations = "+incompleteOperations+", estAdditionalFlowTime = "+estAdditionalFlowTime+", recordOfCollaborativeAgreement = "+recordOfCollaborativeAgreement+", boeingMSDSN = "+boeingMSDSN+", exportControl = "+exportControl+", serialID = "+serialID+", faaConformity = "+faaConformity+", previousConformedPart = "+previousConformedPart+", uniqueID = "+uniqueID+", attachmentList = "+attachmentList+", shippedToSupplierCode = "+shippedToSupplierCode+", wcc = "+wcc+", removedFromLineNo = "+removedFromLineNo+", installationHardwareProvidedQty = "+installationHardwareProvidedQty+", multipleItemsOpenSS = "+multipleItemsOpenSS+", newOnDockDate = "+newOnDockDate+", installationLoosePartsReqdQty = "+installationLoosePartsReqdQty+", shipToBoeing = "+shipToBoeing+", supplierContactPhone = "+supplierContactPhone+", qtyShort = "+qtyShort+", incompleteFunctionalTest = "+incompleteFunctionalTest+", pmiCodeName = "+pmiCodeName+", workLoc = "+workLoc+", effectOnTraffic = "+effectOnTraffic+", mesCompany = "+mesCompany+", apDescription = "+apDescription+", installationHardwareProvided = "+installationHardwareProvided+", validationRequired = "+validationRequired+", jobQty = "+jobQty+", installationLoosePartsReqd = "+installationLoosePartsReqd+", supplierRecommendation = "+supplierRecommendation+", coordinateSystem = "+coordinateSystem+", msdsProuctWeight = "+msdsProuctWeight+", task = "+task+", supplierContact = "+supplierContact+", supplierCorrectiveAction = "+supplierCorrectiveAction+", boeingPO = "+boeingPO+", partneredManagedInventory = "+partneredManagedInventory+", erpCompany = "+erpCompany+", productionRepair = "+productionRepair+", shortItemId = "+shortItemId+", acc = "+acc+", shipDateIfComplete = "+shipDateIfComplete+", discrepancyText = "+discrepancyText+", itemDescription = "+itemDescription+", usedOnItemId = "+usedOnItemId+", supplierRecordID = "+supplierRecordID+", timeDaysGained = "+timeDaysGained+", supplierAccessValue = "+supplierAccessValue+", relOrder = "+relOrder+", discrepantQty = "+discrepantQty+"]";
    }
}