/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : BaseEvent.java - BaseEvent Class exposed in CEERS API
 *                                 Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.eventmanager;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.components.ceers.CeersUtils;
import com.boeing.ai.common.components.ceers.eventmanager.DataSensitivityType;
import com.boeing.ai.common.utilities.ClassInfo;

import java.net.InetAddress;

import java.util.GregorianCalendar;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
/*---------------------------------------------------------------------------*/
public class BaseEvent {
    private String _eventID;
    private String _globalTransactionID;
    private String _eventGroupName;
    private String _applicationName;
    private String _componentName;
    private XMLGregorianCalendar _timeStamp;
    private String _serverName;
    private String _environmentName;
    private String _metadata;
    private String _userdata;
    private String _messageName;
    private DataSensitivityType _dataSensitivity = DataSensitivityType.NONE;
    private boolean _ignoreEventErrors;
    private boolean _disableLogging;
    private String _alternateLogFilePath;

    // Initializer - all events need a name.
    public BaseEvent(String messageName) throws Exception {
        String parentClassName = ClassInfo.getCallerCallerClassName();
        this.setEventID("");
        this.setGlobalTransactionID("");
        this.setEventGroupName("NotSpecified");
        this.setApplicationName("");
        this.setComponentName("");
        this.setTimeStamp((GregorianCalendar)GregorianCalendar.getInstance());
        this.setServerName(InetAddress.getLocalHost().getHostName());
        this.setMetaData("");
        this.setUserData("");
        this.setMessageName(messageName);
        this.setDataSensitivity(DataSensitivityType.RESTRICT);
        this.setIgnoreEventErrors(true);
        this.setDisableLogging(false);
        this.setAlternateLogFilePath("");
    }

    public String getEventID() throws Exception {
        return this._eventID;
    }
    @XmlElement
    public void setEventID(String value) throws Exception {
        this._eventID= value;
    }

    public String getGlobalTransactionID() throws Exception {
        return this._globalTransactionID;
    }
    @XmlElement
    public void setGlobalTransactionID(String value) throws Exception {
        this._globalTransactionID = value;
    }

    public String getEventGroupName() throws Exception {
        return this._eventGroupName;
    }
    @XmlElement
    public void setEventGroupName(String value) throws Exception {
        this._eventGroupName = value;
    }

    public String getApplicationName() throws Exception {
        return this._applicationName;
    }
    @XmlElement
    public void setApplicationName(String value) throws Exception {
        this._applicationName = value;
    }

    public String getMessageName() throws Exception {
        return this._messageName;
    }
    @XmlElement
    public void setMessageName(String value) throws Exception {
        this._messageName = value;
    }

    public String getComponentName() throws Exception {
        return this._componentName;
    }
    @XmlElement
    public void setComponentName(String value) throws Exception {
        this._componentName = value;
    }

    public XMLGregorianCalendar getTimeStamp() throws Exception {
        return this._timeStamp;
    }
    @XmlElement
    public void setTimeStamp(String value) throws Exception {
        XMLGregorianCalendar xgc=DatatypeFactory.newInstance().newXMLGregorianCalendar(value);
        this.setTimeStamp(xgc);
    }
    public void setTimeStamp(GregorianCalendar value) throws Exception {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        XMLGregorianCalendar xmlCal = dtf.newXMLGregorianCalendar(value);
        this._timeStamp = xmlCal;
    }
    public void setTimeStamp(XMLGregorianCalendar value) throws Exception {
        this._timeStamp = value;
    }

    public String getServerName() throws Exception {
        return this._serverName;
    }
    @XmlElement
    public void setServerName(String value) throws Exception {
        this._serverName = value;
    }

    public String getEnvironmentName() throws Exception {
        return this._environmentName;
    }
    @XmlElement
    public void setEnvironmentName(String value) throws Exception {
        this._environmentName= value;
    }

    public String getMetaData() throws Exception {
        return this._metadata;
    }
    @XmlElement
    public void setMetaData(String value) throws Exception {
        this._metadata = value;
    }

    public String getMetaDataFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this._metadata,name);
    }
    public void setMetaDataField(String name, String value) throws Exception {
        this._metadata = CeersUtils.setValueInPairString(this._metadata,name,value);
    }

    public String getUserData() throws Exception {
        return this._userdata;
    }
    @XmlElement
    public void setUserData(String value) throws Exception {
        this._userdata = value;
    }

    public String getUserDataFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this._userdata,name);
    }
    public void setUserDataField(String name, String value) throws Exception {
        this._userdata = CeersUtils.setValueInPairString(this._userdata,name,value);
    }

    public DataSensitivityType getDataSensitivity() throws Exception {
        return this._dataSensitivity;
    }
    @XmlElement
    public void setDataSensitivity(String sensitivity) throws Exception {
        if(sensitivity == null) sensitivity = "";
        sensitivity = sensitivity.toUpperCase();
        sensitivity = sensitivity.replace("_", "");
        sensitivity = sensitivity.replace("-", "");
        sensitivity = sensitivity.replace(" ", "");
        if (sensitivity.contains("BOEING")) {
            this.setDataSensitivity(DataSensitivityType.BOEING_PROPRIETARY);
        } else if (sensitivity.contains("FAR12")) {
            this.setDataSensitivity(DataSensitivityType.FAR12);
        } else if (sensitivity.contains("EAR")) {
            this.setDataSensitivity(DataSensitivityType.EAR);
        } else if (sensitivity.contains("ITAR")) {
            this.setDataSensitivity(DataSensitivityType.ITAR);
        } else if (sensitivity.contains("NONE")) {
            this.setDataSensitivity(DataSensitivityType.NONE);
        } else if (!sensitivity.equals("RESTRICT")) {
            this.setDataSensitivity(DataSensitivityType.RESTRICT);
        }
    }
    public void setDataSensitivity(DataSensitivityType value) throws Exception {
        this._dataSensitivity = value;
    }

    public boolean getIgnoreEventErrors() throws Exception {
        return this._ignoreEventErrors;
    }
    @XmlElement
    public void setIgnoreEventErrors(boolean value) throws Exception {
        this._ignoreEventErrors = value;
    }

    public boolean getDisableLogging() throws Exception {
        return this._disableLogging;
    }
    @XmlElement
    public void setDisableLogging(boolean value) throws Exception {
        this._disableLogging = value;
    }

    public String getAlternateLogFilePath() throws Exception {
        return this._alternateLogFilePath;
    }
    @XmlElement
    public void setAlternateLogFilePath(String value) throws Exception {
        this._alternateLogFilePath = value;
    }

    public String displayEvent() throws Exception {
        return "BaseEvent {" +
        "EventID='" + getEventID() + '\'' +
        ",  GlobalTransactionID='" + getGlobalTransactionID() + '\'' +
        ",  EventGroupName='" + getEventGroupName() + '\'' +
        ",  ApplicationName='" + getApplicationName() + '\'' +
        ",  MessageName='" + getMessageName() + '\'' +
        ",  ComponentName='" + getComponentName() + '\'' +
        ",  TimeStamp='" + getTimeStamp().toString() + '\'' +
        ",  ServerName='" + getServerName() + '\'' +
        ",  EnvironmentName='" + getEnvironmentName() + '\'' +
        ",  MetaData='" + getMetaData() + '\'' +
        ",  UserData='" + getUserData() + '\'' +
        ",  DataSensitivity='" + getDataSensitivity().toString() + '\'' +
        ",  IgnoreEventErrors='" + getIgnoreEventErrors() + '\'' +
        ",  DisableLogging='" + getDisableLogging() + '\'' +
        ",  AlternateLogFilePath='" + getAlternateLogFilePath() + '\'' +
        "} ";
    }
}




