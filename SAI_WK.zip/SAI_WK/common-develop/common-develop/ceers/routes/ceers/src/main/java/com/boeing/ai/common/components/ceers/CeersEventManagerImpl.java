/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : CeersEventManagerImpl.java - EventManager Implementation
 *                                             Converted from .NET API.
 *                                             Parent Class for CEERS Event
 *                                             objects exposed in API to send
 *                                             Events directly via method calls.
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers;
/*---------------------------------------------------------------------------*/

import com.boeing.ai.common.components.ceers.CeersEventSender;

import com.boeing.ai.common.components.ceers.CeersUtils;
import com.boeing.ai.common.components.ceers.eventmanager.AuditEvent;
import com.boeing.ai.common.components.ceers.eventmanager.DataSensitivityType;
import com.boeing.ai.common.components.ceers.eventmanager.EventManager;
import com.boeing.ai.common.components.ceers.eventmanager.EventSeverity;
import com.boeing.ai.common.components.ceers.eventmanager.EventState;
import com.boeing.ai.common.components.ceers.eventmanager.EventType;
import com.boeing.ai.common.components.ceers.eventmanager.NotificationEvent;
import com.boeing.ai.common.components.ceers.eventmanager.PayloadType;
import com.boeing.ai.common.components.ceers.eventmanager.StateEvent;
import com.boeing.ai.common.components.ceers.exception.CeersException;
import com.boeing.ai.common.utilities.ClassInfo;
import com.boeing.ai.common.utilities.StringSupport;

import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.exception.ExceptionUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
@XmlRootElement
public class CeersEventManagerImpl extends EventManager {
    // Variables
    private final transient Logger LOG = LoggerFactory.getLogger(CeersEventManagerImpl.class);

    // Audit Event Factory Methods
    public AuditEvent newAuditEvent(String messageName) throws Exception {
        AuditEvent ae = new AuditEvent(messageName);
        setAuditEvent(ae);
        setStateEvent(null);
        setNotificationEvent(null);
        setEventType(EventType.AUDIT);

        LOG.debug("Initializing Audit Event");

        return ae;
    }

    public AuditEvent newAuditEvent(String messageName, Object message) throws Exception {
        AuditEvent ae = newAuditEvent(messageName);
        ae.setPayloadMsgBuffer(message);
        ae.setPayloadMsgType(PayloadType.MessageExchange);

        LOG.debug("Audit Event Initialized");

        return ae;
    }

    public AuditEvent newAuditEvent(String messageName, byte[] message) throws Exception {
        AuditEvent ae = newAuditEvent(messageName);
        ae.setPayloadMsgBuffer(message);
        ae.setPayloadMsgType(PayloadType.ByteArray);

        LOG.debug("Audit Event Initialized");

        return ae;
    }

    public AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity) throws Exception {
        AuditEvent ae = newAuditEvent(messageName);
        ae.setEventGroupName(eventGroup);
        ae.setDataSensitivity(dataSensitivity);

        LOG.debug("Audit Event Initialized");

        return ae;
    }

    public AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, Object message) throws Exception {
        AuditEvent ae = newAuditEvent(messageName,eventGroup,dataSensitivity);
        ae.setPayloadMsgBuffer(message);
        ae.setPayloadMsgType(PayloadType.MessageExchange);

        LOG.debug("Audit Event Initialized");

        return ae;
    }

    public AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, byte[] message) throws Exception {
        AuditEvent ae = newAuditEvent(messageName,eventGroup,dataSensitivity);
        ae.setPayloadMsgBuffer(message);
        ae.setPayloadMsgType(PayloadType.ByteArray);

        LOG.debug("Audit Event Initialized");

        return ae;
    }

    // State Event Factory Methods
    public StateEvent newStateEvent(String messageName) throws Exception {
        StateEvent se = new StateEvent(messageName);
        setAuditEvent(null);
        setStateEvent(se);
        setNotificationEvent(null);
        setEventType(EventType.STATE);

        LOG.debug("Initializing State Event");

        return se;
    }

    public StateEvent newStateEvent(String messageName, EventState state, String additionalInfo) throws Exception {
        StateEvent se = newStateEvent(messageName);

        LOG.debug("Initializing State Event");

        se.setTransactionState(state);
        if (additionalInfo != null)
            se.setAdditionalInfo(additionalInfo);

        return se;
    }

    public StateEvent newStateEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity) throws Exception {
        StateEvent se = newStateEvent(messageName);
        se.setEventGroupName(eventGroup);
        se.setDataSensitivity(dataSensitivity);

        LOG.debug("Initializing State Event");

        return se;
    }

    public StateEvent newStateEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, EventState state, String additionalInfo) throws Exception {
        StateEvent se = newStateEvent(messageName,eventGroup,dataSensitivity);

        LOG.debug("Initializing State Event");

        se.setTransactionState(state);
        if (additionalInfo != null)
            se.setAdditionalInfo(additionalInfo);

        return se;
    }

    // Notification Event Factory Methods
    public NotificationEvent newNotificationEvent(String messageName) throws Exception {
        NotificationEvent ne = new NotificationEvent(messageName);
        setAuditEvent(null);
        setStateEvent(null);
        setNotificationEvent(ne);
        setEventType(EventType.NOTIFICATION);

        LOG.debug("Initializing NotificationEvent Event");

        ne.setPayloadMsgType(PayloadType.None);
        ne.setShortDescription("No Description Provided");

        return ne;
    }

    public NotificationEvent newNotificationEvent(String messageName, EventSeverity severity, String shortDesc, String longDesc) throws Exception {
        NotificationEvent ne = newNotificationEvent(messageName);

        LOG.debug("Initializing NotificationEvent Event");

        ne.setSeverity(severity);
        if (!StringSupport.isBlank(shortDesc))
            ne.setShortDescription(shortDesc);

        if (longDesc != null)
            ne.setDetailedDescription(longDesc);

        return ne;
    }

    public NotificationEvent newNotificationEvent(String messageName, EventSeverity severity, String shortDesc, Exception ex) throws Exception {
        NotificationEvent ne = newNotificationEvent(messageName);

        LOG.debug("Initializing NotificationEvent Event");

        ne.setSeverity(severity);
        if (!StringSupport.isBlank(shortDesc))
            ne.setShortDescription(shortDesc);

        if (ex != null)
            ne.setDetailedDescription(ex.getMessage() + "\n" + ExceptionUtils.getStackTrace(ex));

        return ne;
    }

    public NotificationEvent newNotificationEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity) throws Exception {
        NotificationEvent ne = newNotificationEvent(messageName);
        ne.setEventGroupName(eventGroup);
        ne.setDataSensitivity(dataSensitivity);

        LOG.debug("Initializing NotificationEvent Event");

        ne.setPayloadMsgType(PayloadType.None);
        ne.setShortDescription("No Description Provided");

        return ne;
    }

    public NotificationEvent newNotificationEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, EventSeverity severity, String shortDesc, String longDesc) throws Exception {
        NotificationEvent ne = newNotificationEvent(messageName,eventGroup,dataSensitivity);

        LOG.debug("Initializing NotificationEvent Event");

        ne.setSeverity(severity);
        if (!StringSupport.isBlank(shortDesc))
            ne.setShortDescription(shortDesc);

        if (longDesc != null)
            ne.setDetailedDescription(longDesc);

        return ne;
    }

    public NotificationEvent newNotificationEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, EventSeverity severity, String shortDesc, Exception ex) throws Exception {
        NotificationEvent ne = newNotificationEvent(messageName,eventGroup,dataSensitivity);

        LOG.debug("Initializing NotificationEvent Event");

        ne.setSeverity(severity);
        if (!StringSupport.isBlank(shortDesc))
            ne.setShortDescription(shortDesc);

        if (ex != null)
            ne.setDetailedDescription(ex.getMessage() + "\n" + ExceptionUtils.getStackTrace(ex));

        return ne;
    }

    public String sendAuditEvent(AuditEvent theEvent) throws Exception {
        LOG.debug("About to send Audit Event");
        EventLoggingUtility eventLogUtil  = null;
        Boolean ignoreErrors = false;
        String eventId = "";
        String tmpString = "";

        // Check property to override logging.
        if (theEvent.getDisableLogging() == false) {
            // Ceers field lets you ignore errors during processing so business messages are not stopped by CEERS issues.
            if (theEvent.getIgnoreEventErrors()) {
                ignoreErrors = true;
            }
            try {
                // ComponentName - If blank, grab calling class before moving further.
                tmpString = theEvent.getComponentName();
                if (StringSupport.isBlank(tmpString) || tmpString.contains("UNK")) // Clearout if set to unknown earlier
                    tmpString = "";
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = ClassInfo.getCallerCallerClassName();              // Get from Calling Class
                }
                theEvent.setComponentName(tmpString);

                // Define EventLogging object.
                eventLogUtil = CeersUtils.setupAuditEvent(theEvent);

                // Output to a folder or send to queue
                if(eventLogUtil != null) {
                    CeersEventSender.postAuditEvent(theEvent);
                } else {
                    throw new CeersException("Unable to generate EventLoggingUtility object");
                }
                eventId = eventLogUtil.getEventID();
            } catch (CeersException ce) {
                LOG.error(ce.getMessage());
                if(ignoreErrors) {
                    LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
                } else {
                    throw ce;
                }
            } catch (Exception e) {
                LOG.error("Exception while sending CEERS Event data: " + e.getMessage() + "\n" + ExceptionUtils.getStackTrace(e));
                if(ignoreErrors) {
                    LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
                } else {
                    throw e;
                }
            }
        } else
        {
            LOG.info("Logging Audit Events intentionally disabled");
        }
        return eventId ;
    }

    public String sendStateEvent(StateEvent theEvent) throws Exception {
        LOG.debug("About to send State Event");
        EventLoggingUtility eventLogUtil  = null;
        Boolean ignoreErrors = false;
        String eventId = "";
        String tmpString = "";

        // Check property to override logging.
        if (theEvent.getDisableLogging() == false) {
            // Ceers field lets you ignore errors during processing so business messages are not stopped by CEERS issues.
            if (theEvent.getIgnoreEventErrors()) {
                ignoreErrors = true;
            }
            try {
                // ComponentName - If blank, grab calling class before moving further.
                tmpString = theEvent.getComponentName();
                if (StringSupport.isBlank(tmpString) || tmpString.contains("UNK")) // Clearout if set to unknown earlier
                    tmpString = "";
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = ClassInfo.getCallerCallerClassName();              // Get from Calling Class
                }
                theEvent.setComponentName(tmpString);

                // Define EventLogging object.
                eventLogUtil = CeersUtils.setupStateEvent(theEvent);

                // Output to a folder or send to queue
                if(eventLogUtil != null) {
                    CeersEventSender.postStateEvent(theEvent);
                } else {
                    throw new CeersException("Unable to generate EventLoggingUtility object");
                }
                eventId = eventLogUtil.getEventID();
            } catch (CeersException ce) {
                LOG.error(ce.getMessage());
                if(ignoreErrors) {
                    LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
                } else {
                    throw ce;
                }
            } catch (Exception e) {
                LOG.error("Exception while sending CEERS Event data: " + e.getMessage() + "\n" + ExceptionUtils.getStackTrace(e));
                if(ignoreErrors) {
                    LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
                } else {
                    throw e;
                }
            }
        } else
        {
            LOG.info("Logging State Events intentionally disabled");
        }
        return eventId ;
    }

    public String sendNotificationEvent(NotificationEvent theEvent) throws Exception {
        LOG.debug("About to send Notification Event");
        EventLoggingUtility eventLogUtil  = null;
        Boolean ignoreErrors = false;
        String eventId = "";
        String tmpString = "";

        // Check property to override logging.
        if (theEvent.getDisableLogging() == false) {
            // Ceers field lets you ignore errors during processing so business messages are not stopped by CEERS issues.
            if (theEvent.getIgnoreEventErrors()) {
                ignoreErrors = true;
            }
            try {
                // ComponentName - If blank, grab calling class before moving further.
                tmpString = theEvent.getComponentName();
                if (StringSupport.isBlank(tmpString) || tmpString.contains("UNK")) // Clearout if set to unknown earlier
                    tmpString = "";
                if (StringSupport.isBlank(tmpString)) {
                    tmpString = ClassInfo.getCallerCallerClassName();              // Get from Calling Class
                }
                theEvent.setComponentName(tmpString);

                // Define EventLogging object.
                eventLogUtil = CeersUtils.setupNotificationEvent(theEvent);

                // Output to a folder or send to queue
                if(eventLogUtil != null) {
                    CeersEventSender.postNotificationEvent(theEvent);
                } else {
                    throw new CeersException("Unable to generate EventLoggingUtility object");
                }
                eventId = eventLogUtil.getEventID();
            } catch (CeersException ce) {
                LOG.error(ce.getMessage());
                if(ignoreErrors) {
                    LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
                } else {
                    throw ce;
                }
            } catch (Exception e) {
                LOG.error("Exception while sending CEERS Event data: " + e.getMessage() + "\n" + ExceptionUtils.getStackTrace(e));
                if(ignoreErrors) {
                    LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
                } else {
                    throw e;
                }
            }
        } else
        {
            LOG.info("Logging Notification Events intentionally disabled");
        }
        return eventId ;
    }

    public EventType getEventType() throws Exception {
        return this._eventType;
    }
    public void setEventType(EventType value) throws Exception {
        this._eventType= value;
    }

    public AuditEvent getAuditEvent() throws Exception {
        return this._auditEvent;
    }
    public void setAuditEvent(AuditEvent value) throws Exception {
        this._auditEvent= value;
    }

    public StateEvent getStateEvent() throws Exception {
        return this._stateEvent;
    }
    public void setStateEvent(StateEvent value) throws Exception  {
        this._stateEvent= value;
    }

    public NotificationEvent getNotificationEvent() throws Exception {
        return this._notificationEvent;
    }
    public void setNotificationEvent(NotificationEvent value) throws Exception {
        this._notificationEvent= value;
    }
}




