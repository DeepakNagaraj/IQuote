/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : EventManager.java - EventManager Class exposed in CEERS API
 *                                    Converted from .NET API. Parent abstract
 *                                    Class created to send Events directly from
 *                                    Java method calls.
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.eventmanager;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.components.ceers.eventmanager.AuditEvent;
import com.boeing.ai.common.components.ceers.eventmanager.DataSensitivityType;
import com.boeing.ai.common.components.ceers.eventmanager.EventSeverity;
import com.boeing.ai.common.components.ceers.eventmanager.EventState;
import com.boeing.ai.common.components.ceers.eventmanager.EventType;
import com.boeing.ai.common.components.ceers.eventmanager.NotificationEvent;
import com.boeing.ai.common.components.ceers.eventmanager.StateEvent;

/*---------------------------------------------------------------------------*/
public abstract class EventManager {
    public EventType _eventType;
    public AuditEvent _auditEvent;
    public StateEvent _stateEvent;
    public NotificationEvent _notificationEvent;

    public abstract AuditEvent newAuditEvent(String messageName) throws Exception ;

    public abstract AuditEvent newAuditEvent(String messageName, Object message) throws Exception ;

    public abstract AuditEvent newAuditEvent(String messageName, byte[] message) throws Exception ;

    public abstract AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity) throws Exception ;

    public abstract AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, Object message) throws Exception ;

    public abstract AuditEvent newAuditEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, byte[] message) throws Exception ;

    public abstract StateEvent newStateEvent(String messageName) throws Exception ;

    public abstract StateEvent newStateEvent(String messageName, EventState state, String additionalInfo) throws Exception ;

    public abstract StateEvent newStateEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity) throws Exception ;

    public abstract StateEvent newStateEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, EventState state, String additionalInfo) throws Exception ;

    public abstract NotificationEvent newNotificationEvent(String messageName) throws Exception ;

    public abstract NotificationEvent newNotificationEvent(String messageName, EventSeverity severity, String shortDesc, String longDesc) throws Exception ;

    public abstract NotificationEvent newNotificationEvent(String messageName, EventSeverity severity, String shortDesc, Exception ex) throws Exception ;

    public abstract NotificationEvent newNotificationEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity) throws Exception ;

    public abstract NotificationEvent newNotificationEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, EventSeverity severity, String shortDesc, String longDesc) throws Exception ;

    public abstract NotificationEvent newNotificationEvent(String messageName, String eventGroup, DataSensitivityType dataSensitivity, EventSeverity severity, String shortDesc, Exception ex) throws Exception ;

    public abstract String sendAuditEvent(AuditEvent theEvent) throws Exception ;

    public abstract String sendStateEvent(StateEvent theEvent) throws Exception ;

    public abstract String sendNotificationEvent(NotificationEvent theEvent) throws Exception ;

    public abstract EventType getEventType() throws Exception ;
    public abstract void setEventType(EventType value) throws Exception ;

    public abstract AuditEvent getAuditEvent() throws Exception ;
    public abstract void setAuditEvent(AuditEvent value) throws Exception ;

    public abstract StateEvent getStateEvent() throws Exception ;
    public abstract void setStateEvent(StateEvent value) throws Exception ;

    public abstract NotificationEvent getNotificationEvent() throws Exception ;
    public abstract void setNotificationEvent(NotificationEvent value) throws Exception ;
}




