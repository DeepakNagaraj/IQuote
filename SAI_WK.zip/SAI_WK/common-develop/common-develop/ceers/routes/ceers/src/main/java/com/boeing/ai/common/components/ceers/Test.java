package com.boeing.ai.common.components.ceers;

import java.util.UUID;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char sqr = (char)39;
		
System.out.println("char   "+UUID.randomUUID().toString());
		//System.out.println("fsfdsdf");
	

	}

}
