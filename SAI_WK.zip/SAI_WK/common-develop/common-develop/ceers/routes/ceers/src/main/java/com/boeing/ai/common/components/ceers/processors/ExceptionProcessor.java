/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 12-09-2016
 * Authors      : Alex Kretchetov, David Campbell, Rohan Mars, Tim Schramer
 * File         : ExceptionProcessor .java - Exception Processing for CEERS Route
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *-----------------------------------------------------------------------------
 * -.-.-/1.0.0  | Alex Kretchetov   | Initial Create.
 *              | David Campbell    |
 *              | Rohan Mars        |
 *              | 12-09-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Major update and additions.
 *              | Rohan Mars        | Added missing CEERS API functionality
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-21-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.processors;
/*---------------------------------------------------------------------------*/
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.exception.ExceptionUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class ExceptionProcessor implements Processor {

    private static final Logger LOG = LoggerFactory.getLogger(ExceptionProcessor.class);

    @Override
    public void process(Exchange exchange) {
        Throwable cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        String clazz = cause.getClass().getSimpleName();
        // do custom error handling if required based on clazz

        String errorMessage = cause.getMessage();
        // log message and print stack trace
        LOG.error(errorMessage);
        LOG.error(ExceptionUtils.getStackTrace(cause));
    }
}


