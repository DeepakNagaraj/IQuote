package xsql.ast;

import java.util.*;
import java.io.*;
import xsql.util.XMLUtils;

/**
 * This class writes an XML representation of the XML
 * binding classes in this package to an output writer.
 */
public class XMLWriter
{
   /**
    * The writer used to write the output.
    */
   public Writer out = null;
   /**
    * The margin used to indent the next line
    * that is written.
    */
   public int margin = 0;
   private int lineLength = 0;


   /**
    * Creates a new XMLWriter,
    * without a specified writer.
    * The field <code>writer</code> should be set
    * before any write methods are called.
    */
   public XMLWriter ()
   {
   }


   /**
    * Creates a new XMLWriter,
    * with the specified writer.
    * @param out The writer to send the output to.
    */
   public XMLWriter (Writer out)
   {
      this.out = out;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>XSQL</code>.
    * @param x The object to be written.
    */
   public void write (XSQL x) throws IOException
   {
      if (x == null)
         x = new XSQL ();

      write ("<xsql");
      margin += 3;
      writeAttribute ("root-tag", x.rootTag);
      writeln (">");
      for (Iterator i = x.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</xsql>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>XSQLStatement</code>.
    * @param x The object to be written.
    */
   public void write (XSQLStatement x) throws IOException
   {
      if (x == null)
         x = new xsql.impl.InsertStatementImpl ();

      if (x instanceof IfStatement)
         write ((IfStatement) x);
      else if (x instanceof WhileStatement)
         write ((WhileStatement) x);
      else if (x instanceof VarStatement)
         write ((VarStatement) x);
      else if (x instanceof TagStatement)
         write ((TagStatement) x);
      else if (x instanceof SetStatement)
         write ((SetStatement) x);
      else if (x instanceof EvalStatement)
         write ((EvalStatement) x);
      else if (x instanceof WriteStatement)
         write ((WriteStatement) x);
      else if (x instanceof LogStatement)
         write ((LogStatement) x);
      else if (x instanceof XMLStatement)
         write ((XMLStatement) x);
      else if (x instanceof QueryStatement)
         write ((QueryStatement) x);
      else if (x instanceof SelectStatement)
         write ((SelectStatement) x);
      else if (x instanceof xsql.impl.InsertStatementImpl)
         write ((xsql.impl.InsertStatementImpl) x);
      else if (x instanceof xsql.impl.UpdateStatementImpl)
         write ((xsql.impl.UpdateStatementImpl) x);
      else if (x instanceof xsql.impl.DeleteStatementImpl)
         write ((xsql.impl.DeleteStatementImpl) x);
      else if (x instanceof DefineProc)
         write ((DefineProc) x);
      else if (x instanceof CallProcDef)
         write ((CallProcDef) x);
      else if (x instanceof TEProcess)
         write ((TEProcess) x);
      else if (x instanceof TECall)
         write ((TECall) x);
      else if (x instanceof NWPProcess)
         write ((NWPProcess) x);
      else if (x instanceof NWPCall)
         write ((NWPCall) x);
      else if (x instanceof ImportClass)
         write ((ImportClass) x);
      else if (x instanceof DocumentStatement)
         write ((DocumentStatement) x);
      else if (x instanceof ThrowStatement)
         write ((ThrowStatement) x);
      else if (x instanceof CommitStatement)
         write ((CommitStatement) x);
      else if (x instanceof RollbackStatement)
         write ((RollbackStatement) x);
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>IfStatement</code>.
    * @param ifstatement The object to be written.
    */
   public void write (IfStatement ifstatement) throws IOException
   {
      if (ifstatement == null)
         ifstatement = new xsql.impl.IfStatementImpl ();

      write ("<if");
      margin += 3;
      writeAttribute ("condition", ifstatement.condition);
      writeln (">");
      write (ifstatement.thenPart);
      if (ifstatement.elsePart != null)
      {
         write (ifstatement.elsePart);
      }
      margin -= 3;
      writeln ("</if>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>ThenPart</code>.
    * @param t The object to be written.
    */
   public void write (ThenPart t) throws IOException
   {
      if (t == null)
         t = new ThenPart ();

      writeln ("<then>");
      margin += 3;
      for (Iterator i = t.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</then>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>ElsePart</code>.
    * @param e The object to be written.
    */
   public void write (ElsePart e) throws IOException
   {
      if (e == null)
         e = new ElsePart ();

      writeln ("<else>");
      margin += 3;
      for (Iterator i = e.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</else>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>WhileStatement</code>.
    * @param w The object to be written.
    */
   public void write (WhileStatement w) throws IOException
   {
      if (w == null)
         w = new xsql.impl.WhileStatementImpl ();

      write ("<while");
      margin += 3;
      writeAttribute ("condition", w.condition);
      writeln (">");
      for (Iterator i = w.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</while>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>VarStatement</code>.
    * @param v The object to be written.
    */
   public void write (VarStatement v) throws IOException
   {
      if (v == null)
         v = new xsql.impl.VarStatementImpl ();

      write ("<var");
      margin += 3;
      writeAttribute ("name", v.name);
      writeAttribute ("expr", v.expr);
      writeAttribute ("value", v.value);
      writeln (">");
      if (v.longExpr != null)
      {
         writeElement ("expr", v.longExpr);
      }
      if (v.longValue != null)
      {
         writeElement ("value", v.longValue);
      }
      margin -= 3;
      writeln ("</var>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>TagStatement</code>.
    * @param t The object to be written.
    */
   public void write (TagStatement t) throws IOException
   {
      if (t == null)
         t = new xsql.impl.TagStatementImpl ();

      write ("<tag");
      margin += 3;
      writeAttribute ("name", t.name);
      writeAttribute ("expr", t.expr);
      writeAttribute ("value", t.value);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>SetStatement</code>.
    * @param s The object to be written.
    */
   public void write (SetStatement s) throws IOException
   {
      if (s == null)
         s = new xsql.impl.SetStatementImpl ();

      write ("<set");
      margin += 3;
      writeAttribute ("name", s.name);
      writeAttribute ("expr", s.expr);
      writeAttribute ("value", s.value);
      writeln (">");
      if (s.longExpr != null)
      {
         writeElement ("expr", s.longExpr);
      }
      if (s.longValue != null)
      {
         writeElement ("value", s.longValue);
      }
      margin -= 3;
      writeln ("</set>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>EvalStatement</code>.
    * @param e The object to be written.
    */
   public void write (EvalStatement e) throws IOException
   {
      if (e == null)
         e = new xsql.impl.EvalStatementImpl ();

      write ("<eval");
      margin += 3;
      writeAttribute ("expr", e.expr);
      writeln (">");
      if (e.longExpr != null)
      {
         writeElement ("expr", e.longExpr);
      }
      margin -= 3;
      writeln ("</eval>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>WriteStatement</code>.
    * @param w The object to be written.
    */
   public void write (WriteStatement w) throws IOException
   {
      if (w == null)
         w = new xsql.impl.WriteStatementImpl ();

      write ("<write");
      margin += 3;
      writeAttribute ("value", w.value);
      writeln (">");
      if (w.longValue != null)
      {
         writeElement ("value", w.longValue);
      }
      margin -= 3;
      writeln ("</write>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>LogStatement</code>.
    * @param l The object to be written.
    */
   public void write (LogStatement l) throws IOException
   {
      if (l == null)
         l = new xsql.impl.LogStatementImpl ();

      write ("<log");
      margin += 3;
      writeAttribute ("level", l.level);
      writeAttribute ("value", l.value);
      writeln (">");
      if (l.longValue != null)
      {
         writeElement ("value", l.longValue);
      }
      margin -= 3;
      writeln ("</log>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>XMLStatement</code>.
    * @param x The object to be written.
    */
   public void write (XMLStatement x) throws IOException
   {
      if (x == null)
         x = new xsql.impl.XMLStatementImpl ();

      write ("<xml");
      margin += 3;
      writeAttribute ("tag", x.tag);
      writeAttribute ("value", x.value);
      writeln (">");
      if (x.longValue != null)
      {
         writeElement ("value", x.longValue);
      }
      for (Iterator i = x.attributes.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.XMLAttributeImpl) item);
      }
      for (Iterator i = x.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</xml>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>XMLAttribute</code>.
    * @param x The object to be written.
    */
   public void write (XMLAttribute x) throws IOException
   {
      if (x == null)
         x = new xsql.impl.XMLAttributeImpl ();

      write ("<xml-attribute");
      margin += 3;
      writeAttribute ("name", x.name);
      writeAttribute ("value", x.value);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>QueryStatement</code>.
    * @param q The object to be written.
    */
   public void write (QueryStatement q) throws IOException
   {
      if (q == null)
         q = new xsql.impl.InsertStatementImpl ();

      if (q instanceof SelectStatement)
         write ((SelectStatement) q);
      else if (q instanceof xsql.impl.InsertStatementImpl)
         write ((xsql.impl.InsertStatementImpl) q);
      else if (q instanceof xsql.impl.UpdateStatementImpl)
         write ((xsql.impl.UpdateStatementImpl) q);
      else if (q instanceof xsql.impl.DeleteStatementImpl)
         write ((xsql.impl.DeleteStatementImpl) q);
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>SelectStatement</code>.
    * @param s The object to be written.
    */
   public void write (SelectStatement s) throws IOException
   {
      if (s == null)
         s = new xsql.impl.SelectStatementImpl ();

      write ("<select");
      margin += 3;
      writeAttribute ("name", s.name);
      writeAttribute ("record-tag", s.recordTag);
      writeln (">");
      writeElement ("sql", s.sql);
      for (Iterator i = s.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Argument) item);
      }
      for (Iterator i = s.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</select>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>xsql.impl.InsertStatementImpl</code>.
    * @param insertstatement The object to be written.
    */
   public void write (xsql.impl.InsertStatementImpl insertstatement) throws IOException
   {
      if (insertstatement == null)
         insertstatement = new xsql.impl.InsertStatementImpl ();

      write ("<insert");
      margin += 3;
      writeAttribute ("name", insertstatement.name);
      writeln (">");
      writeElement ("sql", insertstatement.sql);
      for (Iterator i = insertstatement.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Argument) item);
      }
      margin -= 3;
      writeln ("</insert>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>xsql.impl.UpdateStatementImpl</code>.
    * @param u The object to be written.
    */
   public void write (xsql.impl.UpdateStatementImpl u) throws IOException
   {
      if (u == null)
         u = new xsql.impl.UpdateStatementImpl ();

      write ("<update");
      margin += 3;
      writeAttribute ("name", u.name);
      writeln (">");
      writeElement ("sql", u.sql);
      for (Iterator i = u.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Argument) item);
      }
      margin -= 3;
      writeln ("</update>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>xsql.impl.DeleteStatementImpl</code>.
    * @param d The object to be written.
    */
   public void write (xsql.impl.DeleteStatementImpl d) throws IOException
   {
      if (d == null)
         d = new xsql.impl.DeleteStatementImpl ();

      write ("<delete");
      margin += 3;
      writeAttribute ("name", d.name);
      writeln (">");
      writeElement ("sql", d.sql);
      for (Iterator i = d.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Argument) item);
      }
      margin -= 3;
      writeln ("</delete>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>DefineProc</code>.
    * @param d The object to be written.
    */
   public void write (DefineProc d) throws IOException
   {
      if (d == null)
         d = new xsql.impl.DefineProcImpl ();

      write ("<define-proc");
      margin += 3;
      writeAttribute ("name", d.name);
      writeln (">");
      write (d.definition);
      margin -= 3;
      writeln ("</define-proc>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>StoredProcDef</code>.
    * @param s The object to be written.
    */
   public void write (StoredProcDef s) throws IOException
   {
      if (s == null)
         s = new xsql.impl.StoredProcDefImpl ();

      write ("<stored-proc");
      margin += 3;
      writeAttribute ("schema-name", s.schemaName);
      writeAttribute ("package-name", s.packageName);
      writeAttribute ("procedure-name", s.procedureName);
      writeAttribute ("record-tag", s.recordTag);
      writeAttribute ("record-set-tag", s.recordSetTag);
      writeln (">");
      if (s.returnParameter != null)
      {
         writeln ("<return-parameter>");
         margin += 3;
         write (s.returnParameter);
         margin -= 3;
         writeln ("</return-parameter>");
      }
      for (Iterator i = s.parameterList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Parameter) item);
      }
      margin -= 3;
      writeln ("</stored-proc>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>ParameterDef</code>.
    * @param p The object to be written.
    */
   public void write (ParameterDef p) throws IOException
   {
      if (p == null)
         p = new xsql.impl.Parameter ();

      write ("<parameter");
      margin += 3;
      writeAttribute ("pos", p.pos);
      writeAttribute ("name", p.name);
      writeAttribute ("mode", p.mode);
      writeAttribute ("jdbc-type", p.jdbcType);
      writeAttribute ("length", p.length);
      writeAttribute ("scale", p.scale);
      writeAttribute ("simple-date-format", p.simpleDateFormat);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>CallProcDef</code>.
    * @param c The object to be written.
    */
   public void write (CallProcDef c) throws IOException
   {
      if (c == null)
         c = new xsql.impl.CallProc ();

      write ("<call-proc");
      margin += 3;
      writeAttribute ("name", c.name);
      writeAttribute ("define-proc-name", c.defineProcName);
      writeAttribute ("schema-name", c.schemaName);
      writeAttribute ("package-name", c.packageName);
      writeAttribute ("procedure-name", c.procedureName);
      writeAttribute ("record-tag", c.recordTag);
      writeAttribute ("record-set-tag", c.recordSetTag);
      writeln (">");
      for (Iterator i = c.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Argument) item);
      }
      for (Iterator i = c.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</call-proc>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>ArgumentDef</code>.
    * @param a The object to be written.
    */
   public void write (ArgumentDef a) throws IOException
   {
      if (a == null)
         a = new xsql.impl.Argument ();

      write ("<arg");
      margin += 3;
      writeAttribute ("name", a.name);
      writeAttribute ("pos", a.pos);
      writeAttribute ("simple-date-format", a.simpleDateFormat);
      writeAttribute ("time-zone", a.timeZone);
      writeAttribute ("date-type", a.dateType);
      writeAttribute ("jdbc-type", a.jdbcType);
      writeAttribute ("value", a.value);
      writeln (">");
      if (a.longValue != null)
      {
         writeElement ("value", a.longValue);
      }
      margin -= 3;
      writeln ("</arg>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>TEProcess</code>.
    * @param t The object to be written.
    */
   public void write (TEProcess t) throws IOException
   {
      if (t == null)
         t = new xsql.te.TEProcessImpl ();

      write ("<te-process");
      margin += 3;
      writeAttribute ("name", t.name);
      writeAttribute ("schema", t.schema);
      writeln (">");
      for (Iterator i = t.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</te-process>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>TECall</code>.
    * @param t The object to be written.
    */
   public void write (TECall t) throws IOException
   {
      if (t == null)
         t = new xsql.te.TECallImpl ();

      write ("<call-te");
      margin += 3;
      writeAttribute ("name", t.name);
      writeAttribute ("define-proc-name", t.defineProcName);
      writeAttribute ("schema-name", t.schemaName);
      writeAttribute ("package-name", t.packageName);
      writeAttribute ("procedure-name", t.procedureName);
      writeln (">");
      for (Iterator i = t.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Argument) item);
      }
      margin -= 3;
      writeln ("</call-te>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>NWPProcess</code>.
    * @param n The object to be written.
    */
   public void write (NWPProcess n) throws IOException
   {
      if (n == null)
         n = new xsql.nwp.NWPProcessImpl ();

      write ("<nwp-process");
      margin += 3;
      writeAttribute ("name", n.name);
      writeAttribute ("schema", n.schema);
      writeln (">");
      for (Iterator i = n.statementList.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((XSQLStatement) item);
      }
      margin -= 3;
      writeln ("</nwp-process>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>NWPCall</code>.
    * @param n The object to be written.
    */
   public void write (NWPCall n) throws IOException
   {
      if (n == null)
         n = new xsql.nwp.NWPCallImpl ();

      write ("<call-nwp-api");
      margin += 3;
      writeAttribute ("name", n.name);
      writeAttribute ("package-name", n.packageName);
      writeAttribute ("procedure-name", n.procedureName);
      writeln (">");
      for (Iterator i = n.args.iterator (); i.hasNext ();)
      {
         Object item = i.next ();
         write ((xsql.impl.Argument) item);
      }
      margin -= 3;
      writeln ("</call-nwp-api>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>ImportClass</code>.
    * @param importclass The object to be written.
    */
   public void write (ImportClass importclass) throws IOException
   {
      if (importclass == null)
         importclass = new xsql.impl.ImportClassImpl ();

      write ("<import-class");
      margin += 3;
      writeAttribute ("name", importclass.name);
      writeAttribute ("java-name", importclass.javaName);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>DocumentStatement</code>.
    * @param d The object to be written.
    */
   public void write (DocumentStatement d) throws IOException
   {
      if (d == null)
         d = new xsql.impl.DocumentStatementImpl ();

      write ("<doc");
      margin += 3;
      writeAttribute ("action", d.action);
      writeln (" />");
      margin -= 3;
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>ThrowStatement</code>.
    * @param t The object to be written.
    */
   public void write (ThrowStatement t) throws IOException
   {
      if (t == null)
         t = new xsql.impl.ThrowStatementImpl ();

      write ("<throw");
      margin += 3;
      writeAttribute ("reason", t.attrReason);
      writeln (">");
      if (t.elementReason != null)
      {
         writeElement ("reason", t.elementReason);
      }
      margin -= 3;
      writeln ("</throw>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>CommitStatement</code>.
    * @param c The object to be written.
    */
   public void write (CommitStatement c) throws IOException
   {
      if (c == null)
         c = new xsql.impl.CommitStatementImpl ();

      writeln ("<commit/>");
   }


   /**
    * Writes the XML representation of an instance of the
    * class <code>RollbackStatement</code>.
    * @param r The object to be written.
    */
   public void write (RollbackStatement r) throws IOException
   {
      if (r == null)
         r = new xsql.impl.RollbackStatementImpl ();

      writeln ("<rollback/>");
   }


   private void writeAttribute (String name, Object value)
   throws IOException
   {
      if (value != null)
      {
         writeln ();
         write (" " + name + "=");
         write ("\"" + XMLUtils.xmlEscape (value.toString ()) + "\"");
      }
   }


   private void writeElement (String name, Object value)
   throws IOException
   {
      writeln ();
      if (value != null)
      {
         write ("<" + name + ">");
         write (XMLUtils.xmlEscape (value.toString ()));
         write ("</" + name + ">");
      }
      else
      {
         write ("<" + name + "/>");
      }
   }


   private void startLine () throws IOException
   {
      for (int i = 0; i < margin; i ++)
         out.write (' ');
      lineLength = margin;
   }


   private void write (char ch) throws IOException
   {
      if (lineLength == 0)
         startLine ();

      out.write (ch);
      lineLength += 1;

      if (ch == '\n')
         lineLength = 0;
   }


   private void write (String s) throws IOException
   {
      for (int i = 0; i < s.length (); i++)
         write (s.charAt (i));
   }


   private void writeln (String s) throws IOException
   {
      write (s);
      write ("\n");
   }


   private void writeln () throws IOException
   {
      write ("\n");
   }
}
