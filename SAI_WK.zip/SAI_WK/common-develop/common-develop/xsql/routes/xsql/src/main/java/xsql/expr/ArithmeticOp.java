package xsql.expr;

public class ArithmeticOp extends BinaryOp
{
   public ArithmeticOp (ExpressionContext context,
                        String opSymbol,
                        Node left,
                        Node right)
   {
      super (context, opSymbol, left, right);
   }


   public Object eval ()
   throws Exception
   {
      evalOperands ();
      prepareValuesForArithmeticOp ();

      Number l = (Number) leftValue;
      Number r = (Number) rightValue;

      if (leftValue instanceof Double)
      {
         if (opSymbol.equals ("+"))
            return new Double (l.doubleValue () + r.doubleValue ());
         else if (opSymbol.equals ("-"))
            return new Double (l.doubleValue () - r.doubleValue ());
         else if (opSymbol.equals ("*"))
            return new Double (l.doubleValue () * r.doubleValue ());
         else if (opSymbol.equals ("/"))
            return new Double (l.doubleValue () / r.doubleValue ());
         else if (opSymbol.equals ("%"))
            return new Double (l.doubleValue () % r.doubleValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
      else if (leftValue instanceof Long)
      {
         if (opSymbol.equals ("+"))
            return new Long (l.longValue () + r.longValue ());
         else if (opSymbol.equals ("-"))
            return new Long (l.longValue () - r.longValue ());
         else if (opSymbol.equals ("*"))
            return new Long (l.longValue () * r.longValue ());
         else if (opSymbol.equals ("/"))
            return new Long (l.longValue () / r.longValue ());
         else if (opSymbol.equals ("%"))
            return new Long (l.longValue () % r.longValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
      else
      {
         if (opSymbol.equals ("+"))
            return new Integer (l.intValue () + r.intValue ());
         else if (opSymbol.equals ("-"))
            return new Integer (l.intValue () - r.intValue ());
         else if (opSymbol.equals ("*"))
            return new Integer (l.intValue () * r.intValue ());
         else if (opSymbol.equals ("/"))
            return new Integer (l.intValue () / r.intValue ());
         else if (opSymbol.equals ("%"))
            return new Integer (l.intValue () % r.intValue ());
         else
            throw new UndefinedOperatorException (opSymbol);
      }
   }
}
