package xsql.expr;

import java.util.*;

public interface RecordInterface
{
   public boolean fieldExists (String fieldName);
   public Object getFieldValue (String fieldName);
   public List getFieldList ();
}
