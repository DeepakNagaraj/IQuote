package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

/**
The XSQL language provides a simple way to query or update databases
and produce XML documents from the results of database operations.
<p>
This document specifies the structure and meaning of XSQL programs.
XSQL is an XML-based language.
The structure of an XSQL program is described by its DTD, along with
narrative rules, which express further syntax constraints that 
can not be fully expressed through the DTD. Each language construct consists
of one or more elements defined by the DTD.
Moreover, some of the values of attributes an elements must conform
to a well-formed syntax. In these cases, the standard Extended
Backus-Naur Form (EBNF) notation is used to describe the syntax.
<p>
The meaning of an XSQL program is described by narrative rules that describe
the meaning and composition rules for each language construct.
<p>
An XSQL program is given as a set of statements nested in a root
element, whose tag is <i>xsql</i>.
*/
public class XSQL
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;
   /**
    * Defines the tag used for the root element of the document produced
    * by an XSQL program. If this attribute is not specified, then
    * the tag <i>root</i> will be used.
    */
   public String  rootTag;
   /**
    * Defines a list of XSQL statements to be executed.
    * The statements are executed in the order specified.
    */
   public List  statementList = new LinkedList ();


}
