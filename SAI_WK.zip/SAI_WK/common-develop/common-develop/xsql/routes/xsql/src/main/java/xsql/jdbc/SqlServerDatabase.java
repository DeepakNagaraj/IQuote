package xsql.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.FileOutputStream;

import xsql.StatementContext;
import xsql.impl.Parameter;
import xsql.impl.StoredProcDefImpl;
import xsql.util.DBUtil;

public class SqlServerDatabase extends Database
{  
   public SqlServerDatabase (StatementContext context)
   {
      super (context);
   }
   
   public void initialize ()
   throws Exception
   {
      if (pm == null)
          pm = new SqlServerParameterManager (context);
   } 
   
   public void generateProcDefs (String procNamePattern,
                                 String procSchemaPattern,
                                 boolean includeSchemaInDefName)
   throws Exception
   {

      String logMsg = null;
      ResultSet rs = null;
      String procedureName;
      String schemaName;
      String packageName;
      String defFileName;


      try
      {
         conn.setAutoCommit (true);
         metaData = conn.getMetaData ();
         rs = metaData.getProcedures (null, procSchemaPattern, procNamePattern);
                  
         while (rs.next ())
         {          
            packageName = rs.getString ("PROCEDURE_CAT");
            schemaName = rs.getString ("PROCEDURE_SCHEM");
            procedureName = rs.getString ("PROCEDURE_NAME");
            
            StoredProcDefImpl def = getProcDefFromDatabase (schemaName,
                                                            null,
                                                            procedureName,
                                                            null,
                                                            null);
                        
            byte [] defAsByteArray = def.toXML ().getBytes ();
            
            if (includeSchemaInDefName)
               defFileName = schemaName + "." + packageName + "." + procedureName;
            else
               defFileName = packageName + "." + procedureName;
            
            System.out.println (defFileName);
            FileOutputStream out = new FileOutputStream (defFileName);
            out.write (defAsByteArray);
            out.close ();
        }
     }
     finally
     {
        DBUtil.closeResultSet (rs);
        conn.setAutoCommit (false);
     }
  }
      
   protected StoredProcDefImpl getProcDefFromDatabase (String schemaName,
                                                       String packageName,
                                                       String procedureName,
                                                       String recordSetTag,
                                                       String recordTag)
   throws Exception
   {
      StoredProcDefImpl def = null;
      String logMsg = null;
      ResultSet rs = null;

      try 
      {
         def = new StoredProcDefImpl ();
         def.schemaName = schemaName;
         def.packageName = packageName;
         def.procedureName = procedureName;
         def.recordSetTag = recordSetTag;
         def.recordTag = recordTag;
         
         if (metaData == null)
         {
            metaData = conn.getMetaData ();
         }

         rs = metaData.getProcedureColumns (packageName, 
                                            schemaName,
                                            procedureName, 
                                            "%");

         int position = 1;

         while (rs.next ())
         {
            Parameter p = pm.createParameter (rs);
            p.pos = new Integer (position++);
            
            if ("@RETURN_VALUE".equals(p.name))
            {
               p.name = StoredProcResult.getReturnValueFieldName();
               def.returnParameter = p;
            }
            else
            {
               def.parameterList.add (p);
            }
         }

         logMsg =
           "Successfully obtained stored procedure definition from database:\n"
           + def.toString ();
         logger.debug (this, logMsg);
         
         return def;
      }
      finally
      {
         DBUtil.closeResultSet (rs);
      }    
   }
} 
