package xsql.expr;

public class UnaryOp extends Node
{
   public String opSymbol;
   public Node left;
   public Object leftValue;


   public UnaryOp (ExpressionContext context,
                   String opSymbol,
                   Node left)
   {
      super (context);
      this.opSymbol = opSymbol;
      this.left = left;
      left.parent = this;
   }


   public void evalOperand ()
   throws Exception
   {
      leftValue = left.eval ();
   }


   public void prepareValueForArithmeticOp ()
   throws Exception
   {
      if (!(leftValue instanceof Number))
      {
         leftValue = toInteger (leftValue);
      }   
   }


   public void prepareValueForLogicalOp ()
   throws Exception
   {
      leftValue = toBoolean (leftValue);
   }
}
