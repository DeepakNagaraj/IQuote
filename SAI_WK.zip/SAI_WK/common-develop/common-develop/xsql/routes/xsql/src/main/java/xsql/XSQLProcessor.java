package xsql;

import java.sql.*;
import java.util.*;
import java.io.*;

import xsql.ast.*;
import xsql.impl.*;
import xsql.expr.*;
import xsql.util.*;
import xsql.jdbc.Database;
import xsql.jdbc.DatabaseFactory; 

public class XSQLProcessor implements StatementContext 
{
   protected XSQL spec = null;
   protected String defaultConnectionName = null;
   protected Connection defaultConnection = null;
   protected SymbolTable symbolTable = null;
   protected ElementNode currentDocument = null;
   protected Evaluator expressionEvaluator = null;
   protected Logger logger = null;
   protected Database db = null;
   protected boolean connectionValid = true;
   protected boolean purgeTEPipe = false;
   protected List<String> procDictPath = new LinkedList<String> ();
   protected String outputEncoding = "UTF-8";
   protected HashMap tags = null;


   public XSQLProcessor ()
   {
      logger = new Logger ();
      init ();
   }


   public void init ()
   {
      currentDocument = null;
      symbolTable = new SymbolTable ();
      tags = new HashMap ();
      symbolTable.beginScope ();
      expressionEvaluator = new Evaluator (symbolTable);
   }


   /**
    * Sets whether the default connection is valid, i.e.,
    * it can safely be used again in another invocation of an XSQL processor.
    * <p>
    * This method is called to set the default connection invalid by
    * XSQL, when application-specific errors occur using database
    * software packages, which cannot be cleared without getting
    * a new connection.
    * This is not common, but it does occur with certain database
    * packages XSQL interfaces with. For example, the TE API for
    * MTO depends on the state of PL-SQL package variables.
    * When certain errors occur the state of these variables becomes
    * invalid and future invocations of TEs with that
    * connection will perform erroneously.
    * <p>
    * XSQL does not use this flag to indicate that there are
    * SQL errors, such as a broken connection.
    * That is considered the reponsibility of the connection provider,
    * e.g., a connection pool.
    * This flag provides additional information to the connection provider
    * on whether it should allow this connection to be used again to call
    * XSQL.
    */
   public void setConnectionValid (boolean value)
   {
      connectionValid = value;
   }


   /**
    * Returns whether XSQL considers the default connection valid, i.e.,
    * it can safely be used again in another invocation of an XSQL processor.
    * <p>
    * If this method returns false, the connection should not be reused,
    * for example, it should not be returned to a connection pool.
    * <p>
    * This method may return false because of activities between XSQL and
    * PL-SQL packages of an application-specific nature, which do not
    * correspond to normal tests used by database connection pool software
    * to determine whether a connection is valid. (See setConnectionValid.)
    */
   public boolean getConnectionValid ()
   {
      return connectionValid;
   }


   /**
    * Sets a flag indicating whether or not to purge the Oracle
    * pipe at the completion of a TEprocess.
    * <p>
    * When an XSQL database connection is a pooled connection,
    * the purge pipe operation should be enabled
    * to ensure that the Oracle pipe associated with the connection,
    * which used by the TE API to talk to
    * the TE application deamon processes,
    * is cleared and does not contain
    * unused messages when the pooled connection is used again
    * in the future.
    * <p>
    * If this option is set to <code>true</code>, then XSQL must have
    * access to the <code>cdb_actions.purge_pipe()</code>
    * stored procedure.
    * <p>
    * The default value of this option is <code>false</code>.
    */
   public void setPurgeTEPipe (boolean value)
   {
      purgeTEPipe = value;
   }


   /**
    * indicates whether or not to purge the Oracle pipe at the end of
    * a TE process.
    */
   public boolean getPurgeTEPipe ()
   {
      return purgeTEPipe;
   }


   public void setLogWriter (LogWriter logWriter)
   {
      logger.setLogWriter (logWriter);
}


   public void setLogLevel (int level)
   {
      logger.setLevel(level);
   }
   

   public void setCurrentXMLDocument (ElementNode document)
   {
      this.currentDocument = document;
   }


   public void setVariable (String name, Object value)
   {
      symbolTable.addGlobal (name, value);
   }


   public SymbolTable getSymbolTable ()
   {
      return symbolTable;
   }


   public ElementNode getCurrentXMLDocument ()
   {
      if (currentDocument == null) createDocument ();
      return currentDocument;
   }


   public void execute (InputStream input)
   throws Exception
   {
      compileSpec (input);
      executeSpec ();
   }

   public void generateProcDefs (String procNamePattern, 
                                 String procSchemaPattern,
                                 boolean includeSchemaInDefName)
   throws Exception
   {
      db = getDatabase ();
      db.generateProcDefs (procNamePattern,
                           procSchemaPattern,
                           includeSchemaInDefName);
   }  
   
   protected void compileSpec (InputStream input)
   throws Exception
   {
      Object abstractSyntaxTree = parseXSQLSpec (input);
      Semantics sem = new Semantics ();
      sem.analyze (abstractSyntaxTree);
      spec = (XSQL) abstractSyntaxTree;
   }


   protected Object parseXSQLSpec (InputStream input)
   throws Exception
   {
      XSQLParser parser = new XSQLParser ();
      try
      {
         parser.parse (input, true);
      }
      catch (Exception e)
      {
      }
      int numErrors = parser.getNumErrors ();
      if (numErrors != 0)
      {
         String problem = "Error(s) found parsing XSQL input.";
         List errors = parser.getErrors ();
         throw new XSQLCompileTimeException (problem, errors);
      }
      return parser.getDocument ();
   }


   protected void executeSpec ()
   throws Exception
   {
      createDocument ();
      executeStatementList (spec.statementList);
   }


   public void executeStatementList (List statements)
   throws Exception
   {
      symbolTable.beginScope ();
      try
      {
         executeStatementListInCurrentScope (statements);
      }
      finally
      {
         symbolTable.endScope ();
      }
   }


   public void executeStatementListInCurrentScope (List statements)
   throws Exception
   {
      for (Iterator i = statements.iterator (); i.hasNext ();)
      {
         XSQLStatement s = (XSQLStatement) i.next ();
               
         try
         {
            s.execute (this);
         }
         catch (XSQLRuntimeException e)
         {
            if (e.getStatement () == null)
               e.setStatement (s);
            throw e;
         }
         catch (SQLException e)
         {
            String message =
              "A SQL exception occurred during statement execution.";
            throw new XSQLRuntimeException (s, message, e);
         }
         catch (Throwable t)
         {
            String message =
              "An exception occurred during statement execution.";
            throw new XSQLRuntimeException (s, message, t);
         }
      }
   }


   public void setDefaultConnection (Connection conn)
   {
      setDefaultConnection (null, conn);
   }
   

   /**
    * Adds a directory to the procedure directory path.
    */
   public void setProcDictPath (String dir)
   {
      this.procDictPath.add (dir); 
   }

   
   /**
    * Returns the list of directories in the procedure dictionary path.
    */
   public List<String> getProcDictPath ()
   {
      return procDictPath;
   }


   public void setDefaultConnection (String     connectionName,
                                     Connection conn)
   {
      defaultConnectionName = connectionName;
      defaultConnection = conn;
   }

   
   public Connection getDefaultConnection ()
   {
      return defaultConnection;
   }
   
   
   public String getDefaultConnectionName ()
   {
      return defaultConnectionName;
   }
     
   public Database getDatabase () 
   throws Exception
   {
      if (db == null)
      {
         DatabaseFactory factory = new DatabaseFactory ();
         db = factory.createDatabase (this);
      }
      return db;
   }

   public String resolveExpressions (String s) throws Exception
   {
      if (s == null) return null;
      
      StringBuffer resolvedString = new StringBuffer ();

      XSQLTokenizer tokenizer = new XSQLTokenizer (s);
      while (tokenizer.tokenType != tokenizer.EOS)
      {
         if (tokenizer.tokenType == tokenizer.TEXT)
            resolvedString.append (tokenizer.getText ());
         else
         {
            String expression = tokenizer.getExpr();
            Object value = evalExpression (expression);
            if (value != null)
               resolvedString.append (value.toString ());
         }
         tokenizer.getToken ();
      }
      return resolvedString.toString (); 
   }
    
   
   public Object evalExpression (String expr) throws Exception
   {
      try
      {
         if (expr == null) return null;
         return expressionEvaluator.evaluate (expr);
      }
      catch (ExpressionException e)
      {
         throw new XSQLRuntimeException (e.getMessage (), e.getCause ());
      }
   }


   public boolean evalBooleanExpression (String expr) throws Exception
   {
      try
      {
         return expressionEvaluator.evaluateBooleanExpression (expr);
      }
      catch (ExpressionException e)
      {
         throw new XSQLRuntimeException (e.getMessage (), e.getCause ());
      }
   }


   public Evaluator getExpressionEvaluator()
   {
      return this.expressionEvaluator;
   } 
   

   public Logger getLogger()
   {
      return this.logger; 
   }
   

   public int getNumWarnings ()
   {
      return logger.getNumWarnings ();
   }


   public int getNumErrors ()
   {
      return logger.getNumErrors ();
   }


   public void printDocument ()
   {
      try
      {
         if (currentDocument != null)
         {
            currentDocument.write (0, System.out, outputEncoding);
         }
      }
      catch (Exception e)
      {
         System.out.println (e);
      }
   }
   

   public void writeDocument (OutputStream os)
   throws Exception
   {
      if (currentDocument != null)
      {
         currentDocument.write (0, os, outputEncoding);
      }
   }
   

   protected void createDocument ()
   {
      String rootTag = "root";
      if (spec.rootTag != null) rootTag = spec.rootTag;
      currentDocument = new ElementNode (rootTag);
   }
   

   public void clearDocument() 
   {
      currentDocument = null;
   }
   
   public HashMap getDocumentTags ()
   {
      return tags;
   }
   
   public boolean containsDocument ()
   {
      if (currentDocument == null)
         return false;
      else
         return true;
   }
}
