package xsql.te;

import xsql.*;
import xsql.expr.*;
import xsql.ast.*;
import xsql.impl.*;
import xsql.util.*;
import java.sql.*;
import java.util.*;
import java.io.*;

public class TEProcessImpl extends TEProcess
implements TEGlobalDefs
{
   public static final String TE_PROCESS_STATUS_NAME = "TE_PROCESS_STATUS";
   private SymbolTable symtab = null;
   private StatementContext context;
   private Logger logger = null;


   public void execute (StatementContext context)
   throws Exception
   {
      this.context = context;
      logger = context.getLogger ();
      symtab = context.getSymbolTable ();

      logger.info ("Beginning TE Process: " + name);

      TEProcessStatus status =
        (TEProcessStatus) symtab.lookupGlobal (TE_PROCESS_STATUS_NAME);
      if (status != null)
      {
         String reason =
           "This TE process is nested inside another TE process.";
         throw new XSQLRuntimeException (reason);
      }

      status = new TEProcessStatus ();
      status.ccapiServices = establishCCAPIServices();
      symtab.addGlobal (TE_PROCESS_STATUS_NAME, status);

      boolean teProcessCompleted = false;
      try
      {
         context.executeStatementList(statementList);
         commitTEProcess (status);
         teProcessCompleted = true;
      }
      catch (TEProcessBreakException e)
      {
         context.setConnectionValid (false);
         rollbackTEProcess (status);
         teProcessCompleted = true;
      }
      finally
      {
         symtab.addGlobal (TE_PROCESS_STATUS_NAME, null);

         if (!teProcessCompleted)
         {
            context.setConnectionValid (false);
            rollbackTEProcess (status);
         }

         boolean purgeTEPipe = context.getPurgeTEPipe ();
         if (purgeTEPipe)
         {
            purgeTEPipe (status);
         }
      }
   }


   private synchronized CCAPIServices establishCCAPIServices ()
   throws Exception
   {

      String schema = this.schema;
      if (schema == null)
      {
         schema = (String) symtab.lookupGlobal (defaultTESchemaVarName);
      }

      Connection dbConn = context.getDefaultConnection ();
      CCAPIServices ccapiServices = new CCAPIServices (dbConn, schema, logger);
      ccapiServices.getLuwId ("a2a", "6", "campbell");
      return ccapiServices;
   }


   private void commitTEProcess (TEProcessStatus status)
   throws Exception
   {
      CCAPIServices ccapiServices = status.ccapiServices;

      if(status.numTECallsMade > 0)
      {
         logger.debug (this, "Committing TE process");

         int syncCommitRC = ccapiServices.syncCommit();

         if (syncCommitRC > 1)
         {
            List errors = ccapiServices.readMessages ();

            String message =
              "Error(s) occurred during a sync commit operation:\n"
              + ccapiServices.convertCCAPIMessagesToString (errors);

            logger.error (this, message);

            throw new TERuntimeException (message);
         }
         else
         {
            String msg =
              "TE Process completed successfully, syncCommit performed. "
              + status.numTECallsMade + " TE call(s) made.";
            logger.info (this, msg);
         }
      }
   }


   private void rollbackTEProcess (TEProcessStatus status)
   throws Exception
   {
      CCAPIServices ccapiServices = status.ccapiServices;

      if (status.numTECallsMade > 0)
      {
         logger.debug (this, "Rolling back TE process");

         int syncNullRC = ccapiServices.syncNull ();
         int syncRollbackRC = ccapiServices.syncRollback ();

         if(syncRollbackRC == 2 || syncNullRC == 2)
         {
            logger.error (this,
              "Error(s) occurred during sync rollback operation.");
            List errors = ccapiServices.readMessages ();
            for(Iterator i = errors.iterator(); i.hasNext ();)
            {
               CCAPITEMessage msg = (CCAPITEMessage) i.next ();
               logger.info (this, msg.toString());
            }
         }
         else
         {
            String msg =
              "TE Process completed with errors, syncRollback performed. "
              + status.numTECallsMade + " TE call(s) made.";
            logger.error (this, msg);
         }
      }
   }


   private void purgeTEPipe (TEProcessStatus status)
   {
      CCAPIServices ccapiServices = status.ccapiServices;
      if (status.numTECallsMade > 0)
      {
         logger.debug (this, "purging TE pipe");

         context.setConnectionValid (false);

         try
         {
            int rc = ccapiServices.purgePipe ();

            if (rc == 0)
            {
               context.setConnectionValid (true);
            }
            else
            {
               logger.warning (this,
                 "Error(s) occurred during purge pipe operation: rc = " + rc);
            }
         }
         catch (Exception e)
         {
            logger.warning (this,
              "An exception occurred during purge pipe operation.", e);
         }
      }
   }
}
