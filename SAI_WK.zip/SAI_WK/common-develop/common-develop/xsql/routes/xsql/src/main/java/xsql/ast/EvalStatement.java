package xsql.ast;

import java.util.*;
import java.io.*;


/**
An <i>eval statement</i> evaluates an expression.
*/
abstract public class EvalStatement extends XSQLStatement
implements Serializable
{
   /**
    * The expression to be evaluated, given as an attribute.
    * The expression my either be given as an attribute or an element.
    */
   public String  expr;
   /**
    * The expression to be evaluated, given as a element.
    * The expression my either be given as an attribute or an element.
    */
   public String  longExpr;


}
