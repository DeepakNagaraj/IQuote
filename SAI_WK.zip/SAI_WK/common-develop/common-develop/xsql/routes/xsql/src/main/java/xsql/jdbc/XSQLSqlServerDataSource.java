package xsql.jdbc;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;
import com.microsoft.sqlserver.jdbc.SQLServerDataSource;

import java.io.*;
import  java.sql.*;
import java.util.logging.Logger;

/**
 *  Encapsulates the specific data and behavior for connecting to a 
 *  Microsoft SQLServer database via JDBC.
 */
public class XSQLSqlServerDataSource extends XSQLDataSource
implements Serializable
{
   private static int DEFAULT_PORT = 1433;
   private SQLServerDataSource ds = null;
   
   public XSQLSqlServerDataSource ()
   {  
   }  
   
   public XSQLSqlServerDataSource (String name, Connection conn)
   {
      super(name, conn);
   }
   
   public boolean equals (Object obj)
   {
      if (!super.equals (obj))
      {
         return false;
      }
      if (obj == null) return false;
      if (!(obj instanceof XSQLSqlServerDataSource)) return false;

      XSQLSqlServerDataSource obj1 = (XSQLSqlServerDataSource) obj;
      return true;
   }


   public String getJDBCUrl () throws SQLException
   {
      if (url != null) return url;
      
      StringBuffer myUrl = new StringBuffer ();
      myUrl.append ("jdbc:sqlserver://");
      myUrl.append (getHost ());
      
      if (getPort () != DEFAULT_PORT)
      {
         myUrl.append (":");
         myUrl.append (getPort ());
      }
      
      myUrl.append (";databasename=");
      myUrl.append (getSid());
      
      myUrl.append (";user=");
      myUrl.append (getUser ());
      
      myUrl.append (";password=");
      myUrl.append (getPwd ());
         
      String instanceName = getInstanceName ();
      if (instanceName != null)
      {
         myUrl.append (";instancename=");
         myUrl.append (instanceName);
      }

      return myUrl.toString ();
   }
   
   private String getInstanceName ()
   {
      if (host == null)
      {
         return null;
      }
      else
      {
         String [] data = host.split ("\\\\");
         if (data.length == 2)
            return data [1];
         else
            return null;
      }
   }

   
   /**
    * Returns the port to the jdbc datasource
    */
   public int getPort ()
   throws SQLException
   {
      try
      {
         if (port == null)
            return DEFAULT_PORT;
         else
            return Integer.parseInt (port);
      }
      catch (Exception e)
      {
         String errMsg = "Unable to get port number.";
         throw new SQLException(errMsg);
      }
   } 
   
   public Connection getConnection()
   throws SQLException
   {
      if (conn != null)
         return conn;
      
      if (url == null)
         return getConnectionFromDataSource ();
      else
         return getConnectionFromDriver ();
   }
   
   protected Connection getConnectionFromDataSource ()
   throws SQLException
   {
      if (ds == null)
         ds = new SQLServerDataSource ();

      ds.setDatabaseName (getSid ());
      ds.setInstanceName (getInstanceName ());
      ds.setLoginTimeout (getLoginTimeout ());
      ds.setServerName (getHost ());
      ds.setUser (getUser ());
      ds.setPassword (getPwd ());
      
      if (getPort () != DEFAULT_PORT)
         ds.setPortNumber (getPort ());
      
      return ds.getConnection ();     
   }
   
   protected Connection getConnectionFromDriver ()
   throws SQLException
   {
      SQLServerDriver d = new SQLServerDriver ();
      return d.connect (getJDBCUrl (), null);
   }

}
