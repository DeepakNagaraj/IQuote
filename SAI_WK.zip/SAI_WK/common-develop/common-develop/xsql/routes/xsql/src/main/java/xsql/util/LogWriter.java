package xsql.util;

public interface LogWriter
{
   public void writeMessage (String message);
}
