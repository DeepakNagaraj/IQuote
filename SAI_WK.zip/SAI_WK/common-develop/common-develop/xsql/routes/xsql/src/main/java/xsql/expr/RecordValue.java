package xsql.expr;

import java.util.*;


public class RecordValue implements RecordInterface
{
   private HashMap lookup = new HashMap ();
   private List fields = new LinkedList ();


   public RecordValue ()
   {
   }


   public List getFieldList ()
   {
      return fields;
   }


   public void setFieldValue (String name, Object value)
   {
      Field f = (Field) lookup.get (name);
      if (f == null)
      {
         f = new Field (name, value);
         lookup.put (name, f);
         fields.add (f);
      }
      else
      {
         f.value = value;
      }
   }


   public boolean fieldExists (String name)
   {
      return lookup.containsKey (name);
   }


   public Object getFieldValue (String name)
   {
      Field f = (Field) lookup.get (name);
      if (f == null)
         return null;
      else
         return f.value;
   }
}
