package xsql.te;

public class CCAPITEMessage
{

   String ruleType;
   String event;
   String object;
   String attribute;
   int type;
   long number;
   long sqlError;
   String exception;
   String text;
   String date; 


   public String toString ()
   {
      String msg = "CCAPI Message: (";
      msg += "ruleType: " + ruleType + ", ";
      msg += "event: " + event + ", ";
      msg += "object: " + object + ", ";
      msg += "attribute: " + attribute + ", ";
      msg += "type: " + type + ", ";
      msg += "number: " + number + ", ";
      msg += "sqlError: " + sqlError + ", ";
      msg += "exception: " + exception + ", ";
      msg += "text: " + text + ", ";
      msg += "date : " + date  + ")";
      return msg;
   }


   public void setMsgRuleType (String ruleType)
   {
      this.ruleType = ruleType;
   }


   public void setMsgEvent (String event)
   {
      this.event = event;
   }


   public void setMsgObject (String object)
   {
      this.object = object;
   }


   public void setMsgAttribute (String attribute)
   {
      this.attribute = attribute;
   }


   public void setMsgType (int type)
   {
      this.type = type;
   }



   public void setMsgNumber (long number)
   {
      this.number = number;
   }


   public void setMsgSqlError (long sqlError)
   {
      this.sqlError = sqlError;
   }


   public void setMsgException (String exception)
   {
      this.exception = exception;
   }


   public void setMsgText (String text)
   {
      this.text = text;
   }


   public void setMsgDate (String date)
   {
      this.date = date;
   } 
}
