package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.ast.XMLAttribute;
import xsql.expr.*;
import xsql.util.*;


public class ElementNode extends XMLNode
implements Serializable
{
   String tag;
   List attributes;
   List children = new LinkedList ();


   public ElementNode ()
   {
   }


   public ElementNode (String tag)
   {
      this.tag = tag;
   }
   
   public ElementNode (String tag, List attributes)
   {
      this.tag = tag;
      this.attributes = attributes;
   }


   public void addRecordFields (RecordInterface record)
   {
      children.add (record);
   }
   
   
   public void addArrayElements (ArrayInterface array)
   {
      children.add (array);
   }
   
   
   public void addChild (XMLNode node)
   {
      children.add (node);
   }


   public void write (int indent, Writer writer)
   throws Exception
   {
      for (int i = 0; i < indent; i++)
         writer.write (" ");
      
      if (children.size () == 0)
      {
         writer.write ("<" + tag);
         if (attributes != null)
         {
            for (int j = 0; j < attributes.size (); j++)
            {
               writer.write (" ");
               XMLAttributeImpl attr = (XMLAttributeImpl) attributes.get (j);
               attr.write (writer);
            }
         }
         writer.write ("/>");
         writer.write ("\n");
      }
      else
      {
         writer.write ("<" + tag);
         if (attributes != null)
         {
            for (int j = 0; j < attributes.size (); j++)
            {
               writer.write (" ");
               XMLAttributeImpl attr = (XMLAttributeImpl) attributes.get (j);
               attr.write (writer);
            }
         }
         writer.write (">");
         writer.write ("\n");

         for (Iterator i = children.iterator (); i.hasNext ();)
         {
            Object child = i.next ();

            if (child instanceof RecordInterface)
               writeRecordFields (writer, indent + 2, (RecordInterface) child);
            else if (child instanceof ArrayInterface)
               writeArrayElements (writer, indent + 2, (ArrayInterface) child);
            else if (child instanceof XMLNode)
            {
               XMLNode node = (XMLNode) child;
               node.write (indent + 2, writer);
            }
         }
         for (int i = 0; i < indent; i++)
            writer.write (" ");
      
         writer.write ("</" + tag + ">");
         writer.write ("\n");
      }
   }


   public void writeRecordFields (Writer writer,
                                  int indent,
                                  RecordInterface record)
   throws Exception
   {
      List fieldList = record.getFieldList ();
      for (Iterator i = fieldList.iterator (); i.hasNext ();)
      {
         Field f = (Field) i.next ();
         writeValue (writer, indent, f.name, f.value);
      }
   }


   public void writeValue (Writer writer,
                           int indent,
                           String tag,
                           Object value )
   throws Exception
   {
      if (value == null) return;

      for (int i = 0; i < indent; i++)
         writer.write (" ");
      
      if (value instanceof RecordInterface)
      {
         writer.write ("<" + tag + ">\n");
         writeRecordFields (writer, indent + 2, (RecordInterface) value);
         for (int i = 0; i < indent; i++)
            writer.write (" ");
         writer.write ("</" + tag + ">\n");
      }
      else if (value instanceof ArrayInterface)
      {
         writer.write ("<" + tag + ">\n");
         writeArrayElements (writer, indent + 2, (ArrayInterface) value);
         for (int i = 0; i < indent; i++)
            writer.write (" ");
         writer.write ("</" + tag + ">\n");
      }
      else
      {
         writer.write ("<" + tag + ">");
         writer.write (XMLUtils.xmlEscape (value.toString ()));
         writer.write ("</" + tag + ">\n");
      }
   }


   public void writeArrayElements (Writer writer,
                                   int indent,
                                   ArrayInterface array)
   throws Exception
   {
      String name = array.getComponentName ();

      int length = array.length ();
      for (int ix = 0; ix < length; ix++)
      {
         Object value = array.getValue (ix);
         writeValue (writer, indent, name, value);
      }
   }
}
