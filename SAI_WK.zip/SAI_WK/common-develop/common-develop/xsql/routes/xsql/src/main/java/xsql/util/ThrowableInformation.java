package xsql.util;

import java.io.Writer;
import java.io.PrintWriter;
import java.util.Vector;

public class ThrowableInformation
{
   private Throwable throwable;
   private String          msg;
  
   public ThrowableInformation(Throwable throwable) 
   {
      this.throwable = throwable;
   }

   public String toString() 
   {
      if(msg == null)  
      {
         msg = "\n";
         VectorWriter vw = new VectorWriter ();
         throwable.printStackTrace(vw);
         String [] msgArray = vw.toStringArray();
         vw.clear();

         for (int i = 0; i < msgArray.length; i++)
            msg += "    " + msgArray[i] + "\n";
      }
      
      return msg;
   }
 
}
class VectorWriter extends PrintWriter 
{
   private Vector v;
  
   public VectorWriter() 
   {
      super( new NullWriter());
      v = new Vector();
   }
  
   public void println(Object o) 
   {
      v.addElement(o.toString());
   }
  

   public void println(char[] s) 
   {
      v.addElement(new String(s));
   }
  
   public void println(String s) 
   {
      v.addElement(s);
   }

   public String[] toStringArray() 
   {
      int len = v.size();
      String[] sa = new String[len];
      for(int i = 0; i < len; i++) {
         sa[i] = (String) v.elementAt(i);
      }
      return sa;
   }

   public void clear() 
   {
      v.setSize(0);
   }
}  

class NullWriter extends Writer 
{    
  public void close() {}

  public void flush() {}

  public void write(char[] cbuf, int off, int len) {}
}

