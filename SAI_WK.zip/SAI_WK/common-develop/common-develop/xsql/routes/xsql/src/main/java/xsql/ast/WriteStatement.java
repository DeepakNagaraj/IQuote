package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>write statement</i> writes a value to standard out.
It is provided to help debug XSQL programs.
*/
abstract public class WriteStatement extends XSQLStatement
implements Serializable
{
   /**
    * The value to be written, given as an attribute.
    */
   public String  value;
   /**
    * The value to be written, given as a element.
    */
   public String  longValue;


}
