    package xsql.util;
    
    import java.util.Date;
    import java.text.DateFormat;
    import java.text.SimpleDateFormat;
    
    public class DateUtil
    {
       private DateUtil()
       {
       }

       /*
        * Converts a date string from one String format to another using
        * Java's built in parsing and formatting routines.
        */
       public static String reformatDateString(String inDateString,
                                               String inSimpleDateFormatPattern,
                                               String outSimpleDateFormatPattern)
       throws Exception
       {
          SimpleDateFormat sdf = new SimpleDateFormat(inSimpleDateFormatPattern);
          Date d = sdf.parse(inDateString);
          sdf.applyPattern(outSimpleDateFormatPattern);
          return sdf.format(d);
       }
       
       public static Date convertStringToDate (String inDate,
                                               String simpleDateFormat)
       throws Exception
       {
          SimpleDateFormat sdf = new SimpleDateFormat (simpleDateFormat);
          Date d = sdf.parse (inDate);
          return d;
       }
       
       public static String convertDateToString (Date inDate,
                                                 String simpleDateFormat)
       throws Exception
       {
          SimpleDateFormat sdf = new SimpleDateFormat (simpleDateFormat);
          String formattedDate = sdf.format (inDate);
          return formattedDate;
       }
}

