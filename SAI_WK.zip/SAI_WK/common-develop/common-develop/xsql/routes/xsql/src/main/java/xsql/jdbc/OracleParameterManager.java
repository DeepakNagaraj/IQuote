package xsql.jdbc;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.LinkedList;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleResultSet;
import oracle.jdbc.OracleTypes;
import oracle.sql.BLOB;
import oracle.sql.CLOB;

import xsql.StatementContext;
import xsql.impl.Argument;
import xsql.impl.Parameter;
import xsql.util.IOUtil;

public class OracleParameterManager extends ParameterManager
{
   LinkedList temporaryLobs = new LinkedList ();
   
   public OracleParameterManager (StatementContext context)
   {
      super (context);
      jdbcTypes2SqlTypes.put ("CURSOR", new Integer (OracleTypes.CURSOR));
      sqlTypes2JdbcTypes.put (new Integer (OracleTypes.CURSOR), "CURSOR");
      jdbcTypes2SqlTypes.put ("BLOB", new Integer (OracleTypes.BLOB));
      sqlTypes2JdbcTypes.put (new Integer (OracleTypes.BLOB), "BLOB");
      jdbcTypes2SqlTypes.put ("CLOB", new Integer (OracleTypes.CLOB));
      sqlTypes2JdbcTypes.put (new Integer (OracleTypes.CLOB), "CLOB");
   }
  
   @Override
   public void clear ()
   {
      super.clear ();
      freeTemporaryClobs ();
   }
   
   @Override
   protected void  setDecimalParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setNumericParameter (p, arg, value);
   }
   
   @Override
   protected void setNumericParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      int scale = 0; 
         
      if (p.scale != null)
         scale = p.scale.intValue ();

      String val = value.toString ();

      if ("".equals(val.trim()))
      {
         setNullParameter (p, arg, value);
         return;
      }

      if (scale > 0)
      {
         Double d = new Double (val);
         ps.setDouble (p.pos.intValue (), d.doubleValue ());
      }
      else
      {
         if (val.indexOf ('.') == -1)
         {
            Long l = new Long (val);
            ps.setLong (p.pos.intValue (), l.longValue ());
         }
         else
         {
            Double d = new Double (val);
            ps.setDouble (p.pos.intValue (), d.doubleValue ());
         }
      }
   }
   
   
   @Override
   protected void setOtherParameter  (Parameter p, Argument arg, Object value)
   throws Exception
   {
      if ("CLOB".equalsIgnoreCase (p.dbTypeName))
         setClobParameter (p, arg, value);
      else
         throw new IllegalArgumentException ("Unsupported JDBC data type.");
   }
   
   @Override
   protected void setStringParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      String val = value.toString ();
      if ("".equals(val))
         setNullParameter (p, arg, null);
      else
         ps.setString (p.pos.intValue (), val);
   }
 
   @Override
   protected void setOutParameter (Parameter  p)
   throws Exception
   {
      if (("DECIMAL".equalsIgnoreCase (p.jdbcType)) ||
          ( "DOUBLE".equalsIgnoreCase (p.jdbcType)) ||
          (  "FLOAT".equalsIgnoreCase (p.jdbcType)) ||
          ("NUMERIC".equalsIgnoreCase (p.jdbcType)) ||
          (   "REAL".equalsIgnoreCase (p.jdbcType)) ||
          ( "NUMBER".equalsIgnoreCase (p.dbTypeName)))
      {
         setNumericOutParameter (p);
      }
      else if ( ("CHAR".equalsIgnoreCase (p.dbTypeName))  ||
                ("CHAR".equalsIgnoreCase (p.jdbcType))    ||
             ("VARCHAR".equalsIgnoreCase (p.dbTypeName))  ||
             ("VARCHAR".equalsIgnoreCase (p.jdbcType))    ||
            ("VARCHAR2".equalsIgnoreCase (p.dbTypeName)))

      {
         int length = 32767;
         if (p.length != null)
            length = p.length.intValue ();

         if (cs instanceof OracleCallableStatement)
         {
            OracleCallableStatement ocs = (OracleCallableStatement) cs;
            ocs.registerOutParameter (p.pos.intValue (), p.sqlType, 0, length);
         }
         else
         {
            Class cl = OracleCallableStatement.class;
            if (cs.isWrapperFor (cl))
            {
               OracleCallableStatement ocs = (OracleCallableStatement) cs.unwrap (cl);
               ocs.registerOutParameter (p.pos.intValue (), p.sqlType, 0, length);
            }
         }
      }
      else if ("REF CURSOR".equalsIgnoreCase(p.dbTypeName))
      {
         p.jdbcType = "CURSOR";
         Integer sqlType = new Integer(getSQLTypeFromJDBCType (p.jdbcType));
         p.sqlType = sqlType.intValue ();
         cs.registerOutParameter(p.pos.intValue (),  p.sqlType);
      }
      else
      {
         cs.registerOutParameter(p.pos.intValue (), p.sqlType);
      }
   }

   @Override
   protected Object getDatabaseSpecificParameter (Parameter p, Argument arg)
   throws Exception
   {
      if ("CURSOR".equalsIgnoreCase (p.jdbcType))
         return getCursorParameter (p, arg);
      else
         throw new IllegalArgumentException ("Unsupported JDBC data type.");
   }
   
   
   private Object getCursorParameter (Parameter p, Argument arg)
   throws Exception
   {
      OracleCallableStatement ocs = (OracleCallableStatement) cs;
      ResultSet rs = ocs.getCursor (p.pos.intValue ());
      return rs;
   }
   
   
   @Override
   protected Object getClobParameter   (Parameter p,  Argument arg)
   throws Exception
   {
      CLOB clob = null;
      Reader reader = null;
      StringBuffer stringBuffer = null;
      try
      {
         clob = getCLOB (p.pos.intValue ());
         if (clob == null) return null;
         
         reader = clob.getCharacterStream ();
         int bufferSize = clob.getBufferSize ();
         char [] charBuffer = new char[bufferSize];
         int lengthRead = reader.read(charBuffer);
         while (lengthRead != -1)
         {
           String readResult = new String(charBuffer, 0, lengthRead);
           if (stringBuffer == null)
              stringBuffer = new StringBuffer ();
           stringBuffer.append (readResult);
           lengthRead = reader.read(charBuffer);
         }
         
         if (stringBuffer == null)
            return null;
         else
            return stringBuffer.toString ();
      }
      finally
      {
         IOUtil.closeReader (reader);
      }
   }
   
   private CLOB getCLOB (int index)
   throws Exception
   {
      CLOB clob = null;

      if (rs != null)
      {
         OracleResultSet ors = (OracleResultSet) rs;
         clob = ors.getCLOB (index);
         if (ors.wasNull ())
            return null;
         else
            return clob;
      }
      else
      {
         OracleCallableStatement ocs = (OracleCallableStatement) cs;
         clob = ocs.getCLOB (index);
         if (ocs.wasNull ()) 
            return null;
         else
            return clob;
      }
   }

   @Override
   protected Object getBlobParameter   (Parameter p,  Argument arg)
   throws Exception
   {
      String encoding = null;
      BLOB blob = null;
      InputStream is = null;
      try
      {
         blob = getBLOB (p.pos.intValue ());
         if (blob == null) return null;
         is = blob.getBinaryStream ();
         return IOUtil.inputStreamToString (is, encoding, blob.getChunkSize ());
      }
      finally
      {
         IOUtil.closeInputStream (is);
      }
   }

   private BLOB getBLOB (int index)
   throws Exception
   {
      BLOB blob = null;

      if (rs != null)
      {
         OracleResultSet ors = (OracleResultSet) rs;
         blob = ors.getBLOB (index);
         if (ors.wasNull ())
            return null;
         else
            return blob;
      }
      else
      {
         OracleCallableStatement ocs = (OracleCallableStatement) cs;
         blob = ocs.getBLOB (index);
         if (ocs.wasNull ())
            return null;
         else
            return blob;
      }
   }

   @Override
   protected void setBlobParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      String logMsg = null;
      BLOB blob = null;
      OraclePreparedStatement ops = (OraclePreparedStatement) ps;
      Connection conn = ps.getConnection ();
      blob = createBLOB (conn, value.toString ());
      ops.setBLOB (p.pos.intValue (), blob);
      logMsg = "Wrote " + Long.toString (blob.length ()) + " bytes " + "into " +
               "parameter " + p.pos.toString ();
      logger.info (this,logMsg);
   }

   private BLOB createBLOB (Connection conn, String value)
   throws Exception
   {
      BLOB blob = null;
      boolean useCache = true;
      blob = BLOB.createTemporary(conn, useCache, BLOB.DURATION_SESSION);
      temporaryLobs.add (blob);
      copyValueToBlob (blob, value);
      return blob;
   }


   @Override
   protected void setClobParameter   (Parameter p, Argument arg, Object value)
   throws Exception
   {
      String logMsg = null;
      CLOB clob = null;
      OraclePreparedStatement ops = (OraclePreparedStatement) ps;
      Connection conn = ps.getConnection ();
      clob = createCLOB (conn, value.toString ());
      ops.setCLOB (p.pos.intValue (), clob);
      logMsg = "Wrote " + Long.toString (clob.length ()) + " bytes " + "into " +
               "parameter " + p.pos.toString ();
      logger.info (this,logMsg);
   }
   
   private CLOB createCLOB (Connection conn, String value) 
   throws Exception
   {
      CLOB clob = null;
      boolean useCache = true;
      clob = CLOB.createTemporary (conn, useCache, CLOB.DURATION_SESSION);
      temporaryLobs.add (clob);
      copyValueToClob (clob, value);
      return clob;
   }
   
   private void copyValueToClob (CLOB clob, String value)
   throws Exception
   {
      Writer writer = clob.getCharacterOutputStream ();
      writer.write (value);
      writer.flush ();
      writer.close ();
   }

   private void copyValueToBlob(BLOB blob, String value)
   throws Exception
   {
      ByteArrayInputStream bais = new ByteArrayInputStream (value.getBytes ());
      OutputStream out = blob.getBinaryOutputStream ();
      int chunkSize = blob.getChunkSize ();
      IOUtil.writeInputStreamToOutputStream (bais, out, chunkSize);
      out.flush ();
      out.close ();
   }
   
   private void freeTemporaryClobs ()
   {
      int size = temporaryLobs.size ();
      for (int i = 0; i < size; i++)
      {
         Object lob = temporaryLobs.remove (i);
         freeTemporaryLob (lob);
      }
   }
   
   private void freeTemporaryLob (Object lob)
   {
      try
      {
         if (lob != null)
         {
            if (lob instanceof CLOB)
            {
               CLOB clob = (CLOB) lob;
               clob.freeTemporary ();
            }
            else if (lob instanceof BLOB)
            {
               BLOB blob = (BLOB) lob;
               blob.freeTemporary ();
            }
         }
      }
      catch (Exception e) {}
   }
}
