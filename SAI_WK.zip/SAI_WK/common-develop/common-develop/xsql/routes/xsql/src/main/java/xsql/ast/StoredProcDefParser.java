package xsql.ast;

import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.w3c.dom.*;
import xsql.util.XMLUtils;


/**
 * This class parses an XML document and creates
 * a Java object structure that represents the contents
 * of the XML document.
 * <p>
 * The parse methods return the top level object
 * which represents the entire document.
 */
public class StoredProcDefParser extends DefaultHandler
{

   /**
    * Creates a new parser.
    */
   public StoredProcDefParser ()
   {
   }


   private List    elementContents = new Vector (2);
   private Stack   stack = new Stack ();
   private Locator locator;
   private int     numErrors = 0;
   private List    errors = new LinkedList ();
   private boolean validating = false;

   private Iterator contentIterator;
   private String   elementTag;
   private Object   elementNode;


   /**
    * Parses an XML document located in a file.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param fileName The name of the file.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (String  fileName,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (fileName, this);
      return getDocument ();
   }


   /**
    * Parses an XML document located in an input stream.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param is The input stream.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (InputStream  is,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (is, this);
      return getDocument ();
   }


   /**
    * Parses an XML document located in an input source.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param is The input source.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (InputSource  is,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (is, this);
      return getDocument ();
   }


   /**
    * Returns the number of error found while
    * parsing the XML docuement.
    * @return The number of error found.
    */
   public int getNumErrors ()
   {
      return numErrors;
   }


   /**
    * Returns a string description of each error found
    * while parsing of the XML docuement.
    * @return A list of <code>String</code>s.
    */
   public List getErrors ()
   {
      return errors;
   }


   /**
    * Returns an object which is Java representation
    * of the parsed XML document.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object getDocument ()
   {
      return elementContents.get (1);
   }


   private void getNextElement ()
   {
      if (contentIterator.hasNext ())
      {
         elementTag  = (String) contentIterator.next ();
         elementNode = contentIterator.next ();
      }
      else
      {
         elementTag = null;
      }
   }


   private String getAttribute (Attributes atts, String qName)
   {
      return atts.getValue (qName);
   }


   private Integer getIntegerAttribute (Attributes atts, String qName)
   {
      String text = atts.getValue (qName);
      Integer value = null;
      if (text != null)
      {
         try
         {
            value = Integer.valueOf (text);
         }
         catch (NumberFormatException e)
         {
            int line = locator.getLineNumber ();
            String message =
              "The value of the attribute \"" + qName
              + "\" must be a valid integer";
            writeError (line, "Error", message);
         }
      }
      return value;
   }


   private Double getDoubleAttribute (Attributes atts, String qName)
   {
      String text = atts.getValue (qName);
      Double value = null;
      if (text != null)
      {
         try
         {
            value = Double.valueOf (text);
         }
         catch (NumberFormatException e)
         {
            int line = locator.getLineNumber ();
            String message =
              "The value of the attribute \"" + qName
              + "\" must be a valid floating point number";
            writeError (line, "Error", message);
         }
      }
      return value;
   }


   public void setDocumentLocator(Locator locator)
   {
      this.locator = locator;
   }


   public InputSource resolveEntity (String publicId,
                                     String systemId )
   throws SAXException
   {
      String dtdName = "stored_proc.dtd";
      InputStream dtd = null;

      if (!validating && systemId.endsWith (".dtd"))
      {
         byte[] emptyArray = new byte [0];
         dtd = new ByteArrayInputStream (emptyArray);
         return new InputSource (dtd);
      }
      if (!systemId.endsWith (".dtd"))
      {
         return null;
      }
      ClassLoader cl = this.getClass ().getClassLoader ();
      dtd = cl.getResourceAsStream (dtdName);
      if (dtd == null)
      {
         throw new SAXException ("Unable to load DTD");
      }
      return new InputSource (dtd);
   }


   public void writeError (int line, String type, String message)
   {
      String msg = "Line: " + line + " " + type + ": " + message;
      errors.add (msg);
      numErrors += 1;
   }


   public void warning (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Warning", exception.getMessage ());
   }


   public void error (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Error", exception.getMessage ());
   }


   public void fatalError (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Fatal error", exception.getMessage ());
   }


   public void startElement(
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName,
         Attributes atts)
   throws SAXException
   {
      stack.push (elementContents);
      elementContents = new LinkedList ();
      stack.push (new AttributesImpl (atts));
      stack.push (new LocatorImpl (locator));
   }


   public void endElement(
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName)
   throws SAXException
   {
      Locator    loc  = (Locator) stack.pop ();
      Attributes atts = (Attributes) stack.pop ();
      Object     node;

      node = constructNode (localName, atts, elementContents, loc);
      elementContents = (List) stack.pop ();
      elementContents.add (localName);
      elementContents.add (node);
   }


   public void characters(
         char[] ch,
         int start,
         int length)
   throws SAXException
   {
      Object node = new String (ch, start, length);
      elementContents.add ("#CDATA");
      elementContents.add (node);
   }


   private Object getSubnode (Object node, Class c)
   {
      if (!(node instanceof List)) return null;

      Iterator i = ((List) node).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object subnode = i.next ();
         if (c.isInstance (subnode))
            return subnode;
      }
      return null;
   }


   private void appendToList (List l, Object elementNode, String tag)
   {
      Iterator i = ((List) elementNode).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (tag.equals (elementTag))
            l.add (node);
      }
   }


   private void appendToList (List l, Object elementNode, Class c)
   {
      Iterator i = ((List) elementNode).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (c.isInstance (node))
            l.add (node);
      }
   }


   private String getText (List content)
   {
      String result = "";

      Iterator i = content.iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (node instanceof String)
            result += node;
      }
      return result;
   }


   private Integer getInteger (List content)
   {
      String text = getText (content);
      try
      {
         return Integer.valueOf (text);
      }
      catch (NumberFormatException e)
      {
         int line = locator.getLineNumber ();
         String message = "The value \"" + text +"\" is not a valid integer";
         writeError (line, "Error", message);
      }
      return null;
   }


   private Double getDouble (List content)
   {
      String text = getText (content);
      try
      {
         return Double.valueOf (text);
      }
      catch (NumberFormatException e)
      {
         int line = locator.getLineNumber ();
         String message = "The value \"" + text +"\" is not a valid floating point number";
         writeError (line, "Error", message);
      }
      return null;
   }


   private Object constructNode (
           String     tag,
           Attributes atts,
           List       content,
           Locator    locator )
   {
      if ("stored-proc".equals (tag))
         return constructStoredProcDefNode (atts, content, locator);

      else if ("parameter".equals (tag))
         return constructParameterDefNode (atts, content, locator);

      return content;
   }


   private xsql.impl.StoredProcDefImpl constructStoredProcDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.StoredProcDefImpl  result = new xsql.impl.StoredProcDefImpl ();

      result.locator = locator;
      result.schemaName = getAttribute (atts, "schema-name");
      result.packageName = getAttribute (atts, "package-name");
      result.procedureName = getAttribute (atts, "procedure-name");
      result.recordTag = getAttribute (atts, "record-tag");
      result.recordSetTag = getAttribute (atts, "record-set-tag");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.returnParameter == null &&
             "return-parameter".equals (elementTag))
         {
            result.returnParameter =
              (xsql.impl.Parameter) getSubnode (elementNode, xsql.impl.Parameter.class);
            getNextElement ();
         }
         while ("parameter".equals (elementTag))
         {
            result.parameterList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.Parameter constructParameterDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.Parameter  result = new xsql.impl.Parameter ();

      result.locator = locator;
      result.pos = getIntegerAttribute (atts, "pos");
      result.name = getAttribute (atts, "name");
      result.mode = getAttribute (atts, "mode");
      result.jdbcType = getAttribute (atts, "jdbc-type");
      result.length = getIntegerAttribute (atts, "length");
      result.scale = getIntegerAttribute (atts, "scale");
      result.simpleDateFormat = getAttribute (atts, "simple-date-format");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }
}
