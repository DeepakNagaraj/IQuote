package xsql.ast;

import java.io.*;
import java.util.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.w3c.dom.*;
import xsql.util.XMLUtils;


/**
 * This class parses an XML document and creates
 * a Java object structure that represents the contents
 * of the XML document.
 * <p>
 * The parse methods return the top level object
 * which represents the entire document.
 */
public class XSQLParser extends DefaultHandler
{

   /**
    * Creates a new parser.
    */
   public XSQLParser ()
   {
   }


   private List    elementContents = new Vector (2);
   private Stack   stack = new Stack ();
   private Locator locator;
   private int     numErrors = 0;
   private List    errors = new LinkedList ();
   private boolean validating = false;

   private Iterator contentIterator;
   private String   elementTag;
   private Object   elementNode;


   /**
    * Parses an XML document located in a file.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param fileName The name of the file.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (String  fileName,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (fileName, this);
      return getDocument ();
   }


   /**
    * Parses an XML document located in an input stream.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param is The input stream.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (InputStream  is,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (is, this);
      return getDocument ();
   }


   /**
    * Parses an XML document located in an input source.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @param is The input source.
    * @param validating Indicates whether to use
    *        a validating parser.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object parse (InputSource  is,
                        boolean validating)
   throws Exception
   {
      SAXParserFactory factory = SAXParserFactory.newInstance ();
      factory.setNamespaceAware (true);
      this.validating = validating;
      factory.setValidating (validating);
      SAXParser parser;
      parser = factory.newSAXParser();
      parser.parse (is, this);
      return getDocument ();
   }


   /**
    * Returns the number of error found while
    * parsing the XML docuement.
    * @return The number of error found.
    */
   public int getNumErrors ()
   {
      return numErrors;
   }


   /**
    * Returns a string description of each error found
    * while parsing of the XML docuement.
    * @return A list of <code>String</code>s.
    */
   public List getErrors ()
   {
      return errors;
   }


   /**
    * Returns an object which is Java representation
    * of the parsed XML document.
    * <p>
    * If the parse fails because the XML document
    * is not valid,
    * then the value <code>null</code> is
    * returned.
    * If the document is valid, but it does not contain
    * constructs that can be bound to the
    * classes in this package, then
    * then the value <code>null</code> is
    * returned.
    * @return An object representing the XML document,
    * if successful; otherwise <code>null</code>.
    */
   public Object getDocument ()
   {
      return elementContents.get (1);
   }


   private void getNextElement ()
   {
      if (contentIterator.hasNext ())
      {
         elementTag  = (String) contentIterator.next ();
         elementNode = contentIterator.next ();
      }
      else
      {
         elementTag = null;
      }
   }


   private String getAttribute (Attributes atts, String qName)
   {
      return atts.getValue (qName);
   }


   private Integer getIntegerAttribute (Attributes atts, String qName)
   {
      String text = atts.getValue (qName);
      Integer value = null;
      if (text != null)
      {
         try
         {
            value = Integer.valueOf (text);
         }
         catch (NumberFormatException e)
         {
            int line = locator.getLineNumber ();
            String message =
              "The value of the attribute \"" + qName
              + "\" must be a valid integer";
            writeError (line, "Error", message);
         }
      }
      return value;
   }


   private Double getDoubleAttribute (Attributes atts, String qName)
   {
      String text = atts.getValue (qName);
      Double value = null;
      if (text != null)
      {
         try
         {
            value = Double.valueOf (text);
         }
         catch (NumberFormatException e)
         {
            int line = locator.getLineNumber ();
            String message =
              "The value of the attribute \"" + qName
              + "\" must be a valid floating point number";
            writeError (line, "Error", message);
         }
      }
      return value;
   }


   public void setDocumentLocator(Locator locator)
   {
      this.locator = locator;
   }


   public InputSource resolveEntity (String publicId,
                                     String systemId )
   throws SAXException
   {
      String dtdName = "xsql.dtd";
      InputStream dtd = null;

      if (!validating && systemId.endsWith (".dtd"))
      {
         byte[] emptyArray = new byte [0];
         dtd = new ByteArrayInputStream (emptyArray);
         return new InputSource (dtd);
      }
      if (!systemId.endsWith (".dtd"))
      {
         return null;
      }
      ClassLoader cl = this.getClass ().getClassLoader ();
      dtd = cl.getResourceAsStream (dtdName);
      if (dtd == null)
      {
         throw new SAXException ("Unable to load DTD");
      }
      return new InputSource (dtd);
   }


   public void writeError (int line, String type, String message)
   {
      String msg = "Line: " + line + " " + type + ": " + message;
      errors.add (msg);
      numErrors += 1;
   }


   public void warning (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Warning", exception.getMessage ());
   }


   public void error (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Error", exception.getMessage ());
   }


   public void fatalError (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      writeError (line, "Fatal error", exception.getMessage ());
   }


   public void startElement(
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName,
         Attributes atts)
   throws SAXException
   {
      stack.push (elementContents);
      elementContents = new LinkedList ();
      stack.push (new AttributesImpl (atts));
      stack.push (new LocatorImpl (locator));
   }


   public void endElement(
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName)
   throws SAXException
   {
      Locator    loc  = (Locator) stack.pop ();
      Attributes atts = (Attributes) stack.pop ();
      Object     node;

      node = constructNode (localName, atts, elementContents, loc);
      elementContents = (List) stack.pop ();
      elementContents.add (localName);
      elementContents.add (node);
   }


   public void characters(
         char[] ch,
         int start,
         int length)
   throws SAXException
   {
      Object node = new String (ch, start, length);
      elementContents.add ("#CDATA");
      elementContents.add (node);
   }


   private Object getSubnode (Object node, Class c)
   {
      if (!(node instanceof List)) return null;

      Iterator i = ((List) node).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object subnode = i.next ();
         if (c.isInstance (subnode))
            return subnode;
      }
      return null;
   }


   private void appendToList (List l, Object elementNode, String tag)
   {
      Iterator i = ((List) elementNode).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (tag.equals (elementTag))
            l.add (node);
      }
   }


   private void appendToList (List l, Object elementNode, Class c)
   {
      Iterator i = ((List) elementNode).iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (c.isInstance (node))
            l.add (node);
      }
   }


   private String getText (List content)
   {
      String result = "";

      Iterator i = content.iterator ();
      while (i.hasNext ())
      {
         String elementTag = (String) i.next ();
         Object node       = i.next ();
         if (node instanceof String)
            result += node;
      }
      return result;
   }


   private Integer getInteger (List content)
   {
      String text = getText (content);
      try
      {
         return Integer.valueOf (text);
      }
      catch (NumberFormatException e)
      {
         int line = locator.getLineNumber ();
         String message = "The value \"" + text +"\" is not a valid integer";
         writeError (line, "Error", message);
      }
      return null;
   }


   private Double getDouble (List content)
   {
      String text = getText (content);
      try
      {
         return Double.valueOf (text);
      }
      catch (NumberFormatException e)
      {
         int line = locator.getLineNumber ();
         String message = "The value \"" + text +"\" is not a valid floating point number";
         writeError (line, "Error", message);
      }
      return null;
   }


   private Object constructNode (
           String     tag,
           Attributes atts,
           List       content,
           Locator    locator )
   {
      if ("xsql".equals (tag))
         return constructXSQLNode (atts, content, locator);

      else if ("if".equals (tag))
         return constructIfStatementNode (atts, content, locator);

      else if ("then".equals (tag))
         return constructThenPartNode (atts, content, locator);

      else if ("else".equals (tag))
         return constructElsePartNode (atts, content, locator);

      else if ("while".equals (tag))
         return constructWhileStatementNode (atts, content, locator);

      else if ("var".equals (tag))
         return constructVarStatementNode (atts, content, locator);

      else if ("tag".equals (tag))
         return constructTagStatementNode (atts, content, locator);

      else if ("set".equals (tag))
         return constructSetStatementNode (atts, content, locator);

      else if ("eval".equals (tag))
         return constructEvalStatementNode (atts, content, locator);

      else if ("write".equals (tag))
         return constructWriteStatementNode (atts, content, locator);

      else if ("log".equals (tag))
         return constructLogStatementNode (atts, content, locator);

      else if ("xml".equals (tag))
         return constructXMLStatementNode (atts, content, locator);

      else if ("xml-attribute".equals (tag))
         return constructXMLAttributeNode (atts, content, locator);

      else if ("select".equals (tag))
         return constructSelectStatementNode (atts, content, locator);

      else if ("insert".equals (tag))
         return constructInsertStatementNode (atts, content, locator);

      else if ("update".equals (tag))
         return constructUpdateStatementNode (atts, content, locator);

      else if ("delete".equals (tag))
         return constructDeleteStatementNode (atts, content, locator);

      else if ("define-proc".equals (tag))
         return constructDefineProcNode (atts, content, locator);

      else if ("stored-proc".equals (tag))
         return constructStoredProcDefNode (atts, content, locator);

      else if ("parameter".equals (tag))
         return constructParameterDefNode (atts, content, locator);

      else if ("call-proc".equals (tag))
         return constructCallProcDefNode (atts, content, locator);

      else if ("arg".equals (tag))
         return constructArgumentDefNode (atts, content, locator);

      else if ("te-process".equals (tag))
         return constructTEProcessNode (atts, content, locator);

      else if ("call-te".equals (tag))
         return constructTECallNode (atts, content, locator);

      else if ("nwp-process".equals (tag))
         return constructNWPProcessNode (atts, content, locator);

      else if ("call-nwp-api".equals (tag))
         return constructNWPCallNode (atts, content, locator);

      else if ("import-class".equals (tag))
         return constructImportClassNode (atts, content, locator);

      else if ("doc".equals (tag))
         return constructDocumentStatementNode (atts, content, locator);

      else if ("throw".equals (tag))
         return constructThrowStatementNode (atts, content, locator);

      else if ("commit".equals (tag))
         return constructCommitStatementNode (atts, content, locator);

      else if ("rollback".equals (tag))
         return constructRollbackStatementNode (atts, content, locator);

      return content;
   }


   private XSQL constructXSQLNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      XSQL  result = new XSQL ();

      result.locator = locator;
      result.rootTag = getAttribute (atts, "root-tag");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.IfStatementImpl constructIfStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.IfStatementImpl  result = new xsql.impl.IfStatementImpl ();

      result.locator = locator;
      result.condition = getAttribute (atts, "condition");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.thenPart == null &&
             "then".equals (elementTag))
         {
            result.thenPart = (ThenPart) elementNode;
            getNextElement ();
         }
         if (result.elsePart == null &&
             "else".equals (elementTag))
         {
            result.elsePart = (ElsePart) elementNode;
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private ThenPart constructThenPartNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      ThenPart  result = new ThenPart ();

      result.locator = locator;
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private ElsePart constructElsePartNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      ElsePart  result = new ElsePart ();

      result.locator = locator;
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.WhileStatementImpl constructWhileStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.WhileStatementImpl  result = new xsql.impl.WhileStatementImpl ();

      result.locator = locator;
      result.condition = getAttribute (atts, "condition");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.VarStatementImpl constructVarStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.VarStatementImpl  result = new xsql.impl.VarStatementImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.expr = getAttribute (atts, "expr");
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.longExpr == null &&
             "expr".equals (elementTag))
         {
            result.longExpr = getText ((List) elementNode);
            getNextElement ();
         }
         if (result.longValue == null &&
             "value".equals (elementTag))
         {
            result.longValue = getText ((List) elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.TagStatementImpl constructTagStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.TagStatementImpl  result = new xsql.impl.TagStatementImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.expr = getAttribute (atts, "expr");
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.SetStatementImpl constructSetStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.SetStatementImpl  result = new xsql.impl.SetStatementImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.expr = getAttribute (atts, "expr");
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.longExpr == null &&
             "expr".equals (elementTag))
         {
            result.longExpr = getText ((List) elementNode);
            getNextElement ();
         }
         if (result.longValue == null &&
             "value".equals (elementTag))
         {
            result.longValue = getText ((List) elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.EvalStatementImpl constructEvalStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.EvalStatementImpl  result = new xsql.impl.EvalStatementImpl ();

      result.locator = locator;
      result.expr = getAttribute (atts, "expr");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.longExpr == null &&
             "expr".equals (elementTag))
         {
            result.longExpr = getText ((List) elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.WriteStatementImpl constructWriteStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.WriteStatementImpl  result = new xsql.impl.WriteStatementImpl ();

      result.locator = locator;
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.longValue == null &&
             "value".equals (elementTag))
         {
            result.longValue = getText ((List) elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.LogStatementImpl constructLogStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.LogStatementImpl  result = new xsql.impl.LogStatementImpl ();

      result.locator = locator;
      result.level = getAttribute (atts, "level");
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.longValue == null &&
             "value".equals (elementTag))
         {
            result.longValue = getText ((List) elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.XMLStatementImpl constructXMLStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.XMLStatementImpl  result = new xsql.impl.XMLStatementImpl ();

      result.locator = locator;
      result.tag = getAttribute (atts, "tag");
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.longValue == null &&
             "value".equals (elementTag))
         {
            result.longValue = getText ((List) elementNode);
            getNextElement ();
         }
         while ("xml-attribute".equals (elementTag))
         {
            result.attributes.add (elementNode);
            getNextElement ();
         }
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.XMLAttributeImpl constructXMLAttributeNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.XMLAttributeImpl  result = new xsql.impl.XMLAttributeImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.SelectStatementImpl constructSelectStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.SelectStatementImpl  result = new xsql.impl.SelectStatementImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.recordTag = getAttribute (atts, "record-tag");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.sql == null &&
             "sql".equals (elementTag))
         {
            result.sql = getText ((List) elementNode);
            getNextElement ();
         }
         while ("arg".equals (elementTag))
         {
            result.args.add (elementNode);
            getNextElement ();
         }
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.InsertStatementImpl constructInsertStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.InsertStatementImpl  result = new xsql.impl.InsertStatementImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.sql == null &&
             "sql".equals (elementTag))
         {
            result.sql = getText ((List) elementNode);
            getNextElement ();
         }
         while ("arg".equals (elementTag))
         {
            result.args.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.UpdateStatementImpl constructUpdateStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.UpdateStatementImpl  result = new xsql.impl.UpdateStatementImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.sql == null &&
             "sql".equals (elementTag))
         {
            result.sql = getText ((List) elementNode);
            getNextElement ();
         }
         while ("arg".equals (elementTag))
         {
            result.args.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.DeleteStatementImpl constructDeleteStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.DeleteStatementImpl  result = new xsql.impl.DeleteStatementImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.sql == null &&
             "sql".equals (elementTag))
         {
            result.sql = getText ((List) elementNode);
            getNextElement ();
         }
         while ("arg".equals (elementTag))
         {
            result.args.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.DefineProcImpl constructDefineProcNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.DefineProcImpl  result = new xsql.impl.DefineProcImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.definition == null &&
             "stored-proc".equals (elementTag))
         {
            result.definition = (xsql.impl.StoredProcDefImpl) elementNode;
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.StoredProcDefImpl constructStoredProcDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.StoredProcDefImpl  result = new xsql.impl.StoredProcDefImpl ();

      result.locator = locator;
      result.schemaName = getAttribute (atts, "schema-name");
      result.packageName = getAttribute (atts, "package-name");
      result.procedureName = getAttribute (atts, "procedure-name");
      result.recordTag = getAttribute (atts, "record-tag");
      result.recordSetTag = getAttribute (atts, "record-set-tag");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.returnParameter == null &&
             "return-parameter".equals (elementTag))
         {
            result.returnParameter =
              (xsql.impl.Parameter) getSubnode (elementNode, xsql.impl.Parameter.class);
            getNextElement ();
         }
         while ("parameter".equals (elementTag))
         {
            result.parameterList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.Parameter constructParameterDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.Parameter  result = new xsql.impl.Parameter ();

      result.locator = locator;
      result.pos = getIntegerAttribute (atts, "pos");
      result.name = getAttribute (atts, "name");
      result.mode = getAttribute (atts, "mode");
      result.jdbcType = getAttribute (atts, "jdbc-type");
      result.length = getIntegerAttribute (atts, "length");
      result.scale = getIntegerAttribute (atts, "scale");
      result.simpleDateFormat = getAttribute (atts, "simple-date-format");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.CallProc constructCallProcDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.CallProc  result = new xsql.impl.CallProc ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.defineProcName = getAttribute (atts, "define-proc-name");
      result.schemaName = getAttribute (atts, "schema-name");
      result.packageName = getAttribute (atts, "package-name");
      result.procedureName = getAttribute (atts, "procedure-name");
      result.recordTag = getAttribute (atts, "record-tag");
      result.recordSetTag = getAttribute (atts, "record-set-tag");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("arg".equals (elementTag))
         {
            result.args.add (elementNode);
            getNextElement ();
         }
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.Argument constructArgumentDefNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.Argument  result = new xsql.impl.Argument ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.pos = getIntegerAttribute (atts, "pos");
      result.simpleDateFormat = getAttribute (atts, "simple-date-format");
      result.timeZone = getAttribute (atts, "time-zone");
      result.dateType = getAttribute (atts, "date-type");
      result.jdbcType = getAttribute (atts, "jdbc-type");
      result.value = getAttribute (atts, "value");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.longValue == null &&
             "value".equals (elementTag))
         {
            result.longValue = getText ((List) elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.te.TEProcessImpl constructTEProcessNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.te.TEProcessImpl  result = new xsql.te.TEProcessImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.schema = getAttribute (atts, "schema");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.te.TECallImpl constructTECallNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.te.TECallImpl  result = new xsql.te.TECallImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.defineProcName = getAttribute (atts, "define-proc-name");
      result.schemaName = getAttribute (atts, "schema-name");
      result.packageName = getAttribute (atts, "package-name");
      result.procedureName = getAttribute (atts, "procedure-name");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("arg".equals (elementTag))
         {
            result.args.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.nwp.NWPProcessImpl constructNWPProcessNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.nwp.NWPProcessImpl  result = new xsql.nwp.NWPProcessImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.schema = getAttribute (atts, "schema");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("if".equals (elementTag)
          || "while".equals (elementTag)
          || "var".equals (elementTag)
          || "tag".equals (elementTag)
          || "set".equals (elementTag)
          || "eval".equals (elementTag)
          || "write".equals (elementTag)
          || "log".equals (elementTag)
          || "xml".equals (elementTag)
          || "query-statement".equals (elementTag)
          || "select".equals (elementTag)
          || "insert".equals (elementTag)
          || "update".equals (elementTag)
          || "delete".equals (elementTag)
          || "define-proc".equals (elementTag)
          || "call-proc".equals (elementTag)
          || "te-process".equals (elementTag)
          || "call-te".equals (elementTag)
          || "nwp-process".equals (elementTag)
          || "call-nwp-api".equals (elementTag)
          || "import-class".equals (elementTag)
          || "doc".equals (elementTag)
          || "throw".equals (elementTag)
          || "commit".equals (elementTag)
          || "rollback".equals (elementTag))
         {
            result.statementList.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.nwp.NWPCallImpl constructNWPCallNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.nwp.NWPCallImpl  result = new xsql.nwp.NWPCallImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.packageName = getAttribute (atts, "package-name");
      result.procedureName = getAttribute (atts, "procedure-name");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         while ("arg".equals (elementTag))
         {
            result.args.add (elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.ImportClassImpl constructImportClassNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.ImportClassImpl  result = new xsql.impl.ImportClassImpl ();

      result.locator = locator;
      result.name = getAttribute (atts, "name");
      result.javaName = getAttribute (atts, "java-name");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.DocumentStatementImpl constructDocumentStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.DocumentStatementImpl  result = new xsql.impl.DocumentStatementImpl ();

      result.locator = locator;
      result.action = getAttribute (atts, "action");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.ThrowStatementImpl constructThrowStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.ThrowStatementImpl  result = new xsql.impl.ThrowStatementImpl ();

      result.locator = locator;
      result.attrReason = getAttribute (atts, "reason");
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (result.elementReason == null &&
             "reason".equals (elementTag))
         {
            result.elementReason = getText ((List) elementNode);
            getNextElement ();
         }
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.CommitStatementImpl constructCommitStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.CommitStatementImpl  result = new xsql.impl.CommitStatementImpl ();

      result.locator = locator;
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }


   private xsql.impl.RollbackStatementImpl constructRollbackStatementNode (
          Attributes atts,
          List       content,
          Locator    locator )
   {
      xsql.impl.RollbackStatementImpl  result = new xsql.impl.RollbackStatementImpl ();

      result.locator = locator;
      contentIterator = content.iterator ();
      getNextElement ();
      while (elementTag != null)
      {
         if (elementTag != null)
            getNextElement ();
      }
      return result;
   }
}
