package xsql.impl;

import java.util.Iterator;
import java.util.List;
import java.io.StringWriter;


import xsql.StatementContext;
import xsql.XSQLRuntimeException;
import xsql.ast.StoredProcDef;
import xsql.ast.XMLWriter;
import xsql.impl.Parameter;
import xsql.util.ReflectionUtil;

public class StoredProcDefImpl extends StoredProcDef
{
   public StoredProcDefImpl ()
   {
   }
   
   public void check (StatementContext context)
   throws Exception
   {
      resolveInstanceVariables (context);

      if (returnParameter != null)
      {
         returnParameter.checkDefinition(context);
      }

      for (Iterator i = parameterList.iterator (); i.hasNext (); )
      {
         Parameter p = (Parameter) i.next ();
         p.checkDefinition(context);

         if (returnParameter != null && p.pos.intValue () == 1)
         {
            String errMsg =
              "Cannot define a non-return parameter with " +
              "a position equal to 1. ";
            throw new XSQLRuntimeException (errMsg);
         }
      }
   }
   
   public void resolveInstanceVariables (StatementContext context)
   throws Exception
   {
      this.packageName = context.resolveExpressions (this.packageName);
      this.procedureName = context.resolveExpressions (this.procedureName);
      this.schemaName = context.resolveExpressions (this.schemaName);
   }
   
   public Parameter getParameter (int position)
   {
      if (returnParameter != null && position == 1)
      {
         return returnParameter;
      }

      for (Iterator i = parameterList.iterator (); i.hasNext ();)
      {
         Parameter p = (Parameter) i.next ();
         if (p.pos.intValue() == position) return p;
      }
      return null;
   }


   public Parameter getParameter (String name)
   {
      if (returnParameter != null)
      {
         if (name.equals(returnParameter.name)) return returnParameter;
      }

      for (Iterator i = parameterList.iterator (); i.hasNext ();)
      {
         Parameter p = (Parameter) i.next ();
         if (name.equals (p.name)) return p;
      }
      return null;
   }
   
   public String getSQL ()
   {
      StringBuffer result = new StringBuffer("{");
      
      if (returnParameter != null)
         result.append("? = ");
      
      result.append("call ");
      
      if (schemaName != null)
      {
         result.append(schemaName);
         result.append(".");
      }
      if (packageName != null)
      {
         result.append(packageName);
         result.append(".");
      }
      
      result.append(procedureName);
      result.append("(");

      if (parameterList != null)
      {
         int numParams = parameterList.size ();

         for (int i = 1; i<= numParams; i++)
         {
            if (i > 1)
               result.append(",");
            result.append("?");
         }
      }
      result.append(")}");
      return result.toString ();
   }
   
   public List getParameterList ()
   {
      return parameterList;
   }
   
   public String toString ()
   {
      return ReflectionUtil.toString (this);
   }
   
   public String toXML ()
   throws Exception
   {
      StringWriter writer = new StringWriter ();
      xsql.ast.XMLWriter storedProcWriter = new XMLWriter (writer);
      storedProcWriter.write ((StoredProcDef) this);
      return writer.toString ();
   }
}
