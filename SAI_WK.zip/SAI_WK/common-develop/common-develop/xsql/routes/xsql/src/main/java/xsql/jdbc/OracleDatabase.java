package xsql.jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.StringWriter;

import oracle.jdbc.OracleResultSet;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import xsql.StatementContext;

import xsql.impl.Argument;
import xsql.impl.CallProc;
import xsql.impl.Parameter;
import xsql.impl.StoredProcDefImpl;
import xsql.util.DBUtil;
import xsql.ast.XMLWriter;
import xsql.ast.StoredProcDef;


public class OracleDatabase extends Database
{
   public OracleDatabase (StatementContext context)
   {
      super (context);
   }


   public void initialize ()
   throws Exception
   {
      if (pm == null)
          pm = new OracleParameterManager (context);
   }
   
   public void generateProcDefs (String procNamePattern,
                                 String procSchemaPattern,
                                 boolean includeSchemaInDefName)
   throws Exception
   {

      String logMsg = null;
      ResultSet rs = null;
      String procedureName;
      String schemaName;
      String packageName;
      String defFileName;

      try
      {
         DatabaseMetaData metaData = conn.getMetaData ();
         System.out.println ("procSchema = " + procSchemaPattern);
         System.out.println ("procName = " + procNamePattern);
         rs = metaData.getProcedures ("%", procSchemaPattern, procNamePattern);
                  
         while (rs.next ())
         {          
            packageName = rs.getString ("PROCEDURE_CAT");
            schemaName = rs.getString ("PROCEDURE_SCHEM");
            procedureName = rs.getString ("PROCEDURE_NAME");
            
            if (includeSchemaInDefName)
               defFileName = schemaName + "." + packageName + "." + procedureName;
            else
            {
               defFileName = packageName + "." + procedureName;
               schemaName = null;
            }
            
            
            StoredProcDefImpl def = getProcDefFromDatabase (schemaName,
                                                            packageName,
                                                            procedureName,
                                                            null,
                                                            null);
                        
            byte [] defAsByteArray = def.toXML ().getBytes ();
            
            System.out.println (defFileName);
            FileOutputStream out = new FileOutputStream (defFileName);
            out.write (defAsByteArray);
            out.close ();
        }
     }
     finally
     {
        DBUtil.closeResultSet (rs);
     }
  }      
  
   protected StoredProcDefImpl getProcDefFromDatabase (String schemaName,
                                                       String packageName,
                                                       String procedureName,
                                                       String recordSetTag,
                                                       String recordTag)
   throws Exception
   {
      StoredProcDefImpl def = null;
      String logMsg = null;
      ResultSet rs = null;

      try
      {
         def = new StoredProcDefImpl ();
         def.schemaName = schemaName;
         def.packageName = packageName;
         def.procedureName = procedureName;
         def.recordSetTag = recordSetTag;
         def.recordTag = recordTag;

         if (metaData == null)
         {
            metaData = conn.getMetaData ();
         }

         rs = metaData.getProcedureColumns (toNullOrUpperCase (packageName),
                                            toNullOrUpperCase (schemaName),
                                            toNullOrUpperCase (procedureName),
                                            "%");

         //System.out.println ("getting procedure def for: " +
         //  schemaName + "." + packageName + "." + procedureName);

         //displayProcDefs (procedureName, schemaName);

         int position = 1;

         while (rs.next ())
         {
            Parameter p = pm.createParameter (rs);
            p.pos = new Integer (position++);
            //System.out.println ("Parameter: " + p);

            if (p.name == null)
            {
               if (def.returnParameter == null)
               {
                  p.name = StoredProcResult.getReturnValueFieldName() ;
                  def.returnParameter = p;
               }
               else
                  // We have detected an overloaded method
                  break;
            }
            else
            {
               def.parameterList.add (p);
            }
         }

         logMsg =
           "Successfully obtained stored procedure definition from database:\n"
           + def.toString ();
         logger.debug (this, logMsg);

         return def;
      }
      finally
      {
         DBUtil.closeResultSet (rs);
      }
   }


   public void displayProcDefs (String procNamePattern,
                                String procSchemaPattern)
   throws Exception
   {

      String logMsg = null;
      ResultSet rs = null;
      String procedureName;
      String schemaName;
      String packageName;
      String defFileName;

      try
      {
         DatabaseMetaData metaData = conn.getMetaData ();
         System.out.println ("procSchema = " + procSchemaPattern);
         System.out.println ("procName = " + procNamePattern);

         rs = metaData.getProcedures ("%", procSchemaPattern, procNamePattern);
                  
         while (rs.next ())
         {          
            packageName = rs.getString ("PROCEDURE_CAT");
            schemaName = rs.getString ("PROCEDURE_SCHEM");
            procedureName = rs.getString ("PROCEDURE_NAME");
            
            System.out.println (schemaName + "." + packageName + "." + procedureName);
        }
     }
     finally
     {
        DBUtil.closeResultSet (rs);
     }
  }      


   private String toNullOrUpperCase (String s)
   {
      if (s == null)
         return null;
      else
         return s.toUpperCase ();
   }


   protected void setOutParametersInResult (CallProc cp,
                                            CallableStatement cs,
                                            StoredProcResult  result)
   throws Exception
   {
      Object value = null;
      Parameter returnParameter = cp.getReturnParameter ();

      if (returnParameter != null)
      {
         Argument arg = cp.getArgument (returnParameter.name);
         value = pm.getParameter (returnParameter, arg);
         if (value instanceof ResultSet)
         {
            ResultSet rs = (ResultSet) value;
            pm.setResultSet (rs);
            RecordSet recordSet = createRecordSet (cp.getRecordSetTag (),
                                                   cp.getRecordTag (),
                                                   rs);
            result.setRecordSet (recordSet);
            pm.setCallableStatement (cs);
         }
         else
         {
            result.setReturnValue (returnParameter.name, value);
         }
      }

      List parameterList = cp.getParameterList ();
      for (Iterator i = parameterList.iterator (); i.hasNext ();)
      {
         Parameter p = (Parameter) i.next ();
         Argument arg = cp.getArgument(p.name);
         value = pm.getParameter (p, arg);
         if (p.isOutParameter)
         {
            if (value instanceof ResultSet)
            {
               ResultSet rs = (ResultSet) value;
               pm.setResultSet (rs);
               RecordSet recordSet = createRecordSet (cp.getRecordSetTag (),
                                                      cp.getRecordTag (),
                                                      rs);
               result.setRecordSet (recordSet);
               pm.setCallableStatement (cs);
            }
            else
            {
               result.setFieldValue (p.name, value);
            }
         }
         else if (arg != null)
         {
            result.setFieldValue (p.name, value);
         }
      }
   }
}
