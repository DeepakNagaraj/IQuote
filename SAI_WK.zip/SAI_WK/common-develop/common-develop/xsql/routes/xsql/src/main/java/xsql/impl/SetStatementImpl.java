package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;
import xsql.expr.*;

public class SetStatementImpl extends SetStatement
{

   public void execute (StatementContext context)
   throws Exception
   {
      Object value = getValue (context);
      SymbolTable symbolTable = context.getSymbolTable ();
      boolean found = symbolTable.set (name, value);
      if (!found)
      {
         String message = "The variable " + name + " is not defined.";
         throw new XSQLRuntimeException (message);
      }
   }


   private Object getValue (StatementContext context)
   throws Exception
   {
      if (expr != null)
      {
         return context.evalExpression (expr);
      }
      else if (longExpr != null)
      {
         return context.evalExpression (longExpr);
      }
      else if (value != null)
      {
         return context.resolveExpressions (value);
      }
      else if (longValue != null)
      {
         return context.resolveExpressions (longValue);
      }
      else
      {
         return null;
      }
   }
}
