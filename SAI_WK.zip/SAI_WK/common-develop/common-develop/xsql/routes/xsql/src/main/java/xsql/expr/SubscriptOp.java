package xsql.expr;

import java.lang.reflect.*;

public class SubscriptOp extends IndexOp
{
   public Node subscript;

   public SubscriptOp (ExpressionContext context, Node subscript)
   {
      super (context);
      this.subscript = subscript;
   }


   public Object eval () throws Exception
   {
      Object value = left.eval ();
      int index = toInt (subscript.eval ());

      if (value instanceof ArrayInterface)
      {
         ArrayInterface a = (ArrayInterface) value;
         if (index >= 0 && index < a.length ())
            return a.getValue (index);
         else
         {
            String reason = "subscript out of bounds :: " + index;
            throw new ExpressionException (reason);
         }
      }
      else
      {
         throw new InvalidTypeException (value, "list");
      }
   }
}
