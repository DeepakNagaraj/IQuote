package xsql.ast;

import java.util.*;
import java.io.*;


/**
An NWP process is used to represent the beginning and end of a
sequence of NWP API calls.
The NWP process maintains the status of NWP-API calls inside the
NWP process by checking return codes.
The NWP process also handles the decision of whether or not
to commit or rollback all NWP APIs called inside the NWP process.
For example, while executing a statement list,
if one or more te calls are made and complete without error the
NWP process will issue a database commit.
However, if one or more NWP calls are made and an error occurs,
the NWP process will issue a rollback.
*/
abstract public class NWPProcess extends XSQLStatement
implements Serializable
{
   /**
    * Defines the name of the NWP process.
    */
   public String  name;
   /**
    * Defines the schema the NWP process runs in. If the schema is not
    * specified, the NWP process will run using the schema associated
    * with the database connection.
    */
   public String  schema;
   /**
    * Defines a list of XSQL statements to be executed as part
    * of the NWP process.
    */
   public List  statementList = new LinkedList ();


}
