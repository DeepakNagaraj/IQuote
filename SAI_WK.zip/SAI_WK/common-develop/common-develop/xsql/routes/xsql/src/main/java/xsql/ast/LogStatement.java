package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>log statement</i> writes a value to the XSQL log.
*/
abstract public class LogStatement extends XSQLStatement
implements Serializable
{
   /**
    * The level of severity to be associated with the log message.
    */
   public String  level;
   /**
    * The value to be written, given as an attribute.
    */
   public String  value;
   /**
    * The value to be written, given as a element.
    */
   public String  longValue;


}
