package xsql.impl;

import java.util.*;
import java.io.*;

import java.sql.*;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;

public class DefineProcImpl extends DefineProc
{
   private StatementContext context = null;
   

   public void execute (StatementContext context)
   throws Exception
   {
      this.context = context;
      definition.check (context);
      saveDefinition ();
   }


   public void saveDefinition ()
   throws Exception
   {
      context.getSymbolTable ().addGlobal (name, definition);
   }
}
