package xsql.nwp;

import xsql.*;

public class NWPProcessBreakException extends XSQLRuntimeException
{
   public NWPProcessBreakException ()
   {
      super ("NWPProcessBreakException");
   }
}
