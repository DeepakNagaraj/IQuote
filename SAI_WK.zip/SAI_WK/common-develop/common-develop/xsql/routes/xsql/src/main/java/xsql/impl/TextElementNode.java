package xsql.impl;

import java.util.*;
import java.io.*;
import xsql.ast.XMLAttribute;
import xsql.util.*;


public class TextElementNode extends XMLNode
implements Serializable
{
   String tag;
   Object value;
   List attributes;


   public TextElementNode (String tag, Object value)
   {
      this.tag = tag;
      this.value = value;
   }
   
   public TextElementNode (String tag, Object value, List attributes)
   {
      this.tag = tag;
      this.value = value;
      this.attributes = attributes;
   }


   public void write (int indent, Writer writer)
   throws Exception
   {
      if (value != null)
      {
         for (int i = 0; i < indent; i++)
            writer.write (" ");
         writer.write ("<" + tag);
         if (attributes != null)
         {
            for (int j = 0; j < attributes.size (); j++)
            {
               writer.write (" ");
               XMLAttributeImpl attr = (XMLAttributeImpl) attributes.get (j);
               attr.write (writer);
            }
         }
         writer.write (">");
         writer.write (XMLUtils.xmlEscape (value.toString()));
         writer.write ("</" + tag + ">");
         writer.write ("\n");
      }
   }
}
