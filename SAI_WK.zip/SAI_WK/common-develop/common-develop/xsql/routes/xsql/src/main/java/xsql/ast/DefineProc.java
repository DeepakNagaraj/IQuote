package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>define procedure statement</i> associates a name with
a database stored procedure definition.
The name can then be used to invoke the database stored procedure from
XSQL, using the <i>call procedure</i> statement.
*/
public class DefineProc extends XSQLStatement
implements Serializable
{
   /**
    * The name of the stored procedure being defined.
    */
   public String  name;
   /**
    * The stored procedure definition.
    */
   public xsql.impl.StoredProcDefImpl  definition;


}
