package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;
import xsql.expr.*;

public class VarStatementImpl extends VarStatement
{
   public void execute (StatementContext context)
   throws Exception
   {
      SymbolTable symbolTable = context.getSymbolTable ();
      if (symbolTable.symbolExistsInCurrentScope (name))
      {
         String message = "The variable " + name +
           " already exists in the current scope.";
         throw new XSQLRuntimeException (message);
      }
      else
      {
         Object value = getValue (context);
         symbolTable.add (name, value);
      }
   }


   private Object getValue (StatementContext context)
   throws Exception
   {
      if (expr != null)
      {
         return context.evalExpression (expr);
      }
      else if (longExpr != null)
      {
         return context.evalExpression (longExpr);
      }
      else if (value != null)
      {
         return context.resolveExpressions (value);
      }
      else if (longValue != null)
      {
         return context.resolveExpressions (longValue);
      }
      else
      {
         return null;
      }
   }
}
