package xsql.impl;

import java.io.*;
import java.sql.*;
import java.util.*;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
import xsql.impl.*;
import xsql.jdbc.RecordSet;

public class ForeachStatementImpl
{ 
   public static void processDependentStatements (StatementContext context,
                                                  RecordSet parentRs,
                                                  List statements) 
   throws Exception
   { 
      SymbolTable symbolTable = context.getSymbolTable ();
      ElementNode parentDoc = context.getCurrentXMLDocument();
      
      if (parentRs == null)
      {
         context.executeStatementList (statements);
      }
      else 
      {
         int recordCount = parentRs.length ();
         for (int i = 0; i < recordCount; i++)  
         { 
            RecordValue parentRecord = (RecordValue) parentRs.getValue (i);

            ElementNode myDoc = new ElementNode (parentRs.getComponentName ());
            myDoc.addRecordFields (parentRecord);
            parentDoc.addChild(myDoc);
            context.setCurrentXMLDocument(myDoc);

            symbolTable.beginScope ();
            symbolTable.add (parentRs.getComponentName (), parentRecord);

            try
            {
               context.executeStatementList(statements);
            }
            finally
            {
               symbolTable.endScope();
            }
         }
      }
   }
}     
