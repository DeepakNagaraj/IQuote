package xsql;

import java.util.*;
import java.io.*;


public class XSQLCompileTimeException extends XSQLException
{
   private List errors;


   public XSQLCompileTimeException (String message)
   {
      super (message);
   }


   public XSQLCompileTimeException (String message, List errors)
   {
      super (message);
      this.errors = errors;
   }


   public void setErrors (List errors)
   {
      this.errors = errors;
   }


   public List getErrors ()
   {
      return this.errors;
   }
}
