package xsql.jdbc;

import java.util.*;
import java.io.*;

public class RecordSetMetaData
{
   public List    parameters = new LinkedList();
   
   public int getColumnCount ()
   {
      return parameters.size ();
   }
}
