package xsql.te;

import xsql.util.*;
import xsql.*;
import xsql.impl.*;
import xsql.expr.*;
import xsql.ast.*;
import java.sql.*;
import java.util.*;
import xsql.jdbc.Database;
import xsql.jdbc.StoredProcResult;

public class TECallImpl extends TECall
{
   private StatementContext context;
   private SymbolTable      symtab;
   private Logger logger = null;
   private Database db;
   private StoredProcDefImpl def = null;

   private static TEErrorAnalyzer errorAnalyzer = new TEErrorAnalyzer ();


   public void execute (StatementContext context)
   throws Exception
   {
      this.context = context;
      logger = context.getLogger ();
      symtab = context.getSymbolTable ();
      db = context.getDatabase ();

      TEProcessStatus status = (TEProcessStatus) symtab.
        lookup (TEProcessImpl.TE_PROCESS_STATUS_NAME);
      if (status == null)
      {
         String reason =
           "TE Call is outside the scope of a TE Process Statement.";
         throw new XSQLRuntimeException (reason);
      }
      status.numTECallsMade += 1;

      String tag;
      if (packageName == null)
         tag = "call-te";
      else
         tag = "call-te-" + packageName;

      ElementNode myDoc = new ElementNode (tag);
      ElementNode parentDoc = context.getCurrentXMLDocument ();
      parentDoc.addChild (myDoc);

      CCAPIServices ccapiServices = status.ccapiServices;
      int rc = executeTECall (ccapiServices, myDoc, ccapiServices.getSchema ());

      List ccapiMessages = ccapiServices.readMessages ();

      ElementNode ccapiMessageDoc = convertCCAPIMessagesToXML (ccapiMessages);
      status.teMessages.add (ccapiMessageDoc);
      myDoc.addChild (ccapiMessageDoc);

      if (rc == 1)
      {
         String message =
           "The TE call returned the following warning message(s):\n" +
           ccapiServices.convertCCAPIMessagesToString (ccapiMessages);
         logger.warning (message);
      }
      if (rc > 1)
      {
         if (errorAnalyzer.isCriticalError (ccapiMessages))
         {
            String message =
              "A critical error occurred processing a TE call. " +
              "The TE call returned the following error message(s):\n" +
              ccapiServices.convertCCAPIMessagesToString (ccapiMessages);

            throw new TERuntimeException (message);
         }
         else
         {
            String message =
              "The TE call returned the following error message(s):\n" +
              ccapiServices.convertCCAPIMessagesToString (ccapiMessages);
            logger.error (message);
            status.teCallFailed = true;
            status.failedCall = this;
            throw new TEProcessBreakException ();
         }
      }
   }


   public int executeTECall (CCAPIServices ccapiServices,
                             ElementNode myDoc,
                             String schemaName)
   throws Exception
   {
      String message = "Calling ";
      if (defineProcName != null)
      {
         message += "defined procedure " + defineProcName;
      }
      else
      {
         if (schemaName != null)
            message += (schemaName + ".");
         message += (packageName + "." + procedureName);
      }
      logger.info (this, message);

      resolveInstanceVariables ();

      def = getStoredProcDef ();

      completeArgList (ccapiServices, args);

      CallProc cp = createCallProc (def);

      cp.checkArgList ();

      StoredProcResult result = db.makeCall (cp);

      if (name != null)
      {
         symtab.add (name, result);
      }

      myDoc.addRecordFields (result);
      Object returnValue = result.getFieldValue (def.returnParameter.name);
      message = "TE return value: " + returnValue.toString ();
      logger.info (this, message);
      int rc = Integer.parseInt (returnValue.toString ());
      return rc;
   }


   public StoredProcDefImpl getStoredProcDef ()
   throws Exception
   {
      if (def != null) return def;

      if (defineProcName == null)
      {
         def = db.getStoredProcDef (schemaName,
                                    packageName,
                                    procedureName,
                                    null,
                                    null);
      }
      else
      {
         def = (StoredProcDefImpl) symtab.lookupGlobal(defineProcName);

         if (def == null)
         {
            String reason = "A stored procedure named " + defineProcName
              + " is not defined.";
            throw new XSQLRuntimeException (reason);
         }
      }

      return def;
   }

   private void completeArgList (CCAPIServices ccapiServices,
                                 List args)
   throws Exception
   {
      for (Iterator i = def.parameterList.iterator (); i.hasNext ();)
      {
         Parameter p = (Parameter) i.next ();
         if (p.isInParameter)
         {
            Argument a = getArgument (p.name);

            if (a == null)
            {
               if ("LUW_ID".equals (p.name))
               {
                  String value = ccapiServices.getLuwId ();
                  args.add (new Argument ("LUW_ID", value));
               }
               else if ("LUW_SEQ".equals (p.name))
               {
                  String value = ccapiServices.getLuwSeq (true);
                  args.add (new Argument ("LUW_SEQ", value));
               }
            }
         }
      }
   }


   private Argument getArgument (String name)
   {
      for (Iterator i = args.iterator (); i.hasNext ();)
      {
         Argument a = (Argument) i.next ();
         if (name.equals (a.name)) return a;
      }
      return null;
   }


   private ElementNode convertCCAPIMessagesToXML (List messages)
   {
      ElementNode document = new ElementNode("ccapi-messages");

      for (Iterator i = messages.iterator (); i.hasNext (); )
      {
         CCAPITEMessage errorMsg = (CCAPITEMessage) i.next();
         TextElementNode errorMessageHeader =
           new TextElementNode("message", errorMsg.toString());
         document.addChild (errorMessageHeader);
      }
      return document;
   }


   private void logParameter (Parameter p)
   throws Exception
   {
      logger.debug (this, p.toString ());
      logger.debug (this, "---------");
   }

   private void resolveInstanceVariables ()
   throws Exception
   {
      this.packageName = context.resolveExpressions (this.packageName);
      this.procedureName = context.resolveExpressions (this.procedureName);
      this.schemaName = context.resolveExpressions (this.schemaName);
   }

   private CallProc createCallProc (StoredProcDefImpl def)
   throws Exception
   {
      CallProc cp = new CallProc ();
      cp.args = this.args;
      cp.defineProcName = this.defineProcName;
      cp.name = this.name;
      cp.packageName = this.packageName;
      cp.procedureName = this.procedureName;
      cp.schemaName = this.schemaName;
      cp.def = def;
      return cp;
   }
}
