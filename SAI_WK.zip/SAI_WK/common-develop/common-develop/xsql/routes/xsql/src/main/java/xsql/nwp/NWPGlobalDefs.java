package xsql.nwp;


public interface NWPGlobalDefs
{
}
