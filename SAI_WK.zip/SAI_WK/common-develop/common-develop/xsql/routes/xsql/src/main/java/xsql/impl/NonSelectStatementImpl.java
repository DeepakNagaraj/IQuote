package xsql.impl;

import xsql.XSQLRuntimeException;
import xsql.StatementContext;
import xsql.ast.QueryStatement;
import xsql.jdbc.Database;
import xsql.util.Logger;
 
public class NonSelectStatementImpl extends QueryStatement
{ 
   private StatementContext context = null;
   private Logger logger = null;
   private String logMsg = new String ();
   private Database db = null;

   public void execute (StatementContext context)
   throws Exception
   {  
      this.context = context;
      logger = context.getLogger ();
      db = context.getDatabase ();
      executeUpdate ();
   }
   

   public void executeUpdate  ()
   throws Exception
   {
      String    sql = context.resolveExpressions (this.sql);
      
      try
      {
         Integer rowsAffected = null;
         
         rowsAffected = db.executeUpdate (sql, args);
         
         logMsg = "Processed ";
         if (this instanceof InsertStatementImpl)
            logMsg += "insert";
         else if (this instanceof UpdateStatementImpl)
            logMsg += "update";
         else if (this instanceof DeleteStatementImpl)
            logMsg += "delete";
         
         logMsg += " statement named, " + name +
                   ", which affected "  + rowsAffected.intValue () + " row(s).";
         
         logger.info (this, logMsg);
      }
      catch (Exception e)
      {
         String reason =
           "Cannot process statement named, " + name +
           ", whose sql is given as: \n" + sql;
         throw new XSQLRuntimeException (reason, e);
      }
   }
}
