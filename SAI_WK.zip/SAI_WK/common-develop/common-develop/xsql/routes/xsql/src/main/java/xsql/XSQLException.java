package xsql;

import java.util.*;
import java.io.*;


public class XSQLException extends Exception
{
   public XSQLException(String message, Throwable cause)
   {
       super(message, cause);
   }
    
   public XSQLException (String message)
   {
      super (message);
   }
}
