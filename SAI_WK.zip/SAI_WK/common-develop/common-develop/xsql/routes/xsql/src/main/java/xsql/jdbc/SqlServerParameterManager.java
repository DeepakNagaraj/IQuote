package xsql.jdbc;

import xsql.StatementContext;
import xsql.impl.Argument;
import xsql.impl.Parameter;

public class SqlServerParameterManager extends ParameterManager
{

   public SqlServerParameterManager (StatementContext context)
   {
      super (context);
   }

   @Override
   protected Object getVarBinaryParameter (Parameter p, Argument arg)
   throws Exception
   {
      byte [] bytes = null;

      if (rs != null)
      {
         bytes = rs.getBytes(p.pos.intValue ());
         if (rs.wasNull ()) bytes = null;
      }
      else
      {
         bytes = cs.getBytes(p.pos.intValue ());
         if (cs.wasNull ()) bytes = null;
      }

      if (bytes == null)
         return null;
      else
         return new String (bytes);
   }

   @Override
   protected void  setVarBinaryParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setBlobParameter(p, arg, value);
   }

   @Override
   protected Object getLongVarbinaryParameter (Parameter p, Argument arg)
   throws Exception
   {
      byte [] bytes = null;

      if (rs != null)
      {
         bytes = rs.getBytes(p.pos.intValue ());
         if (rs.wasNull ()) bytes = null;
      }
      else
      {
         bytes = cs.getBytes(p.pos.intValue ());
         if (cs.wasNull ()) bytes = null;
      }

      if (bytes == null)
         return null;
      else
         return new String (bytes);
   }

   @Override
   protected void  setLongVarbinaryParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setBlobParameter(p, arg, value);
   }
}