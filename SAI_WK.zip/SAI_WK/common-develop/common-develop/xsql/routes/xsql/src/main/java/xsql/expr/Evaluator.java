package xsql.expr;

import java.util.*;

public class Evaluator implements ExpressionContext
{
   private SymbolTable symbolTable;


   public Evaluator (SymbolTable symbolTable)
   {
      this.symbolTable = symbolTable;
   }


   public SymbolTable getSymbolTable ()
   {
      return symbolTable;
   }


   public Object evaluate (String expr)
   throws Exception
   {
      Lex lex = new Lex ();
      lex.setInput (expr);
      Parser p = new Parser ();
      p.context = this;
      int numErrors = p.parse (lex);
      if (numErrors == 0)
         return p.compiledExpression.eval ();
      else
      {
         String message = "Syntax error(s) in expression: {" + expr +"}";
         for (Iterator i = p.errors.iterator (); i.hasNext (); )
         {
            String errorMessage = (String) i.next ();
            message += "\n   " + errorMessage;
         }
         throw new ExpressionException (message);
      }
   }


   public void evaluate (HashMap expressionTable)
   throws Exception
   {
      Set keySet = expressionTable.keySet();
      
      for (Iterator i = keySet.iterator(); i.hasNext();)
      {
         String expression = (String) i.next();
         expressionTable.put (expression, evaluate (expression));
      }
   }


   public boolean evaluateBooleanExpression (String expression)
   throws Exception
   {
      Object value = evaluate (expression); 
      if (value == null)
         throw new InvalidTypeException (value, "boolean");
      if (!(value instanceof Boolean))
         throw new InvalidTypeException (value, "boolean");
       return ((Boolean) value).booleanValue ();
   }
   

/*
   public static void main (String args [])
   throws Exception
   {
      if (args.length > 0)
         test (args [0]);
      else
      {
      //test ("a.b.c +'pple'");
      test ("21+5");
      test ("-21+5");
      test ("+21+5");
      test ("21+(5-3)");
      test ("'row'+(5-3)");
      test ("''+(5-3)");
      test ("2.11 +3 ");
      test ("5 >= 2.11");
      test ("'cat' < 'dog'");
      test ("'cat' < 'apple'");
      test ("'1'+'0' == 10");
      test ("b.help > 'a' && b.help <'c'");
      test ("'1'+'0' == 10 &&  1 == 0");
      test ("'1'+'0' == 10 &&  (1 == 0)");
      test ("'1'+'0' == 10 &&  !1 == 0");
      }
   }


   public static void test (String expr)
   throws Exception
   {
      Evaluator e = new Evaluator (new SymbolTable ());
      System.out.println (expr + "=" + e.evaluate (expr));
   }
*/
}
