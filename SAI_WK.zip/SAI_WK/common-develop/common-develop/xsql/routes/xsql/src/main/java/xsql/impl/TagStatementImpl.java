package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;
import xsql.expr.*;

public class TagStatementImpl extends TagStatement
{
   public void execute (StatementContext context)
   throws Exception
   {
      HashMap tags = context.getDocumentTags ();
      if (tags.containsKey (name))
      {
         String message = "The tag " + name +
           " already exists in the current scope.";
         throw new XSQLRuntimeException (message);
      }
      else
      {
         Object value = getValue (context);
         tags.put (name, value);      
      }
   }


   private Object getValue (StatementContext context)
   throws Exception
   {
      if (expr != null)
      {
         return context.evalExpression (expr);
      }
      else
      {
         return null;
      }
   }
}
