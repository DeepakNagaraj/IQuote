package xsql.expr;

public class ExpressionException extends Exception
{
   public ExpressionException (String message)
   {
      super (buildMessage (message));
   }


   public ExpressionException (String message, Throwable cause)
   {
      super (buildMessage (message), cause);
   }


   private static String buildMessage (String message)
   {
      return "Error occurred evaluating expression: " + message;
   }
}
