package xsql.expr;

public interface ExpressionContext
{
   public SymbolTable getSymbolTable ();
}
