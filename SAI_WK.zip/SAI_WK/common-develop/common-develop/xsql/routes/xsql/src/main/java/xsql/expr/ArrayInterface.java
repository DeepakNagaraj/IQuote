package xsql.expr;

public interface ArrayInterface
{
   public String getComponentName ();
   public int length ();
   public Object getValue (int index);
}
