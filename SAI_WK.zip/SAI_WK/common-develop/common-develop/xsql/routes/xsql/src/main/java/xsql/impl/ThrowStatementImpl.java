package xsql.impl;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
  
public class ThrowStatementImpl extends ThrowStatement
{ 
   public void execute (StatementContext context)
   throws Exception
   {
      String specifiedReason = getReason ();
      String resolvedReason = context.resolveExpressions (specifiedReason);
      throw new XSQLUserException (resolvedReason);
   }
   
   public String getReason ()
   {
      if (attrReason != null) 
         return attrReason;
      else
         return elementReason;
   }
}
