package xsql.impl;

import java.sql.*;
import java.lang.reflect.*;

import xsql.StatementContext;
import xsql.ast.ParameterDef;
import xsql.jdbc.Database;
import xsql.jdbc.ParameterManager;
import xsql.util.ReflectionUtil;

public class Parameter extends ParameterDef
{ 
   public String dbTypeName = null;
   public int sqlType;
   public boolean isInParameter = true;
   public boolean isOutParameter = true;
   public Integer precision;
   public Integer radix;
   
   public boolean definedFromDatabase = false; 
   
   public String toString ()
   {
      String result = ReflectionUtil.toString (this);
      
      return result;
   }
   
   public void checkDefinition(StatementContext context)
   throws Exception
   {
      if (mode.equalsIgnoreCase("in"))
      {
         isInParameter = true;
         isOutParameter = false;
      }
      else if (mode.equalsIgnoreCase("inout"))
      {
         isInParameter = true;
         isOutParameter = true;
      }
      else if (mode.equalsIgnoreCase("out"))
      {
         isInParameter = false;
         isOutParameter = true;
      }
      
      Database db = context.getDatabase ();
      ParameterManager pm = db.getParameterManager ();
      sqlType = pm.getSQLTypeFromJDBCType (jdbcType);
   }
}