package xsql.util;

import java.lang.reflect.*;
import java.util.Iterator;

public class ReflectionUtil
{
   private ReflectionUtil() { }
   
   public static String toString (Object instance)
   {
      StringBuffer result = new StringBuffer("\n");
      
      Class thisClass = instance.getClass ();
      String className = thisClass.getName ();
      java.lang.reflect.Field [] fields = thisClass.getFields ();
      for (int i = 0; i < fields.length; i++)
      {
         java.lang.reflect.Field field = (java.lang.reflect.Field) fields[i];
         String fieldName = field.getName();
         Object fieldValue = null;
         try
         { fieldValue = field.get (instance);
         } catch (Exception e) {}
         result.append (className);
         result.append (".");
         result.append (fieldName);
         result.append ("=");
         result.append (fieldValue);
         result.append ("\n");
      }
      
      return result.toString ();
   }
}
