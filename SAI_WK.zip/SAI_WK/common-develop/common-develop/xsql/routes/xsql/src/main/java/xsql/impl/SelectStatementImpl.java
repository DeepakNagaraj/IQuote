package xsql.impl;


import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
import xsql.jdbc.Database;
import xsql.jdbc.RecordSet;

public class SelectStatementImpl extends SelectStatement
{ 
   private StatementContext     context = null;
   private Logger                logger = null;
   private SymbolTable      symbolTable = null;
   private Database                  db = null;

   public void execute (StatementContext context)
   throws Exception
   {  
      this.context = context;
      logger = context.getLogger ();
      symbolTable = context.getSymbolTable();
      db = context.getDatabase ();
      
      ElementNode parentDoc = context.getCurrentXMLDocument();
      try
      {
         ElementNode myDoc = new ElementNode (name);
         parentDoc.addChild (myDoc);
         context.setCurrentXMLDocument (myDoc);

         RecordSet rs = executeQuery ();

         this.symbolTable.add (name, rs);

         ForeachStatementImpl.processDependentStatements 
           (context, rs, statementList);
      }
      finally
      {
         context.setCurrentXMLDocument (parentDoc);
      }
   }

   
   public RecordSet executeQuery ()
   throws Exception
   {
      String sql = null;
      try 
      { 
         sql = context.resolveExpressions (this.sql);
         
         return db.executeQuery (sql, name, recordTag, args);  
      }
      catch (Exception e)
      {
         String reason =
           "Cannot process select statement named, " + name +
           ", whose sql is given as: \n" + sql + ": " + e;
         throw new XSQLRuntimeException(reason, e);
      }
   }
}     
