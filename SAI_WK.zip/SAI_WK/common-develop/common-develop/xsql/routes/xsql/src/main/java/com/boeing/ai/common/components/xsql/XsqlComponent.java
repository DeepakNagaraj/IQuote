package com.boeing.ai.common.components.xsql;

import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;
import org.apache.camel.impl.UriEndpointComponent;
import org.apache.camel.util.CamelContextHelper;

import javax.sql.DataSource;

/**
 * Represents the component that manages {@link XsqlEndpoint}.
 */

public class XsqlComponent extends UriEndpointComponent {

    private DataSource ds;
    
    protected Endpoint createEndpoint(String uri, String remaining, Map<String, Object> parameters) throws Exception {
        DataSource dataSource;
        if (ds != null) {
            // prefer to use datasource set by setter
            dataSource = ds;
        } else {
            dataSource = CamelContextHelper.mandatoryLookup(getCamelContext(), remaining, DataSource.class);
        }
        
/*        if (ds==null || dataSource==null) {
            throw new IllegalArgumentException("Data source cannot be null for using XSQL component");
        }*/
                
        XsqlEndpoint endpoint = new XsqlEndpoint(uri, this, dataSource);
        setProperties(endpoint, parameters);
        return endpoint;
    }

    public XsqlComponent() {
        super(XsqlEndpoint.class);
    }

    public XsqlComponent(CamelContext context) {
        super(context, XsqlEndpoint.class);
    }

    public DataSource getDs() {
        return ds;
    }

    public void setDs(DataSource ds) {
        this.ds = ds;
    }

}
