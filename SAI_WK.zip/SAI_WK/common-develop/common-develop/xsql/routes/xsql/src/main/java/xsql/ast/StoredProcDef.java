package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

/**
A <i>stored procedure definition</i>defines the attributes of a stored
procedure defined in a database so that it can be called from XSQL.
*/
public class StoredProcDef
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;
   /**
    * The name of the database schema that contains the stored procedure.
    */
   public String  schemaName;
   /**
    * The name of the package that contains the stored procedure.
    */
   public String  packageName;
   /**
    * The name of the stored procedure as given in the data base.
    */
   public String  procedureName;
   /**
    * The value to be used for the surrounding XML document tag for each
    * record returned from the record set (if applicable).
    */
   public String  recordTag;
   /**
    * The tag to be used to wrap the returned record set (if applicable).
    */
   public String  recordSetTag;
   /**
    * The return type of the stored procedure, if the procedure is a function.
    */
   public xsql.impl.Parameter  returnParameter;
   /**
    * The parameters for the stored procedure.
    */
   public List  parameterList = new LinkedList ();


}
