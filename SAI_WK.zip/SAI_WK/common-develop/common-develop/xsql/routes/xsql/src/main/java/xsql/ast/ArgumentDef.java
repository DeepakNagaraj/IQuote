package xsql.ast;

import java.util.*;
import java.io.*;

import org.xml.sax.Locator;

/**
 * This class provides a Java representation of
 * the XML element <code>arg</code>.
 */
public class ArgumentDef
implements Serializable
{
   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;
   /**
    * The name of the parameter this argument is associated with.
    */
   public String  name;
   /**
    * The position of the parameter this argument is associated with.
    */
   public Integer  pos;
   /**
   *  The Java simple date format (see java.text.SimpleDateFormat) expression 
   *  that describes the input format used for specifying dates and times, and 
   *  also, the format which will be used for displaying them within the 
   *  generated XML document.
   */
   public String  simpleDateFormat;
   /**
   *  The ID of a time zone. (The valid values are the same values returned
   *  by calling the getAvailableIDs on the class java.util.TimeZone.)
   *  If specified, this time zone is passed to the jdbc driver,
   *  for Date, Time, and Timestamp arguments. The driver can then calculate
   *  the time taking into account a custom timezone.
   */
   public String  timeZone;
   /**
    * Deprecated!  use jdbcType instead
    *
    * Acceptable values are "Date", "Time", or "Timestamp" (case-insensitive)
    *
    * If given a simple date format, this will switch it from the default
    * of creating a java.sql.Date to creating a java.sql.Time or java.sql.Timestamp
    * as appropriate.  The default, if not specified, is to create a java.sql.Date.
    */
   public String  dateType;
   /**
    * This optional attribute can be used to specify the JDBC type
    * of the argument.  If specified, the appropriate set method will be called.
    * <p>
    * For example, if the argument is a timestamp, then this value should
    * be set as a TIMESTAMP.  The simple date format supplied will then be used
    * to parse the argument value into a JDBC compliant timestamp object.
    */
   public String  jdbcType;
   /**
    * The value to be used for the parameter when the call is made.
    * The value of an argument can contain embedded expressions.
    */
   public String  value;
   /**
    * The value, specified as an element instead of an attribute,
    * to be used for the parameter when the call is made.
    */
   public String  longValue;


}
