package xsql.expr;

public class IndexOp extends Node
{
   public String opSymbol;
   public Node left;

   public IndexOp (ExpressionContext context)
   {
      super (context);
   }


   public void setLeft (Node expr)
   {
      expr.parent = this;
      left = expr;
   }
}
