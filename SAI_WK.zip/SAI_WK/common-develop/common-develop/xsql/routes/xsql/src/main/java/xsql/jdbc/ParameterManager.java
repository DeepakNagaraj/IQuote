package xsql.jdbc;

import java.util.TimeZone;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.io.ByteArrayInputStream;
import java.io.StringReader;
import java.sql.CallableStatement;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import java.util.HashMap;

import xsql.StatementContext;
import xsql.impl.Parameter;
import xsql.impl.Argument;
import xsql.util.DateUtil;
import xsql.util.Logger;

public class ParameterManager
{
   protected HashMap jdbcTypes2SqlTypes = new HashMap ();  
   protected HashMap sqlTypes2JdbcTypes = new HashMap (); 
   protected HashMap parameterValues = new HashMap ();
   protected CallableStatement cs = null;
   protected PreparedStatement ps = null;
   protected ResultSet rs = null;
   protected StatementContext context = null;
   protected Logger logger = null;
   
   public ParameterManager (StatementContext context)
   {
      this.context = context;
      this.logger = context.getLogger ();
      initializeJdbcTypes2SqlTypes ();
      initializeSqlTypes2JdbcTypes ();
   }
   
   public void setCallableStatement (CallableStatement cs)
   {
      this.cs = cs;
      this.ps = (PreparedStatement) cs;
      this.rs = null;
   }
   
   public void setPreparedStatement (PreparedStatement ps)
   {
      this.cs = null;
      this.ps = ps;
      this.rs = null;
   }
   
   public void setResultSet (ResultSet rs)
   {
      this.cs = null;
      this.ps = null;
      this.rs = rs;
   }
   
   public void clear ()
   {
      this.cs = null;
      this.ps = null;
      this.rs = null;      
      this.parameterValues.clear ();
   }
   
   protected void initializeJdbcTypes2SqlTypes ()
   {
      if (jdbcTypes2SqlTypes.size () > 0) return;

      jdbcTypes2SqlTypes.put ("ARRAY", new Integer (Types.ARRAY));
      jdbcTypes2SqlTypes.put ("BIGINT", new Integer (Types.BIGINT));
      jdbcTypes2SqlTypes.put ("BINARY", new Integer (Types.BINARY));
      jdbcTypes2SqlTypes.put ("BIT", new Integer (Types.BIT));
      jdbcTypes2SqlTypes.put ("BLOB", new Integer (Types.BLOB));
      jdbcTypes2SqlTypes.put ("BOOLEAN", new Integer (Types.BOOLEAN));
      jdbcTypes2SqlTypes.put ("CHAR", new Integer (Types.CHAR));
      jdbcTypes2SqlTypes.put ("CLOB", new Integer (Types.CLOB));
      jdbcTypes2SqlTypes.put ("DATALINK", new Integer (Types.DATALINK));
      jdbcTypes2SqlTypes.put ("DATE", new Integer (Types.DATE));
      jdbcTypes2SqlTypes.put ("DECIMAL", new Integer (Types.DECIMAL));
      jdbcTypes2SqlTypes.put ("DISTINCT", new Integer (Types.DISTINCT));
      jdbcTypes2SqlTypes.put ("DOUBLE", new Integer (Types.DOUBLE));
      jdbcTypes2SqlTypes.put ("FLOAT", new Integer (Types.FLOAT));
      jdbcTypes2SqlTypes.put ("INTEGER", new Integer (Types.INTEGER));
      jdbcTypes2SqlTypes.put ("JAVA_OBJECT", new Integer (Types.JAVA_OBJECT));
      jdbcTypes2SqlTypes.put ("LONGNVARCHAR", new Integer (Types.LONGNVARCHAR));
      jdbcTypes2SqlTypes.put ("LONGVARBINARY", new Integer (Types.LONGVARBINARY));
      jdbcTypes2SqlTypes.put ("LONGVARCHAR", new Integer (Types.LONGVARCHAR));
      jdbcTypes2SqlTypes.put ("NCHAR", new Integer (Types.NCHAR));
      jdbcTypes2SqlTypes.put ("NCLOB", new Integer (Types.NCLOB));
      jdbcTypes2SqlTypes.put ("NULL", new Integer (Types.NULL));
      jdbcTypes2SqlTypes.put ("NUMERIC", new Integer (Types.NUMERIC));
      jdbcTypes2SqlTypes.put ("NVARCHAR", new Integer (Types.NVARCHAR));
      jdbcTypes2SqlTypes.put ("OTHER", new Integer (Types.OTHER));
      jdbcTypes2SqlTypes.put ("REAL", new Integer (Types.REAL));
      jdbcTypes2SqlTypes.put ("REF", new Integer (Types.REF));
      jdbcTypes2SqlTypes.put ("ROWID", new Integer (Types.ROWID));
      jdbcTypes2SqlTypes.put ("SMALLINT", new Integer (Types.SMALLINT));
      jdbcTypes2SqlTypes.put ("STRUCT", new Integer (Types.STRUCT));
      jdbcTypes2SqlTypes.put ("TIME", new Integer (Types.TIME));
      jdbcTypes2SqlTypes.put ("TIMESTAMP", new Integer (Types.TIMESTAMP));
      jdbcTypes2SqlTypes.put ("TINYINT", new Integer (Types.TINYINT));
      jdbcTypes2SqlTypes.put ("VARBINARY", new Integer (Types.VARBINARY));
      jdbcTypes2SqlTypes.put ("VARCHAR", new Integer (Types.VARCHAR));
      jdbcTypes2SqlTypes.put ("SQLXML", new Integer (Types.SQLXML));
   }
   
   protected void initializeSqlTypes2JdbcTypes ()
   {
      if (sqlTypes2JdbcTypes.size () > 0) return;
      
      sqlTypes2JdbcTypes.put (new Integer (Types.ARRAY), "ARRAY");
      sqlTypes2JdbcTypes.put (new Integer (Types.BIGINT), "BIGINT");
      sqlTypes2JdbcTypes.put (new Integer (Types.BINARY), "BINARY");
      sqlTypes2JdbcTypes.put (new Integer (Types.BIT), "BIT");
      sqlTypes2JdbcTypes.put (new Integer (Types.BLOB), "BLOB");
      sqlTypes2JdbcTypes.put (new Integer (Types.BOOLEAN), "BOOLEAN");
      sqlTypes2JdbcTypes.put (new Integer (Types.CHAR), "CHAR");
      sqlTypes2JdbcTypes.put (new Integer (Types.CLOB), "CLOB");
      sqlTypes2JdbcTypes.put (new Integer (Types.DATALINK), "DATALINK");
      sqlTypes2JdbcTypes.put (new Integer (Types.DATE), "DATE");
      sqlTypes2JdbcTypes.put (new Integer (Types.DECIMAL), "DECIMAL");
      sqlTypes2JdbcTypes.put (new Integer (Types.DISTINCT), "DISTINCT");
      sqlTypes2JdbcTypes.put (new Integer (Types.DOUBLE), "DOUBLE");
      sqlTypes2JdbcTypes.put (new Integer (Types.FLOAT), "FLOAT");
      sqlTypes2JdbcTypes.put (new Integer (Types.INTEGER), "INTEGER");
      sqlTypes2JdbcTypes.put (new Integer (Types.JAVA_OBJECT), "JAVA_OBJECT");
      sqlTypes2JdbcTypes.put (new Integer (Types.LONGNVARCHAR), "LONGNVARCHAR");
      sqlTypes2JdbcTypes.put (new Integer (Types.LONGVARBINARY), "LONGVARBINARY");
      sqlTypes2JdbcTypes.put (new Integer (Types.LONGVARCHAR), "LONGVARCHAR");
      sqlTypes2JdbcTypes.put (new Integer (Types.NCHAR), "NCHAR");
      sqlTypes2JdbcTypes.put (new Integer (Types.NCLOB), "NCLOB");
      sqlTypes2JdbcTypes.put (new Integer (Types.NULL), "NULL");
      sqlTypes2JdbcTypes.put (new Integer (Types.NUMERIC), "NUMERIC");
      sqlTypes2JdbcTypes.put (new Integer (Types.NVARCHAR), "NVARCHAR");
      sqlTypes2JdbcTypes.put (new Integer (Types.OTHER), "OTHER");
      sqlTypes2JdbcTypes.put (new Integer (Types.REAL), "REAL");
      sqlTypes2JdbcTypes.put (new Integer (Types.REF), "REF");
      sqlTypes2JdbcTypes.put (new Integer (Types.ROWID), "ROWID");
      sqlTypes2JdbcTypes.put (new Integer (Types.SMALLINT), "SMALLINT");
      sqlTypes2JdbcTypes.put (new Integer (Types.STRUCT), "STRUCT");
      sqlTypes2JdbcTypes.put (new Integer (Types.TIME), "TIME");
      sqlTypes2JdbcTypes.put (new Integer (Types.TIMESTAMP), "TIMESTAMP");
      sqlTypes2JdbcTypes.put (new Integer (Types.TINYINT), "TINYINT");
      sqlTypes2JdbcTypes.put (new Integer (Types.VARBINARY), "VARBINARY");
      sqlTypes2JdbcTypes.put (new Integer (Types.VARCHAR), "VARCHAR");
      sqlTypes2JdbcTypes.put (new Integer (Types.SQLXML), "SQLXML");
   } 
   
   
   protected Parameter createParameter (ResultSet rs)
   throws Exception
   {
      String name = rs.getString (4);
      String columnType = rs.getString (5);
      String dataType = rs.getString (6);
      String dbTypeName = rs.getString (7);
      String precision = rs.getString (8);
      String length = rs.getString (9);
      String scale = rs.getString (10);
      String radix = rs.getString (11);
      String nullable = rs.getString (12);

      Parameter p = new Parameter ();
      p.name = name;

      int colType = Integer.parseInt (columnType);
      p.isInParameter =
           colType == DatabaseMetaData.procedureColumnIn
        || colType == DatabaseMetaData.procedureColumnInOut;

      p.isOutParameter =
           colType == DatabaseMetaData.procedureColumnInOut
        || colType == DatabaseMetaData.procedureColumnOut
        || colType == DatabaseMetaData.procedureColumnReturn;

      p.mode = "";
      if (p.isInParameter)
         p.mode += "in";
      if (p.isOutParameter)
         p.mode += "out";

      p.sqlType = Integer.parseInt (dataType);
      p.jdbcType = getJDBCTypeFromSqlType (p.sqlType);

      p.dbTypeName = dbTypeName;

      if (length != null)
         p.length = new Integer (length);

      if (scale != null)
         p.scale = new Integer (scale);

      if (precision != null)
         p.precision = new Integer (precision);

      if (radix != null)
         p.radix = new Integer (radix);
      
      p.definedFromDatabase = true;

      return p;
   }

   public String getJDBCTypeFromSqlType (int sqlType)
   {
      String jdbcType = (String) sqlTypes2JdbcTypes.get (new Integer (sqlType));
      if (jdbcType == null)
         return "Type not found";
      else
         return jdbcType;
   }


   public int getSQLTypeFromJDBCType (String jdbcType)
   throws Exception
   {
      Integer sqlType = (Integer) jdbcTypes2SqlTypes.get (jdbcType);
      if (sqlType == null)
      {
         throw new IllegalArgumentException
            ("Unsupported JDBC type : " + jdbcType);
      }
      else
         return sqlType.intValue ();
   }
   
   protected void setInParameter (Parameter p,
                                  Argument arg,
                                  Object   value)
   throws Exception
   {
      parameterValues.put (p, value);

      if (value == null)
      {
         setNullParameter (p, arg, value);
      }
      else if ("ARRAY".equalsIgnoreCase (p.jdbcType))
      {
         setArrayParameter (p, arg, value);
      }
      else if ("BIGINT".equalsIgnoreCase (p.jdbcType))
      {
         setBigIntParameter (p, arg, value);
      }
      else if ("BINARY".equalsIgnoreCase (p.jdbcType))
      {
         setBinaryParameter (p, arg, value);
      }
      else if ("BIT".equalsIgnoreCase (p.jdbcType))
      {
         setBitParameter (p, arg, value);
      }
      else if ("BLOB".equalsIgnoreCase (p.jdbcType))
      {
         setBlobParameter (p, arg, value);
      }
      else if ("BOOLEAN".equalsIgnoreCase (p.jdbcType))
      {
         setBooleanParameter (p, arg, value);
      }
      else if ("CHAR".equalsIgnoreCase (p.jdbcType))
      {
         setCharParameter (p, arg, value);
      }
      else if ("CLOB".equalsIgnoreCase (p.jdbcType))
      {
         setClobParameter (p, arg, value);
      }
      else if ("DATALINK".equalsIgnoreCase (p.jdbcType))
      {
         setDatalinkParameter (p, arg, value);
      }
      else if ("DATE".equalsIgnoreCase (p.jdbcType))
      {
         setDateParameter (p, arg, value);
      }
      else if ("DECIMAL".equalsIgnoreCase (p.jdbcType))
      {
         setDecimalParameter (p, arg, value);
      }
      else if ("DISTINCT".equalsIgnoreCase (p.jdbcType))
      {
         setDistinctParameter (p, arg, value);
      }
      else if ("DOUBLE".equalsIgnoreCase (p.jdbcType))
      {
         setDoubleParameter (p, arg, value);
      }
      else if ("FLOAT".equalsIgnoreCase (p.jdbcType))
      {
         setFloatParameter (p, arg, value);
      }
      else if ("INTEGER".equalsIgnoreCase (p.jdbcType))
      {
         setIntegerParameter (p, arg, value);
      }
      else if ("JAVA_OBJECT".equalsIgnoreCase (p.jdbcType))
      {
         setJavaObjectParameter (p, arg, value);
      }
      else if ("LONGNVARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         setLongNVarcharParameter (p, arg, value);
      }
      else if ("LONGVARBINARY".equalsIgnoreCase (p.jdbcType))
      {
         setLongVarbinaryParameter (p, arg, value);
      }
      else if ("LONGVARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         setLongVarcharParameter (p, arg, value);
      }
      else if ("NCHAR".equalsIgnoreCase (p.jdbcType))
      {
         setNCharParameter (p, arg, value);
      }
      else if ("NCLOB".equalsIgnoreCase (p.jdbcType))
      {
         setNClobParameter (p, arg, value);
      }
      else if ("NULL".equalsIgnoreCase (p.jdbcType))
      {
         setNullParameter (p, arg, value);
      }
      else if ("NUMERIC".equalsIgnoreCase (p.jdbcType))
      {
         setNumericParameter (p, arg, value);
      }
      else if ("NVARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         setNVarcharParameter (p, arg, value);
      }
      else if ("OTHER".equalsIgnoreCase (p.jdbcType))
      {
         setOtherParameter (p, arg, value);
      }
      else if ("REAL".equalsIgnoreCase (p.jdbcType))
      {
         setRealParameter (p, arg, value);
      }
      else if ("REF".equalsIgnoreCase (p.jdbcType))
      {
         setRefParameter (p, arg, value);
      }
      else if ("ROWID".equalsIgnoreCase (p.jdbcType))
      {
         setRowIdParameter (p, arg, value);
      }
      else if ("SMALLINT".equalsIgnoreCase (p.jdbcType))
      {
         setSmallIntParameter (p, arg, value);
      }
      else if ("STRUCT".equalsIgnoreCase (p.jdbcType))
      {
         setStructParameter (p, arg, value);
      }
      else if ("TIME".equalsIgnoreCase (p.jdbcType))
      {
         setTimeParameter (p, arg, value);
      }
      else if ("TIMESTAMP".equalsIgnoreCase (p.jdbcType))
      {
         setTimestampParameter (p, arg, value);
      }
      else if ("TINYINT".equalsIgnoreCase (p.jdbcType))
      {
         setTinyIntParameter (p, arg, value);
      }
      else if ("VARBINARY".equalsIgnoreCase (p.jdbcType))
      {
         setVarBinaryParameter (p, arg, value);
      }
      else if ("VARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         setVarcharParameter (p, arg, value);
      }
      else if ("SQLXML".equalsIgnoreCase (p.jdbcType))
      {
         setSqlXmlParameter (p, arg, value);
      }
      else
      {
         throw new IllegalArgumentException ("Unsupported JDBC type.");
      }
   }
   
   protected void  setArrayParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
     
                                      
   protected void  setBigIntParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
     
   
   protected void  setBinaryParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
     
                                       
   protected void  setBitParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
     
   
   protected void  setBlobParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      if (value instanceof String)
      {
         String s = (String) value;
         ByteArrayInputStream bais = new ByteArrayInputStream(s.getBytes());
         ps.setBlob (p.pos.intValue (), bais);
      }
      else
      {
         throw new UnsupportedOperationException ();
      }
   }
     
                                     
   protected void  setBooleanParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
       
                                        
   protected void  setCharParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
     
                                     
   protected void  setClobParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      if (value instanceof String)
      {
         String s = (String) value;
         StringReader sr = new StringReader (s);
         ps.setClob (p.pos.intValue (), sr);
      }
      else
      {
         throw new UnsupportedOperationException ();
      }
   }
    
                                     
   protected void  setDatalinkParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
    
                                         
   protected void  setDateParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      String simpleDateFormat = getSimpleDateFormat (p, arg);
      Calendar cal = getCalendar (p, arg);
      
      if (simpleDateFormat == null)
      {
         setStringParameter (p, arg, value);
      }
      else
      {
         String s = value.toString ();
         if ("".equals(s.trim ()))
         {
            setNullParameter (p, arg, value);
            
         }
         else
         {
            java.util.Date d = DateUtil.convertStringToDate (s,simpleDateFormat);
            java.sql.Date sqlDate = new java.sql.Date (d.getTime ());
            if (cal == null)
            {
               ps.setDate (p.pos.intValue (), sqlDate);
            }
            else
            {
               ps.setDate (p.pos.intValue (), sqlDate, cal);
            }
         }
      }
   }
   
   
   protected void  setDecimalParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
   
   
   protected void setDistinctParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();      
   }
   
   
   protected void  setDoubleParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
                                       

   protected void  setFloatParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }


   protected void  setIntegerParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
  
   
   protected void  setJavaObjectParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();  
   }


   protected void setLongNVarcharParameter(Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }


   protected void  setLongVarbinaryParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();  
   }
   
   
   protected void  setLongVarcharParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
  

   protected void setNCharParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }


   protected void setNClobParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setClobParameter (p, arg, value);
   }


   protected void  setNullParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      ps.setNull (p.pos.intValue (), p.sqlType);   
   }


   protected void setNVarcharParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
   

   protected void setNumericParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }


   protected void setOtherParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException (); 
   }
   
   
   protected void setRealParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
   

   protected void setRefParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException (); 
   }
   

   protected void setRowIdParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }


   protected void setSmallIntParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
   
   
   protected void setStructParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException (); 
   }
   
   
   protected void setTimeParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      String simpleDateFormat = getSimpleDateFormat (p, arg);
      Calendar cal = getCalendar (p, arg);

      if (simpleDateFormat == null)
      {
         setStringParameter (p, arg, value);
      }
      else
      {
         String s = value.toString ();
         if ("".equals(s.trim ()))
         {
            setNullParameter (p, arg, value);
         }
         else
         {
            java.util.Date d = DateUtil.convertStringToDate (s,simpleDateFormat);
            java.sql.Time t = new java.sql.Time (d.getTime ());
            if (cal == null)
            {
               ps.setTime (p.pos.intValue (), t);
            }
            else
            {
               ps.setTime (p.pos.intValue (), t, cal);
            }
         }
      }
   }
   
   protected void setTimestampParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      String simpleDateFormat = getSimpleDateFormat (p, arg);
      Calendar cal = getCalendar (p, arg);
      
      if (simpleDateFormat == null)
      {
         setStringParameter (p, arg, value);
      }
      else
      {
         String s = value.toString ();
         if ("".equals(s.trim ()))
         {
            setNullParameter (p, arg, value);
         }
         else
         {
            java.util.Date d = DateUtil.convertStringToDate (s, simpleDateFormat);
            java.sql.Timestamp t = new java.sql.Timestamp (d.getTime ());
            if (cal == null)
            {
               ps.setTimestamp (p.pos.intValue (), t);
            }
            else
            {
               ps.setTimestamp (p.pos.intValue (), t, cal);
            }
         }
      }
   }
   
   protected void setTinyIntParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
   
   protected void setVarBinaryParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }

   
   protected void setVarcharParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      setStringParameter (p, arg, value);
   }
  
   protected void setStringParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      ps.setString (p.pos.intValue (), value.toString ());  
   }

   protected void setSqlXmlParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
   
   protected void setDatabaseSpecificParameter (Parameter p, Argument arg, Object value)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
   
   
   protected String getSimpleDateFormat (Parameter p, Argument arg)
   {
      String simpleDateFormat = null;
      
      if (arg != null)
         simpleDateFormat = arg.simpleDateFormat;
      
      if (simpleDateFormat == null)
      {
         simpleDateFormat = p.simpleDateFormat;
      }
      
      return simpleDateFormat;
   }
   
   
   protected Calendar getCalendar (Parameter p, Argument arg)
   throws Exception
   {
      Calendar cal = null;
      String timeZoneID = null;
      
      if (arg != null)
         timeZoneID = arg.timeZone;

      if (timeZoneID != null)
      {
         TimeZone tz = TimeZone.getTimeZone (timeZoneID);
         cal = new GregorianCalendar (tz);
      }
      return cal;
   }
   
   
   protected void setOutParameter (Parameter  p)
   throws Exception
   {
      if (("DECIMAL".equalsIgnoreCase (p.jdbcType)) ||
          ("DOUBLE".equalsIgnoreCase (p.jdbcType)) ||
          ("FLOAT".equalsIgnoreCase (p.jdbcType)) ||
          ("NUMERIC".equalsIgnoreCase (p.jdbcType)) ||
          ("REAL".equalsIgnoreCase (p.jdbcType)))
      {
         setNumericOutParameter (p);
      }
      else
      {
         cs.registerOutParameter(p.pos.intValue (), p.sqlType);
      }
   }
   
   
   protected void setNumericOutParameter (Parameter  p)
   throws Exception
   {
      if (p.scale == null)
      {
         cs.registerOutParameter(p.pos.intValue (), p.sqlType);
      }
      else
      {
         int scale = p.scale.intValue();
         cs.registerOutParameter (p.pos.intValue (), p.sqlType, scale);
      }
   }
   
   protected Object getParameter (Parameter p)
   throws Exception
   {
      return getParameter (p, null);
   } 
   

   protected Object getParameter (Parameter p,
                                  Argument arg)
   throws Exception
   {
      if (p.isOutParameter)
         return getOutParameter (p, arg);
      else
         return parameterValues.get (p);
   }


   protected Object getOutParameter (Parameter p,
                                     Argument arg)
   throws Exception
   {
      if      ("ARRAY".equalsIgnoreCase (p.jdbcType))
      {
         return getArrayParameter (p, arg);
      }
      else if ("BIGINT".equalsIgnoreCase (p.jdbcType))
      {
         return getBigIntParameter (p, arg);
      }
      else if ("BINARY".equalsIgnoreCase (p.jdbcType))
      {
         return getBinaryParameter (p, arg);
      }
      else if ("BIT".equalsIgnoreCase (p.jdbcType))
      {
         return getBitParameter (p, arg);
      }
      else if ("BLOB".equalsIgnoreCase (p.jdbcType))
      {
         return getBlobParameter (p, arg);
      }
      else if ("BOOLEAN".equalsIgnoreCase (p.jdbcType))
      {
         return getBooleanParameter (p, arg);
      }
      else if ("CHAR".equalsIgnoreCase (p.jdbcType))
      {
         return getCharParameter (p, arg);
      }
      else if ("CLOB".equalsIgnoreCase (p.jdbcType))
      {
         return getClobParameter (p, arg);
      }
      else if ("DATALINK".equalsIgnoreCase (p.jdbcType))
      {
         return getDatalinkParameter (p, arg);
      }
      else if ("DATE".equalsIgnoreCase (p.jdbcType))
      {
         return getDateParameter (p, arg);
      }
      else if ("DECIMAL".equalsIgnoreCase (p.jdbcType))
      {
         return getDecimalParameter (p, arg);
      }
      else if ("DISTINCT".equalsIgnoreCase (p.jdbcType))
      {
         return getDistinctParameter (p, arg);
      }
      else if ("DOUBLE".equalsIgnoreCase (p.jdbcType))
      {
         return getDoubleParameter (p, arg);
      }
      else if ("FLOAT".equalsIgnoreCase (p.jdbcType))
      {
         return getFloatParameter (p, arg);
      }
      else if ("INTEGER".equalsIgnoreCase (p.jdbcType))
      {
         return getIntegerParameter (p, arg);
      }
      else if ("JAVA_OBJECT".equalsIgnoreCase (p.jdbcType))
      {
         return getJavaObjectParameter (p, arg);
      }
      else if ("LONGNVARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         return getLongNVarcharParameter (p, arg);
      }
      else if ("LONGVARBINARY".equalsIgnoreCase (p.jdbcType))
      {
         return getLongVarbinaryParameter (p, arg);
      }
      else if ("LONGVARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         return getLongVarcharParameter (p, arg);
      }
      else if ("NCHAR".equalsIgnoreCase (p.jdbcType))
      {
         return getNCharParameter (p, arg);
      }
      else if ("NCLOB".equalsIgnoreCase (p.jdbcType))
      {
         return getNClobParameter (p, arg);
      }
      else if ("NULL".equalsIgnoreCase (p.jdbcType))
      {
         return getNullParameter (p, arg);
      }
      else if ("NUMERIC".equalsIgnoreCase (p.jdbcType))
      {
         return getNumericParameter (p, arg);
      }
      else if ("NVARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         return getNVarcharParameter (p, arg);
      }
      else if ("OTHER".equalsIgnoreCase (p.jdbcType))
      {
         return getOtherParameter (p, arg);
      }
      else if ("REAL".equalsIgnoreCase (p.jdbcType))
      {
         return getRealParameter (p, arg);
      }
      else if ("REF".equalsIgnoreCase (p.jdbcType))
      {
         return getRefParameter (p, arg);
      }
      else if ("ROWID".equalsIgnoreCase (p.jdbcType))
      {
         return getRowIdParameter (p, arg);
      }
      else if ("SMALLINT".equalsIgnoreCase (p.jdbcType))
      {
         return getSmallIntParameter (p, arg);
      }
      else if ("STRUCT".equalsIgnoreCase (p.jdbcType))
      {
         return getStructParameter (p, arg);
      }
      else if ("TIME".equalsIgnoreCase (p.jdbcType))
      {
         return getTimeParameter (p, arg);
      }
      else if ("TIMESTAMP".equalsIgnoreCase (p.jdbcType))
      {
         return getTimestampParameter (p, arg);
      }
      else if ("TINYINT".equalsIgnoreCase (p.jdbcType))
      {
         return getTinyIntParameter (p, arg);
      }
      else if ("VARBINARY".equalsIgnoreCase (p.jdbcType))
      {
         return getVarBinaryParameter (p, arg);
      }
      else if ("VARCHAR".equalsIgnoreCase (p.jdbcType))
      {
         return getVarcharParameter (p, arg);
      }
      else if ("SQLXML".equalsIgnoreCase (p.jdbcType))
      {
         return getSqlXmlParameter (p, arg);
      }
      else
      {
         return getDatabaseSpecificParameter (p, arg);
      }
   }
   
   protected Object getArrayParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
                                         
   protected Object getBigIntParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }     
      
   protected Object getBinaryParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
     
                                       
   protected Object getBitParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
     
   
   protected Object getBlobParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
     
                                     
   protected Object getBooleanParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
       
                                        
   protected Object getCharParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
     
                                     
   protected Object getClobParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
    
                                     
   protected Object getDatalinkParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }
    
                                         
   protected Object getDateParameter (Parameter p, Argument arg)
   throws Exception
   {
      String simpleDateFormat = getSimpleDateFormat (p, arg);
      
      if (simpleDateFormat == null)
      {
         return getString (p, arg);
      }
      else
      {
         java.util.Date d = (java.util.Date) getDate (p.pos.intValue ());
         if (d == null)
            return null;
         else
            return DateUtil.convertDateToString(d, simpleDateFormat);
      }
   }
   
   private java.sql.Date getDate (int index)
   throws Exception
   {
      java.sql.Date d = null;
      
      if (rs != null)
      {
         d = rs.getDate (index);
         if (rs.wasNull ()) d = null;
      }
      else
      {
         d = cs.getDate (index);
         if (cs.wasNull ()) d = null;
      }
      
      return d;
   }
   
   protected Object getDecimalParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
   
   
   protected Object getDistinctParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();      
   }
   
   
   protected Object getDoubleParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
                                       

   protected Object getFloatParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }


   protected Object getIntegerParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
  
   
   protected Object getJavaObjectParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();  
   }


   private Object getLongNVarcharParameter(Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }


   protected Object getLongVarbinaryParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }


   protected Object getLongVarcharParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
  

   protected Object getNCharParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }


   protected Object getNClobParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }


   protected Object getNullParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);   
   }
   

   protected Object getNumericParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }


   protected Object getNVarcharParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }


   protected Object getOtherParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException (); 
   }
   
   
   protected Object getRealParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
   

   protected Object getRefParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException (); 
   }
   
   
   protected Object getSmallIntParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
   
   
   protected Object getStructParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException (); 
   }
   
   
   protected Object getTimeParameter (Parameter p, Argument arg)
   throws Exception
   {
      String simpleDateFormat = getSimpleDateFormat (p, arg);
      
      if (simpleDateFormat == null)
      {
         return getString (p, arg);
      }
      else
      {
         java.util.Date d = (java.util.Date) getTime (p.pos.intValue ());
         if (d == null)
            return null;
         else
            return DateUtil.convertDateToString(d, simpleDateFormat);
      }
   }
   
   private java.sql.Time getTime (int index)
   throws Exception
   {
      java.sql.Time t = null;
      
      if (rs != null)
      {
         t = rs.getTime (index);
         if (rs.wasNull ()) t = null;
      }
      else
      {
         t = cs.getTime (index);
         if (cs.wasNull ()) t = null;
      }
      
      return t;
   }
   
   
   protected Object getTimestampParameter (Parameter p, Argument arg)
   throws Exception
   {
      String simpleDateFormat = getSimpleDateFormat (p, arg);
      
      if (simpleDateFormat == null)
      {
         return getString (p, arg);
      }
      else
      {
         java.sql.Timestamp t = getTimestamp (p.pos.intValue ());
         if (t == null)
         {
            return null;
         }
         else
         {
            java.util.Date d = new java.util.Date(t.getTime()  + 
                                                 (t.getNanos() / 1000000));
            return DateUtil.convertDateToString(d, simpleDateFormat);
         }
      }
   }
   
   private java.sql.Timestamp getTimestamp (int index)
   throws Exception
   {
      java.sql.Timestamp t = null;
      
      if (rs != null)
      {
         t = rs.getTimestamp (index);
         if (rs.wasNull ()) t = null;
      }
      else
      {
         t = cs.getTimestamp (index);
         if (cs.wasNull ()) t = null;
      }
      
      return t;
   }
    
   protected Object getTinyIntParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }
   
   
   protected Object getVarBinaryParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }

   
   protected Object getVarcharParameter (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p, arg);
   }


   protected Object getRowIdParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }


   protected Object getString (Parameter p, Argument arg)
   throws Exception
   {
      return getString (p.pos.intValue ());
   }
   
   protected Object getString (int index)
   throws Exception
   {
      String s = null;
      
      if (rs != null)
      {
         s = rs.getString (index);
         if (rs.wasNull ()) s = null;
      }
      else
      {
         s = cs.getString (index);
         if (cs.wasNull ()) s = null;
      }
      
      if (s != null)
         s = s.trim ();
      
      return s;
   }


   protected Object getSqlXmlParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new UnsupportedOperationException ();
   }

   
   protected Object getDatabaseSpecificParameter (Parameter p, Argument arg)
   throws Exception
   {
      throw new IllegalArgumentException ("Unsupported JDBC data type.");
   }
}
