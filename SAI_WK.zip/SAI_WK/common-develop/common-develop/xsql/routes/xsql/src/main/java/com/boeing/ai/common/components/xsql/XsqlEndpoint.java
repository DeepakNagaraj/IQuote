package com.boeing.ai.common.components.xsql;
import org.apache.camel.Consumer;
import org.apache.camel.Processor;
import org.apache.camel.Producer;
import org.apache.camel.impl.DefaultEndpoint;
import org.apache.camel.spi.Metadata;
import org.apache.camel.spi.UriEndpoint;
import org.apache.camel.spi.UriParam;
import org.apache.camel.spi.UriPath;

import javax.sql.DataSource;

/**
 * Represents Xsql endpoint.
 */

@UriEndpoint(scheme = "xsql", title = "XSQL", syntax = "xsql:dataSource", producerOnly = true, label = "xsql")
public class XsqlEndpoint extends DefaultEndpoint {

    @UriPath @Metadata(required = "true")
    private DataSource dataSource;


    public XsqlEndpoint() {
    }

    public XsqlEndpoint(String uri, XsqlComponent component, DataSource dataSource) {
        super(uri, component);
        this.dataSource = dataSource;
    }

    public XsqlEndpoint(String endpointUri) {
        super(endpointUri);
    }

    public boolean isSingleton() {
        return true;
    }

    public Producer createProducer() throws Exception {
        return new XsqlProducer(this, dataSource);
    }

    public Consumer createConsumer(Processor processor) throws Exception {
        throw new UnsupportedOperationException("Xsql consumer pattern not supported: " + getEndpointUri());
    }

    @Override
    protected String createEndpointUri() {
        return "xsql";
    }

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

}
