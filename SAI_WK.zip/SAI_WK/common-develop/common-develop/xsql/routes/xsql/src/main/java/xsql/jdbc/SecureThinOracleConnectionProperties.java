package xsql.jdbc;

import java.util.*;
import java.io.*;

/**
 * Class represents a set of properties that can be used for securely
 * connecting to an Oracle database when using its "thin" driver.
 */
public class SecureThinOracleConnectionProperties
implements Serializable
{
   /**
    * Indicates policy level of client encryption
    */
   public String  oracleNetEncryptionClient;
   /**
    * Indicates algorithm to be used for client encryption
    */
   public String  oracleNetEncryptionTypesClient;
   /**
    * Indicates policy level when using a checksum during encryption
    */
   public String  oracleNetCryptoChecksumClient;
   /**
    * Indicates algorithm to be used for the crypto checksum when using encryption
    */
   public String  oracleNetCryptoChecksumTypesClient;


   protected boolean fieldsMatch (Object o1, Object o2)
   {
      if (o1 == o2) return true;
      if (o1 == null) return false;
      return o1.equals (o2);
   }


   public boolean equals (Object obj)
   {
      if (obj == null) return false;
      if (!(obj instanceof SecureThinOracleConnectionProperties)) return false;

      SecureThinOracleConnectionProperties obj1 = (SecureThinOracleConnectionProperties) obj;
      if (!fieldsMatch (oracleNetEncryptionClient, obj1.oracleNetEncryptionClient))
         return false;
      if (!fieldsMatch (oracleNetEncryptionTypesClient, obj1.oracleNetEncryptionTypesClient))
         return false;
      if (!fieldsMatch (oracleNetCryptoChecksumClient, obj1.oracleNetCryptoChecksumClient))
         return false;
      if (!fieldsMatch (oracleNetCryptoChecksumTypesClient, obj1.oracleNetCryptoChecksumTypesClient))
         return false;
      return true;
   }


   /**
    * Returns the connection properties
    */
   public void addProperties(Properties cp)
   {
      if (oracleNetEncryptionClient != null) 
         cp.put("oracle.net.encryption_client", oracleNetEncryptionClient);

      if (oracleNetEncryptionTypesClient != null)
         cp.put("oracle.net.encryption_types_client", oracleNetEncryptionTypesClient);

      if (oracleNetCryptoChecksumClient != null) 
         cp.put("oracle.net.crypto_checksum_client", oracleNetCryptoChecksumClient);

      if (oracleNetCryptoChecksumTypesClient != null)
         cp.put("oracle.net.crypto_checksum_types_client", oracleNetCryptoChecksumTypesClient);
   }



}
