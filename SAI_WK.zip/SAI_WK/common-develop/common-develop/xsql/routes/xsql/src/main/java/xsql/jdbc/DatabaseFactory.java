package xsql.jdbc;

import java.sql.Connection;

import com.ibm.db2.jcc.DB2BaseDataSource;
import com.ibm.db2.jcc.DB2Connection;
import com.ibm.db2.jcc.DB2ConnectionPoolDataSource;
import com.ibm.db2.jcc.DB2DataSource;
import com.ibm.db2.jcc.DB2Driver;
import com.microsoft.sqlserver.jdbc.SQLServerConnection;
import com.teradata.jdbc.TeraLogicalConnection;
import com.teradata.jdbc.TeraPooledConnection;
import com.teradata.jdbc.jdbc_4.logging.Log;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.pool.OracleDataSource;
import xsql.StatementContext;

public class DatabaseFactory
{
   
   public DatabaseFactory ()
   {
   }
   
   public Database createDatabase (StatementContext context)
   throws Exception
   {
      Database db = null;
      Connection conn = context.getDefaultConnection ();
      String name = null;
      
      /*
       * Check for the connection class tyoe, (Oracle, DB2, MSSQL, Teradata)
       * 
       */
      
  	  name = conn.getMetaData().getDatabaseProductName().toLowerCase();
  	      
   /* 
    * Previous version of code
    * 
    * 
      String className = conn.getClass().getName();
      String name = className.toLowerCase ();
    */
      
      if (name.indexOf ("oracle") != -1)
      {
         db = new OracleDatabase (context);
      }
      else if (name.indexOf ("db2") != -1)
      {
         db = new DB2Database (context); 
      }
      else if (name.indexOf ("microsoft") != -1)
      {
         db = new SqlServerDatabase (context);
      }
      else if (name.indexOf ("tera") != -1)
      {
         db = new TeraDatabase (context);
      }
      else
         throw new IllegalArgumentException ("Unrecognized JDBC connection.");
      
      db.initialize ();
      return db;
   }
}

