package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>while statement</i> consists of an expression, called a condition,
and a statements list. It repeatedly executes a statement list
while the condition evaluates to true.
*/
abstract public class WhileStatement extends XSQLStatement
implements Serializable
{
   /**
    * A boolean valued XSQL expression.
    */
   public String  condition;
   /**
   * A list of <code>XSQLStatements</code>, which correspond
   * to the XML elements <code>xsql-statement</code>.
   */
   public List  statementList = new LinkedList ();


}
