package xsql.jdbc;

import java.io.*;
import java.sql.*;
import java.util.logging.Logger;

import javax.sql.*;

/**
 * An XSQLDataSource is used to establish connections to physical data sources
 * it represents (e.g. Oracle RDBMS, SQL RDBMS, etc.)
 */

abstract public class XSQLDataSource
implements Serializable, DataSource
{  
   protected int loginTimeout = 60;
   protected Connection conn;
   
   public XSQLDataSource ()
   {
      
   }
   
   public XSQLDataSource (String name, Connection conn)
   {
      this.name = name;
      this.conn = conn;
   }
   
   /**
    * Logical name of the data source.
    */
   protected String  name;
   /**
    * Host name of the machine housing the data source
    */
   protected String  host;
   /**
    * Port number where the data source establishes inbound connections
    */
   protected String  port;
   /**
    * Data source id
    */
   protected String  sid;
   /**
    * Username to be used for connecting to the data source
    */
   protected String  user;
   /**
    * Password to be used for connecting to the data source.
    */
   protected String  pwd;
   /**
    * Flag indicating whether or not this data source should use a connection
    * pool.
    */
   protected Boolean  usePool;
   
   /**
    * Number of connections to store in connection pool.
    */   
   protected Integer  maxPoolSize;

   /**
    * Data source URL. This is an alternate way to specify the database
    * connection parameters,
    * instead of providing the host, port, and sid.
    * This method is applicable when a database driver allows other
    * properties for a connection to be specified by encoding them
    * in the URL.
    */
   protected String  url;
   
   public String getName ()
   {
      return name;
   }

   public void setName (String name)
   {
      this.name = name;
   }

   public String getHost ()
   {
      return host;
   }

   public void setHost (String host)
   {
      this.host = host;
   }

   public abstract int getPort ()
   throws SQLException;

   public void setPort (String port)
   {
      this.port = port;
   }

   public String getSid ()
   {
      return sid;
   }

   public void setSid (String sid)
   {
      this.sid = sid;
   }

   public String getUser ()
   {
      return user;
   }

   public void setUser (String user)
   {
      this.user = user;
   }

   public String getPwd ()
   {
      return pwd;
   }

   public void setPwd (String pwd)
   {
      this.pwd = pwd;
   }

   public Boolean getUsePool ()
   {
      return usePool;
   }

   public void setUsePool (Boolean usePool)
   {
      this.usePool = usePool;
   }

   public void setMaxPoolSize (Integer maxPoolSize)
   {
      this.maxPoolSize = maxPoolSize;
   }
   
   protected boolean fieldsMatch (Object o1, Object o2)
   {
      if (o1 == o2) return true;
      if (o1 == null) return false;
      return o1.equals (o2);
   }


   public boolean equals (Object obj)
   {
      if (obj == null) return false;
      if (!(obj instanceof XSQLDataSource)) return false;

      XSQLDataSource obj1 = (XSQLDataSource) obj;
      if (!fieldsMatch (name, obj1.name))
         return false;
      if (!fieldsMatch (host, obj1.host))
         return false;
      if (!fieldsMatch (port, obj1.port))
         return false;
      if (!fieldsMatch (sid, obj1.sid))
         return false;
      if (!fieldsMatch (user, obj1.user))
         return false;
      if (!fieldsMatch (pwd, obj1.pwd))
         return false;
      if (!fieldsMatch (usePool, obj1.usePool))
         return false;
      if (!fieldsMatch (maxPoolSize, obj1.maxPoolSize))
         return false;
      if (!fieldsMatch (new Integer (loginTimeout), new Integer (obj1.loginTimeout)))
         return false;
      if (!fieldsMatch (url, obj1.url))
         return false;
      return true;
   }


   public int getMaxPoolSize ()
   {
      if (maxPoolSize == null)
         return 12;
      else
         return maxPoolSize.intValue ();
   }


   public abstract Connection getConnection()
   throws SQLException;

   public Connection getConnection(String username, String password)
   throws SQLException
   {
      this.user = username;
      this.pwd = password;
      return getConnection();
   }

   public PrintWriter getLogWriter()
   throws SQLException
   {
      String errMsg = "Unsupported method.";
      throw new SQLException(errMsg);
   }   

   public void setLogWriter(PrintWriter out)
   throws SQLException
   {
      String errMsg = "Unsupported method.";
      throw new SQLException(errMsg);
   }


   public void setLoginTimeout(int seconds)
                     throws SQLException
   {
      loginTimeout = seconds;
   }

   public int getLoginTimeout()
   throws SQLException
   {
      return loginTimeout;
   }

   protected boolean usePool()
   {
      if (usePool == null)
         return false;
      else
         return usePool.booleanValue();
   }
   
   protected String getJDBCUrl ()
   throws SQLException
   {
      return url;
   }
   
   public void setJDBCUrl (String url)
   {
      this.url = url;
   }

   public <T> T unwrap(Class<T> iface) throws SQLException
   {
      throw new UnsupportedOperationException("Not supported yet.");
   }

   public boolean isWrapperFor(Class<?> iface) throws SQLException
   {
      throw new UnsupportedOperationException("Not supported yet.");
   }
   
   public Logger getParentLogger() throws SQLFeatureNotSupportedException {

	   throw new SQLFeatureNotSupportedException("getParentLogger");

   }
}
