package xsql.impl;
 
public class InsertStatementImpl extends NonSelectStatementImpl
{ 
}