package xsql.ast;

import java.util.*;
import java.io.*;


/**
Query statements are used to select, insert, update, or delete data
from a database.
*/
abstract public class QueryStatement extends XSQLStatement
implements Serializable
{
   /**
    * The name of query statement.
    */
   public String  name;
   /**
    * The SQL for the query statement. The query string may contain
    * embedded XSQL expressions.
    */
   public String  sql;
   /**
    * An optional list of arguments that can be passed into a query 
    * statement. When arguments are specified a  java.sql.PreparedStatement 
    * is used to execute the statement. The position specified in the argument 
    * is intended to correspond to the positioning of a '?'  in the 'sql' string.
    * When arguments are not specified a java.sql.Statement is used to execute
    * the query statement
    */
   public List  args = new LinkedList ();


}
