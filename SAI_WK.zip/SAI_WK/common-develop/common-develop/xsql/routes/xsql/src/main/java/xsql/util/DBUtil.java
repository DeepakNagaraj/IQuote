package xsql.util;

import java.sql.*;

public class DBUtil 
{

   private DBUtil () { }
   
   public static void rollback (Connection conn) 
   {
       try
       {
           conn.rollback();
       }
       catch (Exception e){}
   }
  

   public static void closeCallableStatement(CallableStatement cs) 
   {
       try
       {
           cs.close();
       } 
       catch (Exception e){}
   }


   public static void closeConnection(Connection conn) 
   {
       try
       {
           conn.close();
       }
       catch (Exception e){}
   }


   public static void closePreparedStatement(PreparedStatement ps) 
   {
       try
       {
           ps.close();
       } 
       catch (Exception e){}
   }


   public static void closeResultSet(ResultSet rs) 
   {
       try
       {
           rs.close();
       } 
       catch (Exception e){}
   }


   public static void closeStatement(Statement s) 
   {
       try
       {
           s.close();
       } 
       catch (Exception e){}
   }
}
