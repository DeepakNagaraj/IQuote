package xsql.expr;

public class LogicalOp extends BinaryOp
{
   public LogicalOp (ExpressionContext context,
                     String opSymbol,
                     Node left,
                     Node right)
   {
      super (context, opSymbol, left, right);
   }


   public Object eval ()
   throws Exception
   {
      evalOperands ();
      prepareValuesForLogicalOp ();
      Boolean l = (Boolean) leftValue;
      Boolean r = (Boolean) rightValue;
      if (opSymbol.equals ("&&"))
         return new Boolean (l.booleanValue () && r.booleanValue ());
      else if (opSymbol.equals ("||"))
         return new Boolean (l.booleanValue () || r.booleanValue ());
      else
         throw new UndefinedOperatorException (opSymbol);
   }
}
