package xsql;

import java.util.*;
import java.io.*;

import xsql.ast.*;

public class Semantics
{
   public int  numErrors = 0;
   
   public int analyze (Object abstractSyntaxTree)
   throws Exception
   {
      XSQL document = (XSQL) abstractSyntaxTree;
      
      return numErrors;
      
   }
}
