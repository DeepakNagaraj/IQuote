package xsql.expr;

public class IndexException extends ExpressionException
{
   public IndexException (int index)
   {
      super (buildMessage (index));
   }


   private static String buildMessage (int index)
   {
      return "Index out of bounds :: " + index;
   }
}
