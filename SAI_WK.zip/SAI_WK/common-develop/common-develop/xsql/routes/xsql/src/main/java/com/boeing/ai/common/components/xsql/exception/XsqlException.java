package com.boeing.ai.common.components.xsql.exception;

public class XsqlException extends Throwable {
    public XsqlException(String message){
       super(message);
    }

}
