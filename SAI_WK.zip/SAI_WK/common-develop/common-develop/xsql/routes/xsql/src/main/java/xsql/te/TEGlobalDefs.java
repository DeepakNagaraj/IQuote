package xsql.te;


public interface TEGlobalDefs
{
   public static String defaultTESchemaPropertyName = "wdsSchemaName";
   public static String defaultTESchemaVarName = "wdsSchemaName";
}
