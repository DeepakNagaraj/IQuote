package xsql.impl;

import java.io.*;
import java.sql.*;
import java.util.*;

import xsql.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.expr.*;
  
public class IfStatementImpl extends IfStatement
{ 
   StatementContext     context = null;

   public void execute (StatementContext context)
   throws Exception
   {
      this.context = context;
      
      boolean b = context.evalBooleanExpression (this.condition);
      
      if (b)
         executeThenPart();
      else 
         executeElsePart();
   }
   
   
   private void executeThenPart()
   throws Exception
   {
      this.context.executeStatementList(this.thenPart.statementList);
   }
   
   
   private void executeElsePart()
   throws Exception
   {
      if (this.elsePart == null) return;
      this.context.executeStatementList(this.elsePart.statementList);
   }
}
