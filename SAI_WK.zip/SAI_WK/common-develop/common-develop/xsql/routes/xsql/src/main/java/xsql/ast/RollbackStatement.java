package xsql.ast;

import java.util.*;
import java.io.*;


/**
A <i>rollback statement</i> enables the user to rollback their current database
activity. 
*/
abstract public class RollbackStatement extends XSQLStatement
implements Serializable
{


}
