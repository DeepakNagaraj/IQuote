package xsql;

import java.sql.*;
import java.util.*;
import java.io.*;

import xsql.impl.*;
import xsql.expr.*;
import xsql.ast.*;
import xsql.util.*;
import xsql.jdbc.*;

public interface StatementContext
{
   public Connection getDefaultConnection ();
   public String getDefaultConnectionName ();
   public void setConnectionValid (boolean value);
   public SymbolTable getSymbolTable ();
   public ElementNode getCurrentXMLDocument ();
   public void setCurrentXMLDocument (ElementNode document);
   public void executeStatementList (List statements) throws Exception;
   public String resolveExpressions (String s) throws Exception;
   public Object evalExpression (String e) throws Exception;
   public boolean evalBooleanExpression (String expr) throws Exception;
   public Logger getLogger ();
   public void clearDocument ();
   public HashMap getDocumentTags ();
   public Database getDatabase () throws Exception;
   public List<String> getProcDictPath ();

   /**
    * Indicates whether to purge the Oracle pipe at the end of
    * a TE process.
    */
   public boolean getPurgeTEPipe ();
}
