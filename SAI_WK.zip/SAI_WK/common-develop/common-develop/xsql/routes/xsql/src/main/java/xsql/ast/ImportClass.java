package xsql.ast;

import java.util.*;
import java.io.*;


/**
An <i>import class statement</i> imports a Java class into an XSQL program,
and gives it a name to reference it by.
*/
abstract public class ImportClass extends XSQLStatement
implements Serializable
{
   /**
    * The XSQL name used to reference the Java class. This name must
    * be a valid XSQL identifier.
    */
   public String  name;
   /**
    * The name of the Java class to be imported.
    */
   public String  javaName;


}
