package xsql.impl;

import java.util.*;
import java.io.*;

import xsql.*;
import xsql.ast.*;

public class WriteStatementImpl extends WriteStatement
{
   public void execute (StatementContext context)
   throws Exception
   {
      String value = getValue ();
      value = context.resolveExpressions (value);
      System.out.println (value);
   }


   private String getValue ()
   {
      if (value != null)
         return value;
      else
         return longValue;
   }
}
