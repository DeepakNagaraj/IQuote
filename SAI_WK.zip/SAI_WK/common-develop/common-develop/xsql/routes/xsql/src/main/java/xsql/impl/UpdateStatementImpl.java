package xsql.impl;
 
public class UpdateStatementImpl extends NonSelectStatementImpl
{ 
}