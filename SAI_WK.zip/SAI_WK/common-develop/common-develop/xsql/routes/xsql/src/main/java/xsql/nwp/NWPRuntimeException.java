package xsql.nwp;

import xsql.*;


/**
 * This exception is thrown when an NWP call encounters a critical error.
 * <p>
 * It provide additional information, giving advice on how soon the
 * XSQL program containing the error should be executed again,
 * and, moreover, the number of the times one should retry executing
 * the XSQL program before considering the error important enough to
 * alert someone.
 */
public class NWPRuntimeException extends XSQLRuntimeException
{
   protected int retryInterval = 1000 * 60 * 5;
   protected int retryThreshold = 1;


   public NWPRuntimeException (String message)
   {
      super (message);
   }


   /**
    * Returns a suggested retry interval, in milliseconds.
    */

   public int getRetryInterval ()
   {
      return retryInterval;
   }


   /**
    * Returns a suggested number of retries, before declaring the problem
    * serious.
    */
   public int getRetryThreshold ()
   {
      return retryThreshold;
   }
}
