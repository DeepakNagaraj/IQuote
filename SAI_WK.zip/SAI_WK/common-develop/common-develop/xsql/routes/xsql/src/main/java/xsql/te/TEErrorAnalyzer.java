package xsql.te;

import java.util.*;

public class TEErrorAnalyzer
{
   /**
    * Symbolic constant for the <code>and</code> conjunction in an error rule.
    */
   protected static final int AND = 0;

   /**
    * Symbolic constant for the <code>or</code> conjunction in an error rule.
    */
   protected static final int OR = 1;

   protected class RuleTableEntry
   {
      long errorNumber;
      int conjunction;
      String text;


      public RuleTableEntry (long errorNumber, int conjunction, String text)
      {
         this.errorNumber = errorNumber;
         this.conjunction = conjunction;
         this.text = text;
      }
   }

   protected RuleTableEntry ruleTable [] =
     {
       new RuleTableEntry (90003, OR, "Time out reading cdb server"),
       new RuleTableEntry (90004, OR, "Timeout on dead server"),
       new RuleTableEntry (90005, OR,
         "Error trying to kill() non-responsive server"),
       new RuleTableEntry (90006, OR, "Killed non-responding server"),
       new RuleTableEntry (90008, OR,
         "CDB client error on message queue see text for details"),
       new RuleTableEntry (90009, OR, "CDB error message see text for details"),
       new RuleTableEntry (90015, OR, "Application program quit"),
       new RuleTableEntry (0, AND, "TEC daemon failed to respond"),
       new RuleTableEntry (543, OR, "Data in use by"),
       new RuleTableEntry (0, AND,
         "ORA-00054: resource busy and acquire with NOWAIT specified"),
       new RuleTableEntry (0, AND,
         "******ALERT******>INTERNAL ERROR: unexpected response (128)"),
       new RuleTableEntry (0, AND,
         "Update Failed MRP is Running"),
       new RuleTableEntry (90028, OR, "Timed out waiting for next message from client"),
       new RuleTableEntry (9277, OR, "Logical Lock Manager failed to respond"),
       new RuleTableEntry (90025, OR, "No response from application, aborting transaction"),
       new RuleTableEntry (90014, OR, "API is out of service due to application error"),
       new RuleTableEntry (100, AND, "ORA-"),
       new RuleTableEntry (0, AND,
         "Commit control requested (ROLLBACK) with no current LUW master"),
       new RuleTableEntry (0, AND,
         "ORA-04061: existing state of package body")
     };


   protected String getLowerCase (String t)
   {
      if (t == null)
      {
         return "";
      }
      else
      {
         return t.toLowerCase ();
      }
   }


   protected boolean matchesRule (CCAPITEMessage m)
   {
      for (int i = 0; i < ruleTable.length; i++)
      {
         RuleTableEntry e = ruleTable [i];

         if (e.conjunction == OR)
         {
            if (e.errorNumber == m.number) return true;

            String ccapiText = getLowerCase (m.text);
            String entryText = getLowerCase (e.text);
            if (ccapiText.indexOf (entryText) != - 1) return true;
         }
         else
         {
            if (e.errorNumber == m.number)
            {
               String ccapiText = getLowerCase (m.text);
               String entryText = getLowerCase (e.text);
               if (ccapiText.indexOf (entryText) != - 1) return true;
            }
         }
      }
      return false;
   }


   public boolean isCriticalError (List ccapiMessages)
   {
      for (Iterator i = ccapiMessages.iterator (); i.hasNext (); )
      {
         CCAPITEMessage m = (CCAPITEMessage) i.next();
         if (matchesRule (m)) return true;
      }
      return false;
   }
}
