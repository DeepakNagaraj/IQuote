package com.boeing.ai.fuse.framework;

import java.util.Dictionary;

import org.apache.aries.blueprint.ParserContext;
import org.apache.aries.blueprint.mutable.MutableBeanMetadata;
import org.w3c.dom.Element;

public interface JmsComponentFactory {

	public MutableBeanMetadata buildConnectionFactory(ParserContext parserContext, Element element, Dictionary<String,Object> properties, String concurrentConsumers);

}
