package com.boeing.ai.fuse.framework;

import java.util.Dictionary;

import org.apache.activemq.jms.pool.GenericResourceManager;
import org.apache.activemq.jms.pool.JcaPooledConnectionFactory;
import org.apache.activemq.jms.pool.PooledConnectionFactory;
import org.apache.aries.blueprint.ParserContext;
import org.apache.aries.blueprint.mutable.MutableBeanMetadata;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Element;

import com.ibm.mq.jms.MQConnectionFactory;
import com.ibm.mq.jms.MQXAConnectionFactory;

public class WmqComponentBuilder extends JmsComponentBuilder {

	private static final transient Logger LOG = LoggerFactory.getLogger(WmqComponentBuilder.class);
	
	public MutableBeanMetadata buildConnectionFactory(ParserContext parserContext, Element element, Dictionary<String,Object> properties, String concurrentConsumers) {
		
		// wmq connection factory
    	MutableBeanMetadata wmqCFMetadata = parserContext.createMetadata(MutableBeanMetadata.class);
    	if (xa) {
    		wmqCFMetadata.setRuntimeClass(MQXAConnectionFactory.class);
    	} else {
    		wmqCFMetadata.setRuntimeClass(MQConnectionFactory.class);
    	}
    	
    	wmqCFMetadata.addProperty("hostName", createStringValue(parserContext,getValue(properties,"hostName","localhost").trim()));
    	wmqCFMetadata.addProperty("port", createStringValue(parserContext,getValue(properties,"port","1414").trim()));
    	if (gotValue(properties, "queueManager")) {
    		wmqCFMetadata.addProperty("queueManager", createStringValue(parserContext,getValue(properties,"queueManager","").trim()));
    	}
    	if (gotValue(properties,"channel")) {
    		wmqCFMetadata.addProperty("channel", createStringValue(parserContext,getValue(properties,"channel","").trim()));
    	}
    	
    	wmqCFMetadata.addProperty("transportType", createStringValue(parserContext,getValue(properties,"transportType","1").trim()));


    	// connection pool
		MutableBeanMetadata connectionPoolMeta = parserContext.createMetadata(MutableBeanMetadata.class);
		if (xa) {
			connectionPoolMeta.setRuntimeClass(JcaPooledConnectionFactory.class);
		} else {
			connectionPoolMeta.setRuntimeClass(PooledConnectionFactory.class);
		}
    	
		connectionPoolMeta.setInitMethod("start");
		connectionPoolMeta.setDestroyMethod("stop");
		if (xa) {
			connectionPoolMeta.addProperty("name",createValue(parserContext,id + ".brokerCP"));
		}
		connectionPoolMeta.addProperty("connectionFactory", wmqCFMetadata);
		connectionPoolMeta.addProperty("maxConnections", createValue(parserContext,concurrentConsumers));

		//  setup the recovery manager
		if (xa) {
			MutableBeanMetadata resourceManagerMeta = parserContext.createMetadata(MutableBeanMetadata.class);
			resourceManagerMeta.setRuntimeClass(GenericResourceManager.class);
			resourceManagerMeta.setInitMethod("recoverResource");
			resourceManagerMeta.setId("resourceManager-" + id);
			resourceManagerMeta.addProperty("connectionFactory",wmqCFMetadata);
			resourceManagerMeta.addProperty("transactionManager",  createValue(parserContext,recoverableTransactionManager));
			resourceManagerMeta.addProperty("resourceName",createValue(parserContext,id + ".brokerCP"));
			
			parserContext.getComponentDefinitionRegistry().registerComponentDefinition(resourceManagerMeta);
		}
		
    	return connectionPoolMeta;
	}

}
