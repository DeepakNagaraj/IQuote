package com.boeing.ai.fuse.framework.sched;

import java.util.*;

public abstract class ScheduledTask
{
   protected Date timeToExecute;
   protected boolean cancelled = false;
   protected boolean done = false;


   public void setTimeToExecute (Date t)
   {
      this.timeToExecute = t;
   }   


   public Date getTimeToExecute ()
   {
      return timeToExecute;
   }   


   public synchronized void cancel ()
   {
      if (!done)
      {
         cancelled = true;
         done = true;
      }
   }


   public synchronized void run ()
   {
      if (!done)
      {
         try
         {
            execute ();
         }
         catch (Exception e)
         {
         }
         finally
         {
            done = true;
         }
      }
   }   


   public abstract void execute ()
   throws Exception;
}
