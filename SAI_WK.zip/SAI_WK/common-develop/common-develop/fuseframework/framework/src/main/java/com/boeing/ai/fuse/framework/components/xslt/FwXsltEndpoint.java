package com.boeing.ai.fuse.framework.components.xslt;

import org.apache.camel.Exchange;
import org.apache.camel.Producer;
import org.apache.camel.component.xslt.XsltEndpoint;
import org.apache.camel.spi.Metadata;
import org.apache.camel.spi.UriEndpoint;
import org.apache.camel.spi.UriParam;
import org.apache.camel.spi.UriPath;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.boeing.ai.fuse.framework.Context;
import com.boeing.ai.fuse.framework.FwJmsComponent;

/**
 * Represents a Framework XSLT Component endpoint.
 */
@UriEndpoint(scheme = "fwxslt", title = "Framework XSLT", syntax="fwxslt:resourceUri", producerOnly = true, label = "framework,transformation")
public class FwXsltEndpoint extends XsltEndpoint 
{

	private static final Logger LOG = LoggerFactory.getLogger(FwXsltEndpoint.class);
	
    @UriParam(defaultValue = "false")
    private boolean development = false;

    public FwXsltEndpoint(String uri, FwXsltComponent component)
    {
        super(uri, component);
        LOG.debug("*** FwXsltEndpoint(" + uri + ", " + component + ")");
    }
    
	public boolean isDevelopment() {
		return development;
	}
	public void setDevelopment(boolean development) {
		this.development = development;
	}

	@Override
	protected void onExchange(Exchange exchange) throws Exception {
		Context context = Context.getInstance();
		context.setProperty("exchange", exchange);
		super.onExchange(exchange);
	}

	

    
}
