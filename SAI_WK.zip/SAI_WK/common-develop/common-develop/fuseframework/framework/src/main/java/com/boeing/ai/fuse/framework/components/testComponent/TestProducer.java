package com.boeing.ai.fuse.framework.components.testComponent;


import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Test Component producer.
 */
public class TestProducer
extends DefaultProducer
{
   private TestEndpoint endpoint;

   private static final Logger LOG =
     LoggerFactory.getLogger(TestProducer.class);

   private static int lastInstance = 0;
   private int instance = ++lastInstance;


   public TestProducer (TestEndpoint endpoint)
   {
      super(endpoint);
      this.endpoint = endpoint;
   }

   public void process (Exchange exchange)
   throws Exception
   {
      System.out.println(exchange.getIn().getBody());    
      //throw new Exception ("TestProducer" + instance + " can't produce.");
   }
}
