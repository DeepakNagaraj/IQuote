package com.boeing.ai.fuse.framework.components.testComponent;

import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;

import org.apache.camel.impl.UriEndpointComponent;

/**
 * Represents the component that manages {@link TestEndpoint}.
 */
public class TestComponent extends UriEndpointComponent {
    
    public TestComponent() {
        super(TestEndpoint.class);
    }

    public TestComponent(CamelContext context) {
        super(context, TestEndpoint.class);
    }

    protected Endpoint createEndpoint(String uri, String remaining, Map<String, Object> parameters) throws Exception {
        Endpoint endpoint = new TestEndpoint(uri, this);
        setProperties(endpoint, parameters);
        return endpoint;
    }
}
