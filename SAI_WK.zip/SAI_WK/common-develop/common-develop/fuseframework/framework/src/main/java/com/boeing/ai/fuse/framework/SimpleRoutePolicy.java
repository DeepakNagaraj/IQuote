package com.boeing.ai.fuse.framework;

import java.util.Date;
import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Route;
import org.apache.camel.support.RoutePolicySupport;

import com.boeing.ai.fuse.framework.sched.ScheduledTask;
import com.boeing.ai.fuse.framework.sched.Timer;


public class SimpleRoutePolicy
extends RoutePolicySupport
{
   protected static String ROUTE_STATUS = "boeing.ROUTE_STATUS";
   public SimpleRoutePolicy ()
   {
      //System.out.println ("SimpleRoutePolicy created");
   }


   public void onInit (Route route)
   {
      RouteStatus status = new RouteStatus ();
      Map<String, Object> properties = route.getProperties ();
      properties.put (ROUTE_STATUS, status);
      String message = buildFullMessage (route, status, 
        "Route initialized.");
      log.info (message);
   }


   protected RouteStatus getRouteStatus (Route route)
   {
      Map<String, Object> properties = route.getProperties ();
      return (RouteStatus) properties.get (ROUTE_STATUS);
   }


   public void onStart (Route route)
   {
      RouteStatus status = getRouteStatus (route);

      String message = buildFullMessage (route, status, 
        "Route started.");
      log.info (message);
   }


   public void onStop(Route route)
   {
      RouteStatus status = getRouteStatus (route);

      String message = buildFullMessage (route, status, 
        "Route stopped.");
      log.info (message);
      if (status != null)
      {
         ScheduledTask resumeTask = status.getResumeTask ();
         if (resumeTask != null)
         {
            resumeTask.cancel ();
         }
      }
   }


   public void onSuspend (Route route)
   {
      RouteStatus status = getRouteStatus (route);

      String message = buildFullMessage (route, status, 
        "Route suspended.");
      log.info (message);
   }


   public void onExchangeBegin(Route route, Exchange exchange)
   {
      RouteStatus status = getRouteStatus (route);

      String message = buildFullMessage (route, status, 
        "Exchange began.");
      log.info (message);
   }


   public void onExchangeDone(Route route, Exchange exchange)
   {
      RouteStatus status = getRouteStatus (route);

      try
      {
         Context context = Context.getInstance ();
         context.destroy ();

         if (!exchange.isFailed ())
         {
            String message = buildFullMessage (route, status, 
              "Exchange completed successfully.");

            log.info (message);
            status.setRetryCount (0);
         }
         else
         {
            if (status.getRetryCount () != status.getAlarmThreshold ())
            {
               String message = buildFullMessage (route, status,
                 "Exchange failed.");
               log.info (message, exchange.getException ());
            }
            else
            {
               String message = buildAlarmMessage (route, status,
                 "Exchange failed.");
               log.error (message, exchange.getException ());
            }
            int retryInterval = status.getRetryInterval ();

            suspendRoute (route);
            String message = buildFullMessage (route, status,
              "Suspending route for " + (retryInterval / 1000.0)
              + "seconds.");
            log.info (message);

            status.setRetryCount (status.getRetryCount () + 1);
            createScheduledTaskToResumeRoute (route, status, retryInterval);
         }
      }
      catch (Exception e)
      {
      }
   }


   protected String buildFullMessage (Route route,
                                      RouteStatus status,
                                      String info)
   {
      StringBuffer message = new StringBuffer ();
      message.append ("Route ");
      message.append (route.getId ());
      if (status != null)
      {
         message.append ("[Retry ");
         message.append (status.getRetryCount () + "");
         message.append ("]");
      }
      message.append (": ");
      message.append (info);
   
      return message.toString ();
   }


   protected String buildAlarmMessage (Route route,
                                       RouteStatus status,
                                       String info)
   {
      StringBuffer message = new StringBuffer ();
      message.append ("Route Failed.");
      message.append (buildFullMessage (route, status, info));
      return message.toString ();
   }


   public void createScheduledTaskToResumeRoute (Route route,
                                                 RouteStatus status,
                                                 int   retryInterval)
   {
      ResumeRouteTask task = new ResumeRouteTask (route);
      status.setResumeTask (task);
      Date d = new Date ();
      Date retryTime = new Date (d.getTime () + retryInterval);
      task.setTimeToExecute (retryTime);
      Timer t = Timer.getInstance ();
      t.add (task);
   }


   protected class ResumeRouteTask
   extends ScheduledTask
   {
      protected Route route = null;

      public ResumeRouteTask (Route route)
      {
         this.route = route;
      }


      public void execute ()
      throws Exception
      {
         CamelContext camelContext =
           route.getRouteContext ().getCamelContext ();
         camelContext.resumeRoute (route.getId ());
      }
   }
}
