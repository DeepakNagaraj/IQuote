package com.boeing.ai.fuse.framework;

public class ThreadLocalContext extends ThreadLocal<Context> {
	public Context initialValue() {
		return new Context();
	}
}
