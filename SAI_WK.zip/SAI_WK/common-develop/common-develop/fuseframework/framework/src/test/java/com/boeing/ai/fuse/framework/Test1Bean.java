package com.boeing.ai.fuse.framework;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Test1Bean
{

   private static final transient Logger LOG =
     LoggerFactory.getLogger(Test1Bean.class);


   public void execute (Exchange exchange)
   {
      String threadName = Thread.currentThread ().getName ();
      LOG.info ("execute method invoked. Running on thread " + threadName);
   }
}
