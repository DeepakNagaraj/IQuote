package com.boeing.a2a.util.xml;

import com.boeing.a2a.util.logging.LoggerInterface;
import javax.xml.transform.ErrorListener;
import javax.xml.transform.TransformerException;

/*
 * Xalan changed its default behavior as of version 2.7.1.  Applications
 * must register their own ErrorListener on the Transformer in order for
 * it to throw exceptions instead of printing out to System.err.  This was
 * the default behavior of the broker prior to this Xalan release.  As a result,
 * this class was written to preserve that behavior.
 */
public class TransformerErrorListener implements ErrorListener
{
   private LoggerInterface logger = null;
   
   public TransformerErrorListener () {}
   
   public TransformerErrorListener (LoggerInterface logger)
   {
      this.logger = logger;
   }

   public void warning (TransformerException exception) throws TransformerException
   {
      if (logger == null)
      {
         System.err.println ("Warning: " + exception.getMessageAndLocation ());
      }
      else
      {
         String msg = "A warning occurred during a transformation.";
         logger.info (msg, exception);
      }
   }

   public void error (TransformerException exception) throws TransformerException
   {
      System.err.println ("Error: " + exception.getMessageAndLocation ());
      throw exception;
   }

   public void fatalError (TransformerException exception) throws TransformerException
   {
      System.err.println ("FatalError: " + exception.getMessageAndLocation ());
      throw exception;
   }
   
}
