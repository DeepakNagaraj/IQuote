package com.boeing.ai.common.components.ftl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;

import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.boeing.a2a.ftl.FtlProcessor;


/**
 * The Ftl producer.
 */
public class FtlProducer extends DefaultProducer {
    private static final Logger LOG = LoggerFactory.getLogger(FtlProducer.class);
    private FtlEndpoint endpoint;
    
	private String specFile = null;
	private String  encoding = null;
	private String operation=null;
	
    public FtlProducer(FtlEndpoint endpoint) {
        super(endpoint);
        this.endpoint = endpoint;
        this.specFile = endpoint.getSpecFile();
        this.operation = endpoint.getOperation();
        
        if(endpoint.getEncoding()==null)
        	this.encoding = StandardCharsets.UTF_8.toString();
    }
    
    
    public void process(Exchange exchange) throws Exception {
        //System.out.println(exchange.getIn().getBody());    
        FtlProcessor ftlProcessor = null;
        InputStream in;
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        
        try {
            LOG.debug("Start FtlProducer..." + exchange.toString());
            LOG.debug("Start FtlProducer..." + exchange.getIn().getMessageId());

            ftlProcessor = new FtlProcessor(specFile);
            ftlProcessor.compileSpec();
            
            in = exchange.getIn().getBody(InputStream.class);
            
            if (operation.equals("flatToxml")){
            		ftlProcessor.doFlatToXmlTransform(in, out, encoding);
            }
            else if(operation.equals("xmlToflat")){ 
            		ftlProcessor.doXmlToFlatTransform(in, out, encoding);
            }
            
            out.flush();
            
            LOG.debug("output from ftlProcessor " + out.toString(encoding));
            
            exchange.getIn().setBody(out);
        }
        catch (Exception e) {
            LOG.debug(e.getStackTrace().toString());
            throw e;
        }

        LOG.debug(exchange.getIn().getBody().toString());
    }
}
