package org.apache.camel.component;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Paths;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.camel.ContextTestSupport;
import org.apache.camel.Exchange;
import org.apache.camel.FailedToCreateRouteException;
import org.apache.camel.Produce;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.component.util.FtlComponentTestUtil;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.custommonkey.xmlunit.Diff;
import org.custommonkey.xmlunit.XMLUnit;
import org.junit.Test;
import org.w3c.dom.Document;

import com.boeing.ai.common.components.ftl.FtlEndpoint;

public class FtlComponentTest extends CamelTestSupport  {
	
	@Produce
	ProducerTemplate template;
	

	
	@Override
	public void setUp() throws Exception {
	    super.setUp();

	    //Tell XML Unit to ignore whitespace between elements and within elements
	    XMLUnit.setIgnoreWhitespace(true);
	    XMLUnit.setNormalizeWhitespace(true);
	}	
	

	@Test
	public void testFlatToXmlOutput() throws Exception {
		MockEndpoint mock = getMockEndpoint("mock:result");
		mock.expectedMessageCount(1);
//		mock.expectedBodiesReceived(FtlComponentTestUtil.FTL_OUTPUT);
		
		template.sendBody("direct:start1", FtlComponentTestUtil.DELIMIT_DATA);

		assertMockEndpointsSatisfied();
		
        List<Exchange> list = mock.getReceivedExchanges();
        Exchange exchange = list.get(0);
        
        FtlComponentTestUtil.OUTPUT = exchange.getIn().getBody();
        String actualResponse = exchange.getIn().getBody(String.class);
        
        assertNotNull("The transformed XML should not be null", actualResponse);
        assertTrue(actualResponse.indexOf("IronData")>-1);
        assertTrue(actualResponse.indexOf("transaction")>-1);
        
        Diff myDiff = new Diff(actualResponse, FtlComponentTestUtil.XML_DATA);
        assertTrue("XML identical " + myDiff.toString(), myDiff.identical());
		
	}
	
	@Test
	public void testXmlToFlatOutput() throws Exception{
		MockEndpoint mock = getMockEndpoint("mock:result");
		mock.expectedMessageCount(1);

		template.sendBody("direct:start2", FtlComponentTestUtil.XML_DATA);

		assertMockEndpointsSatisfied();

        List<Exchange> list = mock.getReceivedExchanges();
        Exchange exchange = list.get(0);
        String message = exchange.getIn().getBody(String.class).trim();
        
        assertEquals("Output as expected",FtlComponentTestUtil.DELIMIT_DATA , message);
	}

	@Override
	protected RouteBuilder createRouteBuilder() throws Exception {
		return new RouteBuilder() {
			public void configure() {
				//Flat file to XML transformation
				from("direct:start1").to("ftl:flatToxml?specFile=schema/Excl.ftl")
						.to("mock:result");
				
				//XML to flat file transformation
				from("direct:start2").to("ftl:xmlToflat?specFile=schema/Excl.ftl")
				.to("mock:result");
			}
		};
	}
}
