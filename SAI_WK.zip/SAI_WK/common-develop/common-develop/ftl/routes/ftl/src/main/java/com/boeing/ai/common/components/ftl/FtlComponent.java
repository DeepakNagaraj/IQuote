package com.boeing.ai.common.components.ftl;

import java.util.Map;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;
import org.apache.camel.impl.UriEndpointComponent;
import org.apache.camel.util.ObjectHelper;

import com.boeing.a2a.ftl.FtlProcessor;

/**
 * Represents the component that manages {@link FtlEndpoint}.
 */
public class FtlComponent extends UriEndpointComponent {
    

	public FtlComponent() {
        super(FtlEndpoint.class);
    }

    public FtlComponent(CamelContext context) {
        super(context, FtlEndpoint.class);
    }

    protected Endpoint createEndpoint(String uri, String remaining, Map<String, Object> parameters) throws Exception {
    	 
        String operation = remaining;
        if (!"flatToxml".equals(operation) && !"xmlToflat".equals(operation)) {
            throw new IllegalArgumentException("Operation must be either flatToxml or xmlToflat, was: " + operation);
        }
        
    	FtlEndpoint endpoint = new FtlEndpoint(uri, this);
    	endpoint.setOperation(operation);
    	setProperties(endpoint, parameters);
        return endpoint;
    }

    
}
