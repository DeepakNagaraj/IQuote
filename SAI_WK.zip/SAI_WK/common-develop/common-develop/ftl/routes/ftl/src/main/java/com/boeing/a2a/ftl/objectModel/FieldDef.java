package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

import xgen.util.xml.XMLDocument;

import org.xml.sax.Locator;

/**
 * An ftl specification can describe many types of fields, from simple fields
 * to composite fields containing other simple or composite fields. In addition
 * fields can be repeated.
 */
abstract public class FieldDef
implements Serializable
{
   /** supply serialVersionUID for interoperability with older versions*/
   private static final long serialVersionUID = 0000000000000000003L;

   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;

   /**
    * This object contains the original values for each
    * field specified by the user.
    */
   public FieldDef original = null;

   /**
    * The name of the field. When converting to XML this will be used
    * as the element tag for the field.
    */
   public String  name;
   public String  ov_name;
   /**
    * The number of times the field is repeated. The default value for
    * attribute is 1. The value <code>*</code> means the field is
    * repeated an indefinite number of times, as determined by the
    * contents of the flat file being converted.
    */
   public String  repeat;
   public String  ov_repeat;


   abstract public Object copy ();

   protected void copyFields (FieldDef src, FieldDef dest)
   {
      dest.original = src.original;
      dest.name = src.name;
      dest.ov_name = src.ov_name;
      dest.repeat = src.repeat;
      dest.ov_repeat = src.ov_repeat;
   }


   /**
    * Returns an XML Document representation of this instance of the
    * class <code>FieldDef</code>.

    * @param original Specifies whether the original
    * or the resolved document should be represented.
    */
   public XMLDocument toXMLDocument (boolean original)
   throws IOException
   {
      XMLDocument result = new XMLDocument ("field-def");
      FieldDef instance = null;
      if (original)
      {
         if (this.original == null) return null;
         instance = (FieldDef) this.original;
      }
      else
      {
         instance = this;
      }
      addAttributes (result, instance, original);
      addElements (result, instance, original);
      return result;
   }


   /**
    * Adds attributes to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the attribute values from.
    * @param original Specifies whether the original
    * or the resolved attributes should be represented.
    */
   protected void addAttributes (XMLDocument doc,
                                 FieldDef instance,
                                 boolean original)
   throws IOException
   {
      if (original)
      {
         doc.addAttribute ("name", instance.ov_name);
         doc.addAttribute ("repeat", instance.ov_repeat);
      }
      else
      {
         doc.addAttribute ("name", instance.name);
         doc.addAttribute ("repeat", instance.repeat);
      }
   }


   /**
    * Adds elements to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the elements from.
    * @param original Specifies whether the original
    * or the resolved elements should be represented.
    */
   protected void addElements (XMLDocument doc,
                               FieldDef instance,
                               boolean original)
   throws IOException
   {
      XMLDocument temp = null;

   }


   /**
    * The resolved repetition count for the field if the repeat
    * attribute is an integer.
    */
   public int       repeatCount = 1;

   /**
    * The resolved field that will contain the number of times this field
    * repeats if the repeat attribute is the name of a field.
    */
   public FieldDef  repeatField;

   /**
    * The value to write to a flat file if there is no corresponding
    * value in the XML document. It is also the value that is written
    * for other types of fields, such as filler fields and end of
    * line fields.
    */
   public String    defaultValue;

   /**
    * The resolved length of the field in the flat file.
    */
   public int       fieldLength;

   /**
    * Indicates how a value should be aligned when it's being written to the
    * flat file when the length of the value is not equal to the the length
    * of the field.
    */
   public String    fieldAlignment = "left";

   /**
    * Indicates the character to use when padding a value when its length is
    * shorter than the field it is being written to in a flat file.
    */
   public char      padChar = ' ';

   /**
    * Indicates whether blanks should be trimmed off of the field when it is
    * being written to the XML file. If the fieldAlignment is left
    * then blanks on the right will be trimmed. If the fieldAlignment
    * is right then blanks on the left will be trimmed.
    */
   public boolean   fieldTrim = true;

   /**
    * Indicates whether leading zeroes should be trimmed off of the field when
    * it is being written to the FTL file.
    */
   public boolean   trimLeadingZeroes = false;

   /*
    * Parent record of this field def.
    */
   public FieldDef  parentRecord = null;

   /*
    * Previous sibling of this field def.
    */
   public FieldDef  prevSibling = null;



}
