package com.boeing.a2a.util;

import java.util.TimeZone;
import java.util.Date;
import java.util.StringTokenizer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class DateUtil
{
   public static String monthName[] = {"JAN", "FEB", "MAR", "APR",
   "MAY", "JUN", "JUL", "AUG",
   "SEP", "OCT", "NOV", "DEC" };
   
   public static ArrayList timeZoneList = 
           new ArrayList (Arrays.asList (TimeZone.getAvailableIDs ()));

   private DateUtil ()
   {
   }
   
   
   public static String convertDateToDateString (Date date)
   {
      Calendar calendar = new GregorianCalendar ();
      calendar.setTime (date);
      
      int year    = calendar.get (calendar.YEAR);
      int monthIx = calendar.get (Calendar.MONTH);
      int day     = calendar.get (Calendar.DAY_OF_MONTH);
      
      return pad (day, 2) + "-" + monthName [monthIx] + "-" + pad (year, 4);
   }
   
   
   /**
    * Converts strings of the following format to java.util.Date.
    * <pre>
    *      date [time [timezone]]
    * </pre>
    * where
    * <pre>
    *      date = dd-MMM-yyyy | MM/dd/yyyy | yyyymmdd
    *      time = hh:mm[:ss]
    *      timezone = name | [+|-]hh[:]mm
    * </pre>
    * Timezone can be a name such as EST or the number of hours and
    * minutes from GMT, e.g., -0500.
    *
    */
   public static Date convertStringToDate (String dateString)
   throws ParseException
   {
      String          datePart = null;
      String          timePart = null;
      String          timezonePart = null;
      StringTokenizer st = new StringTokenizer (dateString);
      String          parseFormatString = "dd-MMM-yyyy";
      String          reformattedDateString = "";
      
      if (st.hasMoreTokens ())
      {
         datePart = st.nextToken ();
         
         if (datePart.indexOf ("-") != -1)
            parseFormatString = "dd-MMM-yyyy";
         else if (datePart.indexOf ("/") != -1)
            parseFormatString = "MM/dd/yyyy";
         else
            parseFormatString = "yyyyMMdd";
         
         reformattedDateString = datePart;
      }
      
      if (st.hasMoreTokens ())
      {
         timePart = st.nextToken ();
         if (timePart.length () == 5)
            parseFormatString += " HH:mm";
         else
            parseFormatString += " HH:mm:ss";
         
         reformattedDateString += " " + timePart;
      }
      
      if (st.hasMoreTokens ())
      {
         timezonePart = st.nextToken ();
         parseFormatString += " z";
         if (timezonePart.startsWith ("+") || timezonePart.startsWith ("-"))
         {
            if (timezonePart.length () == 5)
            {
               timezonePart = timezonePart.substring (0, 3) + ":" +
                  timezonePart.substring (3, 5);
            }
            if (timezonePart.length () != 6)
            {
               String msg;
               msg = "Invalid time zone in date string: " + dateString;
               int pos = datePart.length () + timePart.length ();
               throw new ParseException (msg, pos);
            }
         }
         reformattedDateString += " GMT " + timezonePart;
      }
      
      DateFormat df = new SimpleDateFormat (parseFormatString);
      Date d = df.parse (reformattedDateString);
      return d;
   }

   /*
    * Provides methods to create a standardized "pretty date" format that
    * can be used for display output but that can also be parsed back into Java
    * if need be.
    */
   public static String getPrettyDateFormatString()
   {
      return "EEE MMM dd HH:mm:ss z yyyy";
   }

   public static SimpleDateFormat getPrettyDateFormat()
   {
      return new SimpleDateFormat(getPrettyDateFormatString());
   }

   private static SimpleDateFormat prettyDateFormat = getPrettyDateFormat();

   public static String getPrettyDate()
   {
      return prettyDateFormat.format(new Date());
   }

   public static Date parsePrettyDate(String input) throws ParseException
   {
      return prettyDateFormat.parse(input);
   }
   
   
   /**
    * Converts strings of the following format to java.util.Date, adjusting
    * 2 digit years so that they fall into the range of 80 years before
    * to 20 years after the time of the call to this method.
    * <pre>
    *      date [time [timezone]]
    * </pre>
    * where
    * <pre>
    *      date = dd-MMM-yyyy | MM/dd/yyyy | yyyymmdd
    *      time = hh:mm[:ss]
    *      timezone = name | [+|-]hh[:]mm
    * </pre>
    * Timezone can be a name such as EST or the number of hours and
    * minutes from GMT, e.g., -0500.
    *
    */
   public static Date convertStringToDateAdjustingYear (String dateString)
   throws ParseException
   {
      String          datePart = null;
      String          timePart = null;
      String          timezonePart = null;
      StringTokenizer st = new StringTokenizer (dateString);
      String          parseFormatString = "dd-MMM-yy";
      String          reformattedDateString = "";
      
      if (st.hasMoreTokens ())
      {
         datePart = st.nextToken ();
         
         if (datePart.indexOf ("-") != -1)
            parseFormatString = "dd-MMM-yy";
         else if (datePart.indexOf ("/") != -1)
            parseFormatString = "MM/dd/yy";
         else
            parseFormatString = "yyMMdd";
         
         reformattedDateString = datePart;
      }
      
      if (st.hasMoreTokens ())
      {
         timePart = st.nextToken ();
         if (timePart.length () == 5)
            parseFormatString += " HH:mm";
         else
            parseFormatString += " HH:mm:ss";
         
         reformattedDateString += " " + timePart;
      }
      
      if (st.hasMoreTokens ())
      {
         timezonePart = st.nextToken ();
         parseFormatString += " z";
         if (timezonePart.startsWith ("+") || timezonePart.startsWith ("-"))
         {
            if (timezonePart.length () == 5)
            {
               timezonePart = timezonePart.substring (0, 3) + ":" +
                  timezonePart.substring (3, 5);
            }
            if (timezonePart.length () != 6)
            {
               String msg;
               msg = "Invalid time zone in date string: " + dateString;
               int pos = datePart.length () + timePart.length ();
               throw new ParseException (msg, pos);
            }
         }
         reformattedDateString += " GMT " + timezonePart;
      }
      
      DateFormat df = new SimpleDateFormat (parseFormatString);
      Date d = df.parse (reformattedDateString);
      return d;
   }
   
  
   public static String reformatDateString (String inDateString,
      String inSimpleDateFormatPattern,
      String outSimpleDateFormatPattern)
      throws Exception
   {
       SimpleDateFormat sdf =
         new SimpleDateFormat (inSimpleDateFormatPattern);
      Date d = sdf.parse (inDateString);
      sdf = new SimpleDateFormat (outSimpleDateFormatPattern);
      return sdf.format (d);
   }
   
   public static String convertTimeBetweenTimeZones (String inputTimeZone, 
                                                     String inputSimpleDateFormat, 
                                                     String inputTime,
                                                     String outputTimeZone,
                                                     String outputSimpleDateFormat)
   throws Exception
   {
      checkTimeZoneId (inputTimeZone);
      checkTimeZoneId (outputTimeZone);
      
      TimeZone myInputTimeZone = TimeZone.getTimeZone (inputTimeZone);
      SimpleDateFormat inputSdf = new SimpleDateFormat (inputSimpleDateFormat);
      inputSdf.setTimeZone (myInputTimeZone);
      Date myInputDate = inputSdf.parse (inputTime);
      
      TimeZone myOutputTimeZone = TimeZone.getTimeZone (outputTimeZone);
      SimpleDateFormat outputSdf = new SimpleDateFormat (outputSimpleDateFormat);
      outputSdf.setTimeZone (myOutputTimeZone);
      String outputTime = outputSdf.format (myInputDate);

      return outputTime; 
   }
   
   
   
   public static void checkTimeZoneId (String id)
   {
      if (timeZoneList.contains (id))
         return;
      else
         throw new IllegalArgumentException (id + " is an invalid timezone.");
   }
   
   public static String getTimeZoneIds ()
   {
      return timeZoneList.toString();
   }
   
   public static String getCurrentTimeAsString (String inSimpleDateFormatPattern)
   {
      Date d = new Date ();
      SimpleDateFormat sdf = new SimpleDateFormat (inSimpleDateFormatPattern);
      return sdf.format (d);
   }

   public static String addDaysToDateAsString (String inDateString, String inSimpleDateFormatPattern, int numDays)
   throws Exception
   {
      SimpleDateFormat sdf =
         new SimpleDateFormat (inSimpleDateFormatPattern);
      Date d = sdf.parse (inDateString);
 
      GregorianCalendar cal = new GregorianCalendar ();
      cal.setTime (d);
      cal.add (GregorianCalendar.DAY_OF_YEAR, numDays);
      d = cal.getTime ();
      
      return sdf.format (d);         
   }
   
   public static String getCurrentTimeInXmlFormat ()
   throws Exception
   {
      GregorianCalendar gCal = (GregorianCalendar) GregorianCalendar.getInstance ();
      DatatypeFactory f = DatatypeFactory.newInstance ();
      XMLGregorianCalendar xCal = f.newXMLGregorianCalendar (gCal);
      return xCal.toXMLFormat ();
   }
   
   public static String reformatDateToXmlFormat (String inSimpleDateFormatPattern,
      String inDateString)
      throws Exception
   {
      SimpleDateFormat sdf =  new SimpleDateFormat (inSimpleDateFormatPattern);
      Date d = sdf.parse (inDateString);
      GregorianCalendar gCal = (GregorianCalendar) GregorianCalendar.getInstance ();
      gCal.setTime (d);
      DatatypeFactory f = DatatypeFactory.newInstance ();
      XMLGregorianCalendar xCal = f.newXMLGregorianCalendar (gCal);
      return xCal.toXMLFormat ();
   }   
   
   public static String dateAndTimeRightNow (String timeZone)
   {
      Calendar rightNow = Calendar.getInstance ();
      if (!timeZone.equals (""))
      {
         TimeZone tz = TimeZone.getTimeZone (timeZone);
         rightNow.setTimeZone (tz);
      }
      
      return(getCalendarString (rightNow));
   }
   
   
    /* Return the current date and time in the format of:
       YYYYMMCCCDDHHMMSSIII
       note: CCC is Character month (JAN, FEB ..),
             III is milliseconds
     */
   public static String getCalendarString (Calendar cal)
   {
      return(
         StringUtil.right (String.valueOf (cal.get (Calendar.YEAR        )  ),4,'0') +
         StringUtil.right (String.valueOf (cal.get (Calendar.MONTH       )+1),2,'0') +
         monthName[cal.get (Calendar.MONTH       )]          +
         StringUtil.right (String.valueOf (cal.get (Calendar.DAY_OF_MONTH)  ),2,'0') +
         StringUtil.right (String.valueOf (cal.get (Calendar.HOUR_OF_DAY )  ),2,'0') +
         StringUtil.right (String.valueOf (cal.get (Calendar.MINUTE      )  ),2,'0') +
         StringUtil.right (String.valueOf (cal.get (Calendar.SECOND      )  ),2,'0') +
         StringUtil.right (String.valueOf (cal.get (Calendar.MILLISECOND )  ),3,'0'));
   }
   
   
   public static String pad (int value, int width)
   {
      String text = value + "";
      
      if (value < 0)
      {
         text = text.substring (1);
         width -= 1;
      }
      
      while (text.length () < width)
         text = "0" + text;
      
      if (value < 0)
         text = "-" + text;
      
      return text;
   }
   
   
   /**
    * Insert the method's description here.
    * Creation date: (3/5/2003 9:37:17 AM)
    * Converts format
    *	MM/DD/YY HH:MM AM|PM to MM/DD/YYYY H:M:S
    */
   public static String msProjectDatetimeToOracleDatetime (String msDate)
   {
      //Strip out all / and :
      String strippedDate;
      strippedDate = StringUtil.replace (msDate      ,"/"," ");
      strippedDate = StringUtil.replace (strippedDate,":"," ");
      
      // Add 12 hours to non 12:00 PM dates
      int hour = Integer.parseInt (StringUtil.word (strippedDate,4));
      if (msDate.indexOf ("PM") != -1 && hour != 12)
         hour = hour + 12;
      // Subtract 12 hours from 12:00 AM dates
      if (msDate.indexOf ("AM") != -1 && hour == 12)
         hour = hour - 12;
      
      String date =	StringUtil.word (strippedDate,1)+"/"+
         StringUtil.word (strippedDate,2)+"/20"+
         StringUtil.word (strippedDate,3)+" "+
         String.valueOf (hour)  +":"+
         StringUtil.word (strippedDate,5)+":0";
      
      return date;
   }
   
   
   /**
    * Converts format
    *	MM/DD/YY HH:MM AM|PM to YYYYMMDDHH24MI
    */
   public static String msProjectDatetimeToYYYYMMDDHH24MI (String msDate)
   {
      //Strip out all / and :
      String strippedDate;
      strippedDate = StringUtil.replace (msDate      ,"/"," ");
      strippedDate = StringUtil.replace (strippedDate,":"," ");
      
      // Add 12 hours to non 12:00 PM dates
      int hour = Integer.parseInt (StringUtil.word (strippedDate,4));
      if (msDate.indexOf ("PM") != -1 && hour != 12)
         hour = hour + 12;
      // Subtract 12 hours from 12:00 AM dates
      if (msDate.indexOf ("AM") != -1 && hour == 12)
         hour = hour - 12;
      
      String date =	"20"+	StringUtil.right (StringUtil.word (strippedDate,3),2,'0')+
         StringUtil.right (StringUtil.word (strippedDate,1),2,'0')+
         StringUtil.right (StringUtil.word (strippedDate,2),2,'0')+
         StringUtil.right (String.valueOf (hour)           ,2,'0')+
         StringUtil.right (StringUtil.word (strippedDate,5),2,'0');
      return date;
   }
   
   
   public static Date dateAndTimeRightNowAdd (int days)
   {
      GregorianCalendar cal = new GregorianCalendar ();
      Date current = cal.getTime ();
      cal.add (GregorianCalendar.DAY_OF_YEAR, days);
      Date previous = cal.getTime ();
      return previous;
   }
   
   /*
    * This method takes as input a date/time value as a string, a java simple
    * date format that describes the input date/time value, an offset type as
    * "DAYS", "HOURS", "MINUTES", or "SECONDS", a signed integer representing
    * the amount of the offset and outputs the offset time as a string in the
    * specified input format.
    */
   public static String offsetDateAndTime (String inDateTimeString, String inSimpleDateFormatPattern, String offsetType, int offset)
   throws Exception
   {
      int myOffsetType = 0;
      if      ("DAYS".equalsIgnoreCase (offsetType))
         myOffsetType = GregorianCalendar.DAY_OF_YEAR;
      else if ("HOURS".equalsIgnoreCase (offsetType))
         myOffsetType = GregorianCalendar.HOUR_OF_DAY;
      else if ("MINUTES".equalsIgnoreCase (offsetType))
         myOffsetType = GregorianCalendar.MINUTE;
      else if ("SECONDS".equalsIgnoreCase (offsetType))
         myOffsetType = GregorianCalendar.SECOND;
      else
      {
         String errMsg = "Offset type must be either:  DAYS, HOURS, MINUTES" +
                         " or SECONDS";
         throw new IllegalArgumentException (errMsg);
      }
      
      SimpleDateFormat sdf = new SimpleDateFormat (inSimpleDateFormatPattern);
      Date timeToOffset = sdf.parse (inDateTimeString);
      
      GregorianCalendar cal = new GregorianCalendar ();
      cal.setTime (timeToOffset);
      cal.add (myOffsetType, offset);
      Date offsetTime = cal.getTime ();
      
      return sdf.format (offsetTime);
   }
   
   
   public static boolean date1GTdate2 (String inDateString1, String inSimpleDateFormatPattern1, String inDateString2, String inSimpleDateFormatPattern2)
   throws Exception
   {
      return compareDates ("GT", inDateString1, inSimpleDateFormatPattern1, inDateString2, inSimpleDateFormatPattern2);
   }
   
   public static boolean compareDates (String comparison, String inDateString1, String inSimpleDateFormatPattern1, String inDateString2, String inSimpleDateFormatPattern2)
   throws Exception
   {  
      SimpleDateFormat sdf1 = new SimpleDateFormat (inSimpleDateFormatPattern1);
      Date d1 = sdf1.parse (inDateString1);
      GregorianCalendar c1 = new GregorianCalendar ();
      c1.setTime (d1); 
      
      SimpleDateFormat sdf2 = new SimpleDateFormat (inSimpleDateFormatPattern2);
      Date d2 = sdf2.parse (inDateString2);
      GregorianCalendar c2 = new GregorianCalendar ();
      c2.setTime (d2); 
      
      int diff = c1.compareTo(c2);
      
      if      ("LT".equalsIgnoreCase (comparison))
      {
         if (diff < 0)
            return true;
         else
            return false;
      }
      else if ("LE".equalsIgnoreCase (comparison))
      {
         if (diff <= 0)
            return true;
         else
            return false;
      }
      else if ("EQ".equalsIgnoreCase (comparison))
      {
         if (diff == 0)
            return true;
         else
            return false;
      }
      else if ("GE".equalsIgnoreCase (comparison))
      {
         if (diff >= 0)
            return true;
         else
            return false;
      }
      else if ("GT".equalsIgnoreCase (comparison))
      {
         if (diff > 0)
            return true;
         else
            return false;
      }
      else
      {
         String errMsg = "Comparison type must be either:  LT, LE, EQ, GE, GT";
         throw new IllegalArgumentException (errMsg);
      }
   }
   
   public static boolean compareXmlDates (String comparison, String inXmlDate1, String inXmlDate2)
   throws Exception
   {
      String errMsg = null;
      DatatypeFactory f = DatatypeFactory.newInstance ();
      XMLGregorianCalendar xc1 = f.newXMLGregorianCalendar (inXmlDate1);
      XMLGregorianCalendar xc2 = f.newXMLGregorianCalendar (inXmlDate2);
      int diff = xc1.compare (xc2);

      if (diff == DatatypeConstants.INDETERMINATE)
      {
         errMsg = "Comparison is indeterminate";
         throw new IllegalArgumentException (errMsg);  
      }
      else if ("LT".equalsIgnoreCase (comparison))
      {
         if (diff == DatatypeConstants.LESSER)
            return true;
         else
            return false;
      }
      else if ("LE".equalsIgnoreCase (comparison))
      {
         if (diff == DatatypeConstants.LESSER || diff == DatatypeConstants.EQUAL)
            return true;
         else
            return false;
      }
      else if ("EQ".equalsIgnoreCase (comparison))
      {
         if (diff == DatatypeConstants.EQUAL)
            return true;
         else
            return false;
      }
      else if ("GE".equalsIgnoreCase (comparison))
      {
         if (diff == DatatypeConstants.GREATER || diff == DatatypeConstants.EQUAL)
            return true;
         else
            return false;
      }
      else if ("GT".equalsIgnoreCase (comparison))
      {
         if (diff == DatatypeConstants.GREATER)
            return true;
         else
            return false;
      }
      else
      {
         errMsg = "Comparison type must be either:  LT, LE, EQ, GE, GT";
         throw new IllegalArgumentException (errMsg);
      }
   }
           
   public static boolean xmlDate1GTxmlDate2 (String inXmlDate1, String inXmlDate2)
   throws Exception
   {
      return compareXmlDates ("GT", inXmlDate1, inXmlDate2);
   }

   public static String reformatXmlDate (String xmlDate, String newDateFormatString)
   throws Exception
   {
       DatatypeFactory df = DatatypeFactory.newInstance ();
       XMLGregorianCalendar xgc = df.newXMLGregorianCalendar (xmlDate);

       SimpleDateFormat sdf = new SimpleDateFormat (newDateFormatString);
       return sdf.format (xgc.toGregorianCalendar ().getTime ());
   }
}

