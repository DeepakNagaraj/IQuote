package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

import xgen.util.xml.XMLDocument;

import org.xml.sax.Locator;

/**
 * A ftl specification defines the structure of a flat file. The ftl engine,
 * using this specification, can then convert a flat file into an XML document
 * or convert an XML document in a flat file.
 * <p>
 * The DTD for the XML document is automatically determined by the structure
 * the flat file. This DTD can also be generated, using the FTL engine.
 * <p>
 * An ftl specification defines the top-level record of a flat-file, by giving
 * it a line and a description the fields it contains.
 */
public class FtlSpec
implements Serializable
{
   /** supply serialVersionUID for interoperability with older versions*/
   private static final long serialVersionUID = 0000000000000000003L;

   /**
    * The location of source XML element for this object.
    */
   public transient Locator locator;

   /**
    * This object contains the original values for each
    * field specified by the user.
    */
   public FtlSpec original = null;

   /**
    * The name of the overall record, the flat file contains. This will be
    * name of the root element when flat file is converted to XML.
    */
   public String  name;
   public String  ov_name;
   /**
   * A list of <code>FieldDefs</code>, which correspond
   * to the XML elements <code>field-def</code>.
   */
   public List  fields = new LinkedList ();


   public Object copy ()
   {
      FtlSpec result = new FtlSpec ();
      copyFields (this, result);
      return result;
   }


   protected void copyFields (FtlSpec src, FtlSpec dest)
   {
      dest.original = src.original;
      dest.name = src.name;
      dest.ov_name = src.ov_name;
      dest.fields = src.fields;
   }


   /**
    * Returns an XML Document representation of this instance of the
    * class <code>FtlSpec</code>.

    * @param original Specifies whether the original
    * or the resolved document should be represented.
    */
   public XMLDocument toXMLDocument (boolean original)
   throws IOException
   {
      XMLDocument result = new XMLDocument ("ftl");
      FtlSpec instance = null;
      if (original)
      {
         if (this.original == null) return null;
         instance = (FtlSpec) this.original;
      }
      else
      {
         instance = this;
      }
      addAttributes (result, instance, original);
      addElements (result, instance, original);
      return result;
   }


   /**
    * Adds attributes to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the attribute values from.
    * @param original Specifies whether the original
    * or the resolved attributes should be represented.
    */
   protected void addAttributes (XMLDocument doc,
                                 FtlSpec instance,
                                 boolean original)
   throws IOException
   {
      if (original)
      {
         doc.addAttribute ("name", instance.ov_name);
      }
      else
      {
         doc.addAttribute ("name", instance.name);
      }
   }


   /**
    * Adds elements to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the elements from.
    * @param original Specifies whether the original
    * or the resolved elements should be represented.
    */
   protected void addElements (XMLDocument doc,
                               FtlSpec instance,
                               boolean original)
   throws IOException
   {
      XMLDocument temp = null;


      for (Iterator i = instance.fields.iterator (); i.hasNext ();)
      {
         FieldDef item = (FieldDef) i.next ();
         doc.addChild (item.toXMLDocument (original));
      }
   }


}
