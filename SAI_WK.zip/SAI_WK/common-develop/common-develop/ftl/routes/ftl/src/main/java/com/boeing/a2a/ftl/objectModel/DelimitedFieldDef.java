package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

import xgen.util.xml.XMLDocument;


/**
 * This class provides a Java representation of
 * the XML element <code>delimited-field</code>.
 */
public class DelimitedFieldDef extends FieldDef
implements Serializable
{
   /** supply serialVersionUID for interoperability with older versions*/
   private static final long serialVersionUID = 0000000000000000003L;

   /**
    * The description of the field.  Used when delimited file requires a
    * header record (e.g. CSV file that represents a spreadsheet)
    */
   public String  description;
   public String  ov_description;
   /**
    * The delimiter used between subsequent fields.
    *
    * If this field is contained within a delimited record, this value may
    * be inherited.
    */
   public String  delimiter;
   public String  ov_delimiter;
   /**
    * The default value to use for the field
    */
   public String  value;
   public String  ov_value;
   /**
    * Indicates whether this field should be output when transforming from
    * flat to xml.  Default value is false.
    */
   public String  omitXmlTag = "false";
   public String  ov_omitXmlTag;
   /**
    * Indicates whether values of this field should be trimmed when
    * written to a file.
    * The legal values for this attribute are <code>true</code> or
    * <code>false</code>. If this attribute is omitted then the
    * field will be trimmed.
    *
    * If this field is contained within a delimited record, this value may
    * be inherited.
    */
   public String  trim;
   public String  ov_trim;
   /**
    * If the field represents formatted contents of an Excel worksheet cell,
    * specifying this option will escape any embedded characters within the
    * fields the record contains. Two escaping styles are supported:  EXCEL or
    * UNIX formatting conventions.
    *
    * If UNIX is specified, if the field contains any embedded
    * field delimiter or EOL characters they will each be escaped by prefixing
    * a leading backspace character.
    *
    * If EXCEL is specified, embedded double quotes (") will be escaped with
    * another double quote and the whole field then surrounded with an
    * additional set of double quotes.  Embedded field delimiters or EOL
    * characters, will also be surrounded by double quotes. Any field that
    * contains a single quote will also be surrounded by double quotes.
    * As a result <em>1,400</em> would become <em>"1,400"</em> assuming that
    * the comma is the required field delimiter.
    *
    * If this field is contained within a delimited record, this value may
    * be inherited.
    */
   public String  escapingStyle;
   public String  ov_escapingStyle;


   public Object copy ()
   {
      DelimitedFieldDef result = new DelimitedFieldDef ();
      copyFields (this, result);
      return result;
   }


   protected void copyFields (DelimitedFieldDef src, DelimitedFieldDef dest)
   {
      super.copyFields (src, dest);
      dest.description = src.description;
      dest.ov_description = src.ov_description;
      dest.delimiter = src.delimiter;
      dest.ov_delimiter = src.ov_delimiter;
      dest.value = src.value;
      dest.ov_value = src.ov_value;
      dest.omitXmlTag = src.omitXmlTag;
      dest.ov_omitXmlTag = src.ov_omitXmlTag;
      dest.trim = src.trim;
      dest.ov_trim = src.ov_trim;
      dest.escapingStyle = src.escapingStyle;
      dest.ov_escapingStyle = src.ov_escapingStyle;
   }


   /**
    * Returns an XML Document representation of this instance of the
    * class <code>DelimitedFieldDef</code>.

    * @param original Specifies whether the original
    * or the resolved document should be represented.
    */
   public XMLDocument toXMLDocument (boolean original)
   throws IOException
   {
      XMLDocument result = new XMLDocument ("delimited-field");
      DelimitedFieldDef instance = null;
      if (original)
      {
         if (this.original == null) return null;
         instance = (DelimitedFieldDef) this.original;
      }
      else
      {
         instance = this;
      }
      addAttributes (result, instance, original);
      addElements (result, instance, original);
      return result;
   }


   /**
    * Adds attributes to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the attribute values from.
    * @param original Specifies whether the original
    * or the resolved attributes should be represented.
    */
   protected void addAttributes (XMLDocument doc,
                                 DelimitedFieldDef instance,
                                 boolean original)
   throws IOException
   {
      super.addAttributes (doc, instance, original);

      if (original)
      {
         doc.addAttribute ("description", instance.ov_description);
         doc.addAttribute ("delimiter", instance.ov_delimiter);
         doc.addAttribute ("value", instance.ov_value);
         doc.addAttribute ("omit-xml-tag", instance.ov_omitXmlTag);
         doc.addAttribute ("trim", instance.ov_trim);
         doc.addAttribute ("escaping-style", instance.ov_escapingStyle);
      }
      else
      {
         doc.addAttribute ("description", instance.description);
         doc.addAttribute ("delimiter", instance.delimiter);
         doc.addAttribute ("value", instance.value);
         doc.addAttribute ("omit-xml-tag", instance.omitXmlTag);
         doc.addAttribute ("trim", instance.trim);
         doc.addAttribute ("escaping-style", instance.escapingStyle);
      }
   }


   /**
    * Adds elements to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the elements from.
    * @param original Specifies whether the original
    * or the resolved elements should be represented.
    */
   protected void addElements (XMLDocument doc,
                               DelimitedFieldDef instance,
                               boolean original)
   throws IOException
   {
      XMLDocument temp = null;

      super.addElements (doc, instance, original);

   }


   public boolean omitXmlTag ()
   {
      if ("true".equals(omitXmlTag))
         return true;
      else
         return false;
   }



}
