package com.boeing.ai.common.components.ftl;

import java.nio.charset.StandardCharsets;

import org.apache.camel.Consumer;
import org.apache.camel.Processor;
import org.apache.camel.Producer;
import org.apache.camel.impl.DefaultEndpoint;
import org.apache.camel.spi.Metadata;
import org.apache.camel.spi.UriEndpoint;
import org.apache.camel.spi.UriParam;
import org.apache.camel.spi.UriPath;

import com.boeing.a2a.ftl.FtlProcessor;

/**
 * Represents a Ftl endpoint.
 */
@UriEndpoint(scheme = "ftl", title = "FTL", syntax="ftl:operation", producerOnly = true, label = "ftl")
public class FtlEndpoint extends DefaultEndpoint {
  

	@UriPath(enums = "flatToxml,xmlToflat") @Metadata(required = "true")
	private String operation;

	@UriParam @Metadata(required = "true")
	private String specFile;
	
	@UriParam
	private String encoding;
	
	private FtlProcessor ftlProcessor;
	
	public FtlEndpoint() {
    }

    public FtlEndpoint(String uri, FtlComponent component) {
        super(uri, component);
    }

    public FtlEndpoint(String endpointUri) {
        super(endpointUri);
    }

    public Producer createProducer() throws Exception {
        return new FtlProducer(this);
    }

    public Consumer createConsumer(Processor processor) throws Exception {
    	throw new UnsupportedOperationException(
    			"FTL does not support consumer pattern:" + getEndpointUri());
    }

    public boolean isSingleton() {
        return true;
    }

	/**
     * Some description of this option, and what it does
     */

    public String getSpecFile() {
		return specFile;
	}

	public void setSpecFile(String specFile) {
		this.specFile = specFile;
	}

	public String getEncoding() {
		return encoding;
	}

	public void setEncoding(String encoding) {
		this.encoding = encoding;
	}

	public FtlProcessor getFtlProcessor() {
		return ftlProcessor;
	}

	public void setFtlProcessor(FtlProcessor ftlProcessor) {
		this.ftlProcessor = ftlProcessor;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}
}
