package com.boeing.a2a.ftl;

import java.io.*;
import java.util.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;
import org.w3c.dom.*;
import com.boeing.a2a.util.xml.XMLUtils;


public class FtlXmlParser extends DefaultHandler
{
   public FtlXmlParser ()
   {
   }


   public XmlNode getDocument ()
   {
      return document;
   }


   private Stack   stack = new Stack ();
   private XmlNode currentNode = null;
   private XmlNode document = null;
   private int     numErrors = 0;
   private Locator locator;


   public void setDocumentLocator (Locator locator)
   {
      this.locator = locator;
   }


   public InputSource resolveEntity (
         java.lang.String publicId,
         java.lang.String systemId)
   throws SAXException
   {
      return null;
   }


   public void warning (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      System.out.println ("Line: " + line + " Warning: " +
         exception.getMessage ());
      numErrors += 1;
   }


   public void error (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      System.out.println ("Line: " + line + " Error: " +
         exception.getMessage ());
      numErrors += 1;
   }


   public void fatalError (SAXParseException exception)
   throws SAXException
   {
      int line = exception.getLineNumber ();
      System.out.println ("Line: " + line + " Fatal error: " +
         exception.getMessage ());
      numErrors += 1;
   }


   public void startElement(
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName,
         Attributes atts)
   throws SAXException
   {
      stack.push (currentNode);

      currentNode = new XmlNode (localName,
            new AttributesImpl (atts), new LocatorImpl (locator));

      if (document == null)
         document = currentNode;
   }


   public void endElement (
         java.lang.String namespaceURI,
         java.lang.String localName,
         java.lang.String qName)
   throws SAXException
   {
      XmlNode n = currentNode;

      currentNode = (XmlNode) stack.pop ();
      if (currentNode != null)
         currentNode.contents.add (n);
   }


   public void characters (char[] ch, int start, int length)
   throws SAXException
   {
      String s = new String (ch, start, length);
      if (currentNode != null)
         currentNode.contents.add (s);
   }
}
