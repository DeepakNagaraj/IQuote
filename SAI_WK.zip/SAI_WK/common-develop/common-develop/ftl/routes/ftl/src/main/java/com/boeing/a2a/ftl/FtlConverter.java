package com.boeing.a2a.ftl;

/**
 *  An FTL converter performs data conversions during FTL transformations.
 */
public interface FtlConverter
{
   /**
    * Converts a value from a specified source type to a specified target
    * type.
    * @param  value  the value to be converted.
    * @param  sourceType  the logical type of the value to be converted.
    * @param  targetType  the logical type the value should be converted to.
    * @return the converted value.
    */
   public String convert (String value, String sourceType, String targetType)
   throws Exception;
}
