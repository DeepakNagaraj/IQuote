package com.boeing.a2a.util.xml;

import java.io.*;
import java.util.*;

import org.w3c.dom.NamedNodeMap;

public class XMLDocument
{
   protected int indentAmount = 3;
   protected int margin = 0;
   protected Vector openElements = new Vector ();
   protected Writer out = null;


   public XMLDocument (OutputStream os)
   {
      out = new OutputStreamWriter (os);
   }


   public void close ()
   throws Exception
   {
      out.flush ();
   }


   public void openElement (String name)
   throws Exception
   {
      openElements.add (0, name);
      indent ();
      write ("<" + name + ">");
      newLine ();
      margin += indentAmount;
   }


   public void closeElement ()
   throws Exception
   {
      margin -= indentAmount;
      String name = (String) openElements.remove (0);
      indent ();
      write ("</" + name + ">");
      newLine ();
   }


   public void addElement (String name, String value)
   throws Exception
   {
      if (value != null)
      {
         if (value.length () == 0)
         {
            indent ();
            write ("<" + name + "/>");
            newLine ();
         }
         else
         {
            indent ();
            write ("<" + name + ">");
            write (XMLUtils.xmlEscape (value));
            write ("</" + name + ">");
            newLine ();
         }
      }
   }


   protected void newLine ()
   throws Exception
   {
      write ("\n");
   }


   protected void indent ()
   throws Exception
   {
      for (int i = 0; i < margin; i++)
      {
         write (" ");
      }
   }


   protected void write (String s)
   throws Exception
   {
      out.write (s);
   }
/*

public static boolean getBooleanAttribute(String attribute, NamedNodeMap atts) {
    String attString = getAttribute(attribute, atts);
    return getBooleanFromString(attString);
  }
  */
}
