package com.boeing.a2a.ftl.objectModel;

import java.util.*;
import java.io.*;

import xgen.util.xml.XMLDocument;


/**
 * This class provides a Java representation of
 * the XML element <code>datetime</code>.
 */
public class DateTimeFieldDef extends FieldDef
implements Serializable
{
   /** supply serialVersionUID for interoperability with older versions*/
   private static final long serialVersionUID = 0000000000000000003L;



   public Object copy ()
   {
      DateTimeFieldDef result = new DateTimeFieldDef ();
      copyFields (this, result);
      return result;
   }


   protected void copyFields (DateTimeFieldDef src, DateTimeFieldDef dest)
   {
      super.copyFields (src, dest);
   }


   /**
    * Returns an XML Document representation of this instance of the
    * class <code>DateTimeFieldDef</code>.

    * @param original Specifies whether the original
    * or the resolved document should be represented.
    */
   public XMLDocument toXMLDocument (boolean original)
   throws IOException
   {
      XMLDocument result = new XMLDocument ("datetime");
      DateTimeFieldDef instance = null;
      if (original)
      {
         if (this.original == null) return null;
         instance = (DateTimeFieldDef) this.original;
      }
      else
      {
         instance = this;
      }
      addAttributes (result, instance, original);
      addElements (result, instance, original);
      return result;
   }


   /**
    * Adds attributes to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the attribute values from.
    * @param original Specifies whether the original
    * or the resolved attributes should be represented.
    */
   protected void addAttributes (XMLDocument doc,
                                 DateTimeFieldDef instance,
                                 boolean original)
   throws IOException
   {
      super.addAttributes (doc, instance, original);

      if (original)
      {
      }
      else
      {
      }
   }


   /**
    * Adds elements to the XMLDocument.
    *
    * @param doc Specifies which document to 
    * add the values to.
    * @param instance Specifies which instance to 
    * obtain the elements from.
    * @param original Specifies whether the original
    * or the resolved elements should be represented.
    */
   protected void addElements (XMLDocument doc,
                               DateTimeFieldDef instance,
                               boolean original)
   throws IOException
   {
      XMLDocument temp = null;

      super.addElements (doc, instance, original);

   }


}
