package xgen.util.xml;


import java.io.*;
import java.util.*;
import java.lang.reflect.*;

public class XMLDocument
{
   String name;
   String value;
   List <XMLDocument> children = new LinkedList ();
   List <XMLDocument> attributes = new LinkedList ();
   boolean isEmpty = true;


   public XMLDocument (String name)
   {
      this.name = name;
   }


   public XMLDocument (String name, String value)
   {
      this.name = name;
      if (value != null)
      { 
         this.value = value;
         isEmpty = false;
      }
   }

   public XMLDocument (String name, Number value)
   {
      this.name = name;
      if (value != null)
      { 
         this.value = value + "";
         isEmpty = false;
      }
   }

   public void addAttribute (String name, String value)
   {
      if (value != null)
      {
         XMLDocument attr = new XMLDocument (name, value);
         attributes.add (attr);
      }
   }


   public void addAttribute (String name, Number value)
   {
      if (value != null)
      {
         XMLDocument attr = new XMLDocument (name, value + "");
         attributes.add (attr);
      }
   }


   public void addChild (XMLDocument child)
   {
      if (child != null)
      {
         children.add (child);
         isEmpty = false;
      }
   }


   public String toString ()
   {
      return toString (this, 0);
   }


   protected String toString (XMLDocument d, int indent)
   {
      StringBuffer result = new StringBuffer ();

      appendBlanks (result, indent);
      result.append ("<");
      result.append (d.name);

      int count = 0;
      for (XMLDocument a: d.attributes)
      {
         count += 1;
         if (count == 1)
         {
            result.append (" ");
         }
         else
         {
            result.append ("\n");
            appendBlanks (result, indent);
            result.append ("  ");
         }
         result.append (a.name + "=\"" + xmlEscape (a.value) + "\"");
      }
      if (d.isEmpty)
      {
         result.append ("/>");
      }
      else if (d.value != null)
      {
         result.append (">");
         result.append (xmlEscape (d.value));
         result.append ("</");
         result.append (d.name);
         result.append (">");
      }
      else
      {
         result.append (">\n");
         for (XMLDocument c: d.children)
         {
            result.append (toString (c, indent + 3));
         }
         appendBlanks (result, indent);
         result.append ("</");
         result.append (d.name);
         result.append (">");
      }
      result.append ("\n");

      return result.toString ();
   }


   protected void appendBlanks (StringBuffer b, int count)
   {
      for (int i = 1; i <= count; i++)
      {
         b.append (" ");
      }
   }


   public static XMLDocument toXMLDocument (Object o)
   throws Exception
   {
         return toXMLDocument (o, false);
   }


   public static XMLDocument toXMLDocument (Object o, boolean omitPackageNames)
   throws Exception
   {
      if (o == null)
      {
         return null;
      }
      else
      {
         return toXMLDocument (null, o, omitPackageNames);
      }
   }


   protected static XMLDocument toXMLDocument (String name,
                                               Object o,
                                               boolean omitPackageNames)
   throws Exception
   {
      XMLDocument result = null;
      String className = null;
      String xmlName = null;

      Class c = o.getClass ();

      if (omitPackageNames)
      {
         className = c.getSimpleName ();
      }
      else
      {
         className = c.getName ();
      }
      xmlName = className.replace ('$', '-');

      if (o instanceof String)
      {
         if (name == null)
         {
            result = new XMLDocument (xmlName, o.toString ());
         }
         else
         {
            result = new XMLDocument (name, o.toString ());
         }
      }
      else if (o instanceof Boolean)
      {
         if (name == null)
         {
            result = new XMLDocument (xmlName, o.toString ());
         }
         else
         {
            result = new XMLDocument (name, o.toString ());
         }
      }
      else if (o instanceof Character)
      {
         if (name == null)
         {
            result = new XMLDocument (xmlName, o.toString ());
         }
         else
         {
            result = new XMLDocument (name, o.toString ());
         }
      }
      else if (o instanceof Number)
      {
         if (name == null)
         {
            result = new XMLDocument (xmlName, o.toString ());
         }
         else
         {
            result = new XMLDocument (name, o.toString ());
         }
      }
      else if (c.isPrimitive ())
      {
         if (name == null)
         {
            result = new XMLDocument (xmlName, o.toString ());
         }
         else
         {
            result = new XMLDocument (name, o.toString ());
         }
      }
      else if (o instanceof java.util.List)
      {
         if (name == null)
         {
            name = "root";
         }
         result = new XMLDocument (name);
         for (Iterator i = ((List)o).iterator (); i.hasNext ();)
         {
            Object child = i.next ();
            result.addChild (toXMLDocument (null, child, omitPackageNames));
         }
      }
      else
      {
         result = new XMLDocument (xmlName);
         Field fields[] = c.getFields ();
         for (int i = 0; i < fields.length; i++)
         {
            Field field = fields [i];

            Object value = field.get (o);
            if (value != null)
            {
               result.addChild (
                 toXMLDocument (field.getName (), value, omitPackageNames));
            }
         }
         if (name != null)
         {
            XMLDocument finalResult = new XMLDocument (name);
            finalResult.addChild (result);
            result = finalResult;
         }
      }
      return result;
   }


   public static String xmlEscape (String s)
   {
      if (s == null)
         return null;
      
      int length = s.length ();
      StringBuffer retval = new StringBuffer (length + 100);
      
      // (the default StringBuffer is very short;
      //  we don't have to get this exactly right, because
      //  it will expand if necessary)
      
      for (int i = 0; i < length; i++)
      {
         char c = s.charAt (i);
         switch (c)
         {
            case '<':
               retval.append ("&lt;");
               break;
            case '>':
               retval.append ("&gt;");
               break;
            case '&':
               retval.append ("&amp;");
               break;
            case '\"':
               retval.append ("&quot;");
               break;
            case '\'':
               retval.append ("&#39;");
               break;
            default:
               retval.append (c);
               break;
         }
      }
      return retval.toString ();
   }
}
