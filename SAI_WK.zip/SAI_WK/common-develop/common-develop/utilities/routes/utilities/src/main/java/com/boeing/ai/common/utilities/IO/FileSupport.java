/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : FileSupport.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.IO;
/*---------------------------------------------------------------------------*/
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
/*---------------------------------------------------------------------------*/
public class FileSupport {
    // Implementation of File.Copy)
    public static void copyFile(String srcFile,String destFile, boolean canOverwrite) throws IOException {
        if (!canOverwrite && new File(destFile).exists())
            throw new IOException("File exists");

        FileChannel srcChannel = new FileInputStream(srcFile).getChannel();
        FileChannel dstChannel = new FileOutputStream(destFile).getChannel();
        while (true) {
            long txed = dstChannel.transferFrom(srcChannel, 0, srcChannel.size());
            if (txed == 0)
                break;
        }
        srcChannel.close();
        dstChannel.close();
    }
}

