/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : GroupCollection.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Text.RegularExpressions;
/*---------------------------------------------------------------------------*/
import java.util.regex.Matcher;
import com.boeing.ai.common.utilities.NotImplementedException;
/*---------------------------------------------------------------------------*/
public class GroupCollection {
    private Match match = null;

    public static GroupCollection mk(Match m) {
        GroupCollection ret = new GroupCollection();
        ret.match = m;
        return ret;
    }
    /***
     *
     * @param i
     * @return
     */
    public Group get(int i) {
        Group ret = new Group();
        ret.setMatch(this.match);
        ret.setIndex(i);
        return ret;
    }
    /***
     *
     * @param name
     * @return
     * @throws NotImplementedException
     */
    public Group get(String name) throws NotImplementedException {
        throw new NotImplementedException("No implementation for named groups in regular expressions");
    }
}

