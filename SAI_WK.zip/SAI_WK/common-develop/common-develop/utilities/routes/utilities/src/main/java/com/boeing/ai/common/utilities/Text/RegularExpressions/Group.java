/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : Group.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Text.RegularExpressions;
/*---------------------------------------------------------------------------*/
import java.util.regex.Matcher;
/*---------------------------------------------------------------------------*/
public class Group {
    private Match match = null;
    private int index = -1;
    /**
     * @return the matcher
     */
    public Match getMatch() {
        return match;
    }
    /**
     * @param matcher the matcher to set
     */
    public void setMatch(Match match) {
        this.match = match;
    }
    /**
     * @return the index
     */
    public int getIndex() {
        return index;
    }
    /**
     * @param index the index to set
     */
    public void setIndex(int index) {
        this.index = index;
    }
    /**
     * @return the string matched by group
     * If index is default then the whole match, else the group(index)
     */
    public String getValue() {
        return (index >= 0 ? match.getMatcher().group(index) : match.getMatcher().group());
    }
}

