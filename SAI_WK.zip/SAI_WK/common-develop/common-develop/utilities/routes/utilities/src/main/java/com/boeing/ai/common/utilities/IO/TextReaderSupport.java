/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : TextReaderSupport.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.IO;
/*---------------------------------------------------------------------------*/
import java.io.IOException;
import java.io.Reader;
import com.boeing.ai.common.utilities.WrappedException;
/*---------------------------------------------------------------------------*/
public class TextReaderSupport {
    // Implementation of TextReader.ReadToEnd()
    public static String readToEnd(Reader r) {
        StringBuilder sb = new StringBuilder();

        try {
            int c = r.read();

            while (c != -1) {
                sb.append((char)c);
                c = r.read();
            }
        } catch (IOException e) {
            throw new WrappedException("readToEnd", e);
        }

        return sb.toString();
    }
}

