/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : IPEndPoint.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Net;
/*---------------------------------------------------------------------------*/
import java.net.InetAddress;
import com.boeing.ai.common.utilities.Net.Sockets.AddressFamily;
/*---------------------------------------------------------------------------*/
public class IPEndPoint extends EndPoint {
    public static final int MaxPort = 0x0000FFFF;
    public static final int MinPort = 0x00000000;
    private IPAddress ipAddress;
    private AddressFamily addressFamily;
    private int port = 0;
    /**
     * @return the address
     */
    public IPAddress getIPAddress() {
        return ipAddress;
    }
    /**
     * @param address the address to set
     */
    public void setIPAddress(IPAddress address) {
        this.ipAddress = address;
    }

    @Override
    public AddressFamily getAddressFamily() {
        return addressFamily;
    }
    /**
     * @return the port
     */
    public int getPort() {
        return port;
    }
    /**
     * @param port the port to set
     */
    public void setPort(int port) {
        this.port = port;
    }

    public IPEndPoint(byte[] address, int port) {
        setIPAddress(new IPAddress(address));
        setPort(port);
    }

    public IPEndPoint(IPAddress address, int port) {
        setIPAddress(address);
        setPort(port);
    }
    /**
     *
     * @return If true, provides an IP address that indicates that the server must listen for client activity on all network interfaces
     */
    public boolean isAny() {
        return ipAddress != null && ipAddress.isAny();
    }
}

