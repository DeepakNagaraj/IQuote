/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : XmlElement.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Xml;
/*---------------------------------------------------------------------------*/
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
/*---------------------------------------------------------------------------*/
public class XmlElement extends XmlLinkedNode {
    protected XmlElement() {

    }
    public XmlElement(Element e) {
        setNode(e);
    }

    private Element getElement() {
        return (Element)getNode();
    }

    protected void getOuterXml(StringBuffer sb) {
        String tag = getName();

        sb.append("<");
        sb.append(tag);
        for (XmlAttribute a : getAttributes()) {
            sb.append(" ");
            a.getOuterXml(sb);
        }
        sb.append(">");
        for (XmlNode n : getChildNodes()) {
            n.getOuterXml(sb);
        }
        sb.append("</" + tag + ">");

    }

    public boolean hasAttribute(String att) {
        return getElement().hasAttribute(att);
    }

    public String getAttribute(String att) {
        return getElement().getAttribute(att);
    }

    public boolean hasAttributes() {
        return getElement().hasAttributes();
    }

    public XmlNodeList getElementsByTagName(String name) {
        return new XmlNodeList(((Element)getNode()).getElementsByTagName(name));
    }

    public void removeAttribute(String att) {
        getElement().removeAttribute(att);
    }

    public void setAttribute(String att, String val) {
        getElement().setAttribute(att, val);
    }

    public void setAttributeNS(String uri, String att, String val) {
        getElement().setAttributeNS(uri, att, val);
    }

    public void setAttributeNode(XmlAttribute att) {
        getElement().setAttributeNode((Attr)att.getNode());
    }

    public short getNodeType() {
        return getElement().getNodeType();
    }
}

