/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : Match.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Text.RegularExpressions;
/*---------------------------------------------------------------------------*/
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/*---------------------------------------------------------------------------*/
public class Match {
    private Matcher matcher = null;
    private boolean lastMatchSuccess = false;
    private int lastMatchStartIdx = 0;
    private int lastMatchLength = 0;
    private String input = "";
    private Pattern pat = null;

    /**
     * @return the matcher
     */
    public Matcher getMatcher() {
        return matcher;
    }

    /**
     * @param matcher the matcher to set
     */
    public void setMatcher(Matcher matcher) {
        this.matcher = matcher;
    }

    /**
     * @return the string matched by the last match
     */
    public String getValue() {
        return matcher.group();
    }

    /**
     * @return the string matched by the last match
     */
    public boolean getSuccess() {
        return lastMatchSuccess;
    }

    /**
     * @return the length of string matched by the last match
     */
    public int length() {
        return lastMatchLength;
    }

    /**
     * @return the start index of string matched by the last match
     */
    public int start() {
        return lastMatchStartIdx;
    }

    public Match nextMatch() {
        return mk(this.pat, this.input,
                  this.lastMatchLength == 0 ? this.lastMatchStartIdx + 1 : this.lastMatchStartIdx + this.lastMatchLength);
    }

    public static Match mk(Pattern pat, String input, int startat) {
        Match ret = new Match();
        ret.pat = pat;
        ret.input = input;
        ret.matcher = pat.matcher(input);
        ret.lastMatchSuccess = ret.matcher.find(startat);
        if (ret.lastMatchSuccess) {
            ret.lastMatchStartIdx = ret.matcher.start();
            ret.lastMatchLength = ret.matcher.end() -ret.matcher.start();
        }
        return ret;
    }

    public static Match mk(Pattern pat, String input) {
        return mk(pat, input, 0);
    }

    public static List<Match> mkMatches(Pattern pat, String input) {
        List<Match> ret = new ArrayList<Match>();
        Match m = mk(pat, input);
        while (m.getSuccess()) {
            ret.add(m);
            m = m.nextMatch();
        }
        return ret;
    }
}

