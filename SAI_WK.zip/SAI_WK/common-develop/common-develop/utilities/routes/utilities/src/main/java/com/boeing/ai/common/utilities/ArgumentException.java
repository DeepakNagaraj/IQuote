/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : ArgumentException.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities;
/*---------------------------------------------------------------------------*/
public class ArgumentException extends IllegalArgumentException {
    /**
     *
     */
    private static final long serialVersionUID = -4437546264011007931L;
    private String param = "";

    /**
     *
     */
    public ArgumentException() {
    }

    /**
     * @param arg0
     */
    public ArgumentException(String arg0) {
        super(arg0);
    }

    /**
     * @param arg0
     */
    public ArgumentException(Throwable arg0) {
        super(arg0);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param arg0 the detail message
     * @param arg1 the cause
     */
    public ArgumentException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }

    /**
     * @param arg0 the detail message
     * @param arg1 the parameter name
     */
    public ArgumentException(String arg0, String arg1) {
        super(arg0);
        setParam(arg1);
    }

    /**
     * @param arg0  the detail message
     * @param p     the parameter name
     * @param arg1  the cause
     */
    public ArgumentException(String arg0, String p, Throwable arg1) {
        super(arg0, arg1);
        setParam(p);
    }

    /**
     * @param param the param to set
     */
    private void setParam(String param) {
        this.param = param;
    }

    /**
     * @return the param
     */
    public String getParam() {
        return param;
    }
}

