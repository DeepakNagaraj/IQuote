/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : ListSupport.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.JavaSupport.util;
/*---------------------------------------------------------------------------*/
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
/*---------------------------------------------------------------------------*/
public class ListSupport {
    // If the sequence of elements in stretch appears in l, then returns a new list, a copy of l without
    // the final such sequence. Otherwise returns l.
    public  static <T> List<T> removeFinalStretch(List<T> l, List<T> stretch) {
        List<T> ret = l;
        boolean found = true;
        int endIdx = l.size() - 1;
        while (endIdx >= stretch.size() - 1) {
            // is this the start of a sequence of stretch?
            found = true;
            for (int j = 0; j < stretch.size(); j++) {
                if (l.get(endIdx - j) != stretch.get(stretch.size() - j - 1)) {
                    found = false;
                    break;
                }
            }
            if (found) {
                break;
            }
            endIdx--;
        }
        if (found) {
            // stretch starts at l(endIdx - stretch.size())
            // don't use subList, create a totally new list.
            ret = new ArrayList<T>(l.size() - stretch.size());
            for (int i = 0; i <= endIdx - stretch.size(); i++) {
                ret.add(l.get(i));
            }
            for (int i = endIdx+1; i < l.size(); i++) {
                ret.add(l.get(i));
            }
        }

        return ret;
    }
}

