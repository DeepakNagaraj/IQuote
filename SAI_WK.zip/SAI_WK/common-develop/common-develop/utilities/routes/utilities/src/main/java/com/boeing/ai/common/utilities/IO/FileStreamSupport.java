/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : FileStreamSupport.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.IO;
/*---------------------------------------------------------------------------*/
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
/*---------------------------------------------------------------------------*/
public class FileStreamSupport  {
    private FileInputStream inputStream = null;
    private FileOutputStream outputStream = null;

    public FileStreamSupport(String path, FileMode mode, FileAccess access) throws FileNotFoundException {
        switch (access) {
        case Read:
            setInputStream(new FileInputStream(path));
            break;
        case Write:
            setOutputStream(new FileOutputStream(path, mode == FileMode.Append));
            break;
        case ReadWrite:
        default:
            break;
        }
    }

    /**
     * @param inputStream the inputStream to set
     */
    public void setInputStream(FileInputStream inputStream) {
        this.inputStream = inputStream;
    }

    /**
     * @return the inputStream
     */
    public FileInputStream getInputStream() {
        return inputStream;
    }

    /**
     * @param outputStream the outputStream to set
     */
    public void setOutputStream(FileOutputStream outputStream) {
        this.outputStream = outputStream;
    }

    /**
     * @return the outputStream
     */
    public FileOutputStream getOutputStream() {
        return outputStream;
    }
}

