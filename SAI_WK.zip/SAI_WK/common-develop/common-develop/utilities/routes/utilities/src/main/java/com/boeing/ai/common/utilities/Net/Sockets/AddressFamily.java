/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : AddressFamily.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Net.Sockets;
/*---------------------------------------------------------------------------*/
public enum AddressFamily {
    Unknown, 		//	Unknown address family.
    Unspecified, 	//	Unspecified address family.
    Unix, 			//	Unix local to host address.
    InterNetwork, 	//	Address for IP version 4.
    ImpLink, 		//	ARPANET IMP address.
    Pup, 			//	Address for PUP protocols.
    Chaos, 		//	Address for MIT CHAOS protocols.
    NS, 			//	Address for Xerox NS protocols.
    Ipx, 			//	IPX or SPX address.
    Iso, 			//	Address for ISO protocols.
    Osi, 			//	Address for OSI protocols.
    Ecma, 			//	European Computer Manufacturers Association (ECMA) address.
    DataKit, 		//	Address for Datakit protocols.
    Ccitt, 		//	Addresses for CCITT protocols, such as X.25.
    Sna, 			//	IBM SNA address.
    DecNet, 		//	DECnet address.
    DataLink, 		//	Direct data-link interface address.
    Lat, 			//	LAT address.
    HyperChannel, 	//	NSC Hyperchannel address.
    AppleTalk, 		//	AppleTalk address.
    NetBios, 		//	NetBios address.
    VoiceView, 		//	VoiceView address.
    FireFox, 		//	FireFox address.
    Banyan, 		//	Banyan address.
    Atm, 			//	Native ATM services address.
    InterNetworkV6, 	//	Address for IP version 6.
    Cluster, 		//	Address for Microsoft cluster products.
    Ieee12844, 		//	IEEE 1284.4 workgroup address.
    Irda, 			//	IrDA address.
    NetworkDesigners, //	Address for Network Designers OSI gateway-enabled protocols.
    Max 			//MAX address.
}

