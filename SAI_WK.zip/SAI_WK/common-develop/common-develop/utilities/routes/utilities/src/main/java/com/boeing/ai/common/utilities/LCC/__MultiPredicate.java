/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : __MultiPredicate.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.LCC;
/*---------------------------------------------------------------------------*/
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import com.boeing.ai.common.utilities.JavaSupport.util.ListSupport;
/*---------------------------------------------------------------------------*/
public class __MultiPredicate<T> implements Predicate<T> {
    public boolean invoke(T obj) throws Exception {
        List<Predicate<T>> copy, members = this.getInvocationList();
        synchronized (members) {
            copy = new LinkedList<Predicate<T>>(members);
        }
        boolean ret = false;
        for (Predicate<T> d : copy) {
            ret = d.invoke(obj);
        }
        return ret;
    }

    private List<Predicate<T>> _invocationList = new ArrayList<Predicate<T>>();
    public static <T>Predicate<T> combine(Predicate<T> a, Predicate<T> b) throws Exception {
        if (a == null)
            return b;

        if (b == null)
            return a;

        __MultiPredicate<T> ret = new __MultiPredicate<T>();
        ret._invocationList = a.getInvocationList();
        ret._invocationList.addAll(b.getInvocationList());
        return ret;
    }

    public static <T>Predicate<T> remove(Predicate<T> a, Predicate<T> b) throws Exception {
        if (a == null || b == null)
            return a;

        List<Predicate<T>> aInvList = a.getInvocationList();
        List<Predicate<T>> newInvList = ListSupport.removeFinalStretch(aInvList, b.getInvocationList());
        if (aInvList == newInvList) {
            return a;
        } else
        {
            __MultiPredicate<T> ret = new __MultiPredicate<T>();
            ret._invocationList = newInvList;
            return ret;
        }
    }

    public List<Predicate<T>> getInvocationList() throws Exception {
        return _invocationList;
    }
}

