/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : __MultiEventHandler.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.LCC;
/*---------------------------------------------------------------------------*/
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import com.boeing.ai.common.utilities.JavaSupport.util.ListSupport;
/*---------------------------------------------------------------------------*/
public class __MultiEventHandler<TEventArgs> implements EventHandler<TEventArgs> {
    public void invoke(Object other, TEventArgs e) throws Exception {
        List<EventHandler<TEventArgs>> copy, members = this.getInvocationList();
        synchronized (members) {
            copy = new LinkedList<EventHandler<TEventArgs>>(members);
        }
        for (EventHandler<TEventArgs> d : copy) {
            d.invoke(other, e);
        }
    }

    private List<EventHandler<TEventArgs>> _invocationList = new ArrayList<EventHandler<TEventArgs>>();
    public static <TEventArgs>EventHandler<TEventArgs> combine(EventHandler<TEventArgs> a, EventHandler<TEventArgs> b) throws Exception {
        if (a == null)
            return b;

        if (b == null)
            return a;

        __MultiEventHandler<TEventArgs> ret = new __MultiEventHandler<TEventArgs>();
        ret._invocationList = a.getInvocationList();
        ret._invocationList.addAll(b.getInvocationList());
        return ret;
    }

    public static <TEventArgs>EventHandler<TEventArgs> remove(EventHandler<TEventArgs> a, EventHandler<TEventArgs> b) throws Exception {
        if (a == null || b == null)
            return a;

        List<EventHandler<TEventArgs>> aInvList = a.getInvocationList();
        List<EventHandler<TEventArgs>> newInvList = ListSupport.removeFinalStretch(aInvList, b.getInvocationList());
        if (aInvList == newInvList) {
            return a;
        } else
        {
            __MultiEventHandler<TEventArgs> ret = new __MultiEventHandler<TEventArgs>();
            ret._invocationList = newInvList;
            return ret;
        }
    }

    public List<EventHandler<TEventArgs>> getInvocationList() throws Exception {
        return _invocationList;
    }
}

