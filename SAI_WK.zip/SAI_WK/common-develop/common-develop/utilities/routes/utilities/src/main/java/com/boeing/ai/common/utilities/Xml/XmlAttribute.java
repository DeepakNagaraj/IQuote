/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-14-2016
 * Authors      : Tim Schramer
 * File         : XmlAttribute.java - .NET type functionality in Java
 *                (based on code from:
 *                 https://github.com/twiglet/cs2j/tree/master/CSharpTranslator)
 *-----------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer      | New
 *              | 04-14-2016        |
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.utilities.Xml;
/*---------------------------------------------------------------------------*/
import org.w3c.dom.Attr;
/*---------------------------------------------------------------------------*/
public class XmlAttribute extends XmlNode {
    protected XmlAttribute() {

    }
    public XmlAttribute(Attr a) {
        setNode(a);
    }

    private Attr getAttribute() {
        return (Attr)getNode();
    }
    public String getValue() {
        return getAttribute().getValue();
    }

    public void setValue(String str) {
        getAttribute().setValue(str);
    }

    protected void getOuterXml(StringBuffer sb) {
        String value = getAttribute().getValue();
        sb.append(getAttribute().getName());
        sb.append("=\"");
        char c;

        for (int i = 0; i < value.length(); i++) {
            c = value.charAt(i);
            switch(c) {
            case '<' :
                sb.append("&lt;");
                break;
            case '>' :
                sb.append("&gt;");
                break;
            case '\'' :
                sb.append("&apos;");
                break;
            case '\"' :
                sb.append("&quot;");
                break;
            case '&' :
                sb.append("&amp;");
                break;
            case '\r' :
                sb.append("&#xD;");
                break;
            case '\t' :
                sb.append("&#x9;");
                break;
            case '\n' :
                sb.append("&#xA;");
                break;
            default :
                sb.append(c);
                break;
            }
        }
        sb.append("\"");
    }
}

