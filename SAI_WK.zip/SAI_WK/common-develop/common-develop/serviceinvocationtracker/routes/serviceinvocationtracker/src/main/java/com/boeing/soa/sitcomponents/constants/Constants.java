package com.boeing.soa.sitcomponents.constants;

public final class Constants {

	public static final String SUCCESS_MSG = "Successful to create CEERS event";
	public static final String VALIDATION_FAILURE_MSG = "SIT Request failed validation";
	
	public static final String CEERS_EVENT_ID = "CeersEventId";
	public static final String CEERS_GLOBAL_TRANSACTION_ID = "CeersGlobalTxId";
	public static final String CEERS_EVENT_GROUP = "CeersEventGroup";
	public static final String CEERS_EVENT_TIMESTAMP = "CeersEventTimestamp";
	public static final String CEERS_DATA_SENSITIVITY = "CeersDataSensitivity";
	public static final String CEERS_COMPONENT_NAME = "CeersComponentName";
	public static final String CEERS_APPLICATION_NAME = "CeersApplicationName";
	public static final String CEERS_MESSAGE_NAME = "CeersMessageName";
	public static final String CEERS_ENVIRONMENT_NAME = "CeersEnvironmentName";
	public static final String CEERS_SERVER_NAME = "CeersServerName";
	public static final String CEERS_TRANSFER_TYPE = "CeersTransferType";
	public static final String CEERS_METADATA = "CeersMetadata";
	public static final String CEERS_USERDATA = "CeersUserdata";
	
	public static final String SIT_CONSUMER = "consumer";
	public static final String SIT_PROVIDER = "provider";
	
	public static final String SINGLE_QUOTE ="\'";
	public static final String EQUALTO ="=";
	public static final String COMMA =",";
	
	
	
}