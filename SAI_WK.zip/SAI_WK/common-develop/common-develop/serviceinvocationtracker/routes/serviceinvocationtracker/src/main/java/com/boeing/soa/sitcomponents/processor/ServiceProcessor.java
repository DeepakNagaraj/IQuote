package com.boeing.soa.sitcomponents.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.boeing.soa.sit.ServiceInvocationRequest;
import com.boeing.soa.sit.ServiceInvocationResponse;
import com.boeing.soa.sit.StatusType;
import com.boeing.soa.sit.StatusFlagType;
import com.boeing.soa.sitcomponents.constants.Constants;


public class ServiceProcessor implements Processor{
	
	public void process(Exchange exchange) throws Exception {
		
		//ServiceInvocationRequest origRequest = new ServiceInvocationRequest();
		//origRequest = (ServiceInvocationRequest)exchange.getIn().getBody();
		
		ServiceInvocationResponse response = new ServiceInvocationResponse();
        StatusType responseStatus = new StatusType();
        
        responseStatus.setStatus(StatusFlagType.SUCCESS);      
        response.setStatus(responseStatus);
        
        response.setEventId(exchange.getProperty(Constants.CEERS_EVENT_ID).toString());
        response.setGlobalId(exchange.getProperty(Constants.CEERS_GLOBAL_TRANSACTION_ID).toString());
        
        exchange.getOut().setBody(response);
	  }
}
