package com.boeing.soa.sitcomponents.processor;

import java.util.Iterator;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import com.boeing.soa.sit.*;
import com.boeing.soa.sitcomponents.constants.Constants;

public class HeaderProcessor implements Processor {

	public void process(Exchange exchange) throws Exception {

		ServiceInvocationRequest sirObj = new ServiceInvocationRequest();
		sirObj = (ServiceInvocationRequest) exchange.getIn().getBody();

		/* Assign a Event ID, if none is provided in the input request */
		/*if (!sirObj.getEventId().isEmpty())
			exchange.setProperty(Constants.CEERS_EVENT_ID, sirObj.getEventId()
					.toString());
		else
			exchange.setProperty(Constants.CEERS_EVENT_ID, UUID.randomUUID()
					.toString());*/

		/* Assign a Global ID, if none is provided in the input request */
		if ( sirObj.getGlobalId() !=null && !sirObj.getGlobalId().isEmpty())
			exchange.setProperty(Constants.CEERS_GLOBAL_TRANSACTION_ID, sirObj
					.getGlobalId().toString());
		else
			exchange.setProperty(Constants.CEERS_GLOBAL_TRANSACTION_ID, UUID
					.randomUUID().toString());

		if (sirObj.getEventGroup() != null && !sirObj.getEventGroup().isEmpty())
			exchange.setProperty(Constants.CEERS_EVENT_GROUP, sirObj
					.getEventGroup().toString());
		else
			exchange.setProperty(Constants.CEERS_EVENT_GROUP, "Unspecified");

		exchange.setProperty(Constants.CEERS_EVENT_TIMESTAMP, sirObj
				.getEventTimeStamp().toString());
		exchange.setProperty(Constants.CEERS_DATA_SENSITIVITY, sirObj
				.getDataSensitivity().toString());
		exchange.setProperty(Constants.CEERS_COMPONENT_NAME, sirObj
				.getComponentName().toString());
		exchange.setProperty(Constants.CEERS_APPLICATION_NAME, sirObj
				.getServiceName().toString());
		exchange.setProperty(Constants.CEERS_MESSAGE_NAME, sirObj
				.getOperationName().toString());

		if (sirObj.getEnvironmentName() != null && !sirObj.getEnvironmentName().isEmpty())
			exchange.setProperty(Constants.CEERS_ENVIRONMENT_NAME, sirObj
					.getEnvironmentName().toString());

		if (sirObj.getServerName() != null && !sirObj.getServerName().isEmpty())
			exchange.setProperty(Constants.CEERS_SERVER_NAME, sirObj
					.getServerName().toString());

		// 'FieldName1’=‘Value1’,’FieldName2’=‘Value2’,...
		
		StringBuilder keyValueString  = new StringBuilder();
		String keyValue ="";
		com.boeing.soa.sit.Attribute sitAttr1 = null;
		
		if (sirObj.getInvocationDetail().getInvocationType() != null )
			
			if (sirObj.getInvocationDetail().getInvocationType().toString().toLowerCase().contains("send")){
			
			exchange.setProperty(Constants.CEERS_TRANSFER_TYPE, "SEND");
			
			keyValue = buildKeyValuePair("invocationType",sirObj.getInvocationDetail().getInvocationType().toString());		
			
			keyValueString.append(keyValue);
			
		}

			else if (sirObj.getInvocationDetail().getInvocationType().toString().toLowerCase().contains("receive")){
				
			exchange.setProperty(Constants.CEERS_TRANSFER_TYPE, "RCV");
				
			keyValue = buildKeyValuePair("invocationType",sirObj.getInvocationDetail().getInvocationType().toString());		
			
			keyValueString.append(keyValue);
			
			}

		
		
		if (sirObj.getInvocationDetail() != null
				&& sirObj.getInvocationDetail().getData() != null
				&& sirObj.getInvocationDetail().getData().getHeader() != null) {

			if (sirObj.getInvocationDetail().getData().getHeader().getMetadata() != null){
				
				Iterator<com.boeing.soa.sit.Attribute> metadataIterator = sirObj
						.getInvocationDetail().getData().getHeader().getMetadata()
						.getAttribute().iterator();
				while (metadataIterator.hasNext()) {
					sitAttr1 = new com.boeing.soa.sit.Attribute();

					sitAttr1 = metadataIterator.next();
					keyValue = buildKeyValuePair(sitAttr1.getKey().toString(),sitAttr1.getValue().toString());
				
					keyValueString.append(Constants.COMMA);
					keyValueString.append(keyValue);

				}
				
			}
			
			exchange.setProperty(Constants.CEERS_METADATA, keyValueString.toString());
			
			sitAttr1 = null;
			keyValue = new String();
			keyValueString = new StringBuilder();
			
			if (sirObj.getInvocationDetail().getData().getHeader().getUserdata() != null){
				
				Iterator<com.boeing.soa.sit.Attribute> userdataIterator = sirObj
						.getInvocationDetail().getData().getHeader().getUserdata()
						.getAttribute().iterator();
				while (userdataIterator.hasNext()) {
					sitAttr1 = new com.boeing.soa.sit.Attribute();

					sitAttr1 = userdataIterator.next();
					keyValue = buildKeyValuePair(sitAttr1.getKey().toString(),sitAttr1.getValue().toString());
				
					if (!keyValueString.toString().isEmpty())
					keyValueString.append(Constants.COMMA);
					keyValueString.append(keyValue);

				}
				
				if (sirObj.getConsumer() != null) {

					keyValue = buildKeyValuePair(Constants.SIT_CONSUMER,sirObj.getConsumer().toString());
					keyValueString.append(Constants.COMMA);
					keyValueString.append(keyValue);
				}

				if (sirObj.getProvider() != null) {

					keyValue = buildKeyValuePair(Constants.SIT_PROVIDER,sirObj.getProvider().toString());
					keyValueString.append(Constants.COMMA);
					keyValueString.append(keyValue);
				}
				
			}
			
			exchange.setProperty(Constants.CEERS_USERDATA, keyValueString.toString());
		}
		
		
		
		
		
	}
	
	

	public String buildKeyValuePair(String key , String value){
		
		StringBuilder sbObj  = new StringBuilder();
		
		sbObj.append(Constants.SINGLE_QUOTE);
		sbObj.append(key);
		sbObj.append(Constants.SINGLE_QUOTE);
		sbObj.append(Constants.EQUALTO);
		sbObj.append(Constants.SINGLE_QUOTE);
		sbObj.append(value);
		sbObj.append(Constants.SINGLE_QUOTE);
		
		
		return sbObj.toString();
	}
}