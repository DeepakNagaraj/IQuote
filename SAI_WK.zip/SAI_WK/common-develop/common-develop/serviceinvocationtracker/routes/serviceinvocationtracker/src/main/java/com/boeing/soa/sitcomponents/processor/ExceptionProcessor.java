package com.boeing.soa.sitcomponents.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.boeing.soa.sit.*;
import com.boeing.soa.sitcomponents.constants.*;


public class ExceptionProcessor implements Processor {

	public void process(Exchange exchange) throws Exception {
		
		ServiceInvocationResponse _return = new ServiceInvocationResponse();
		StatusType _returnStatus = new StatusType();
		
		
		Exception cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);

	
		_returnStatus.setStatus(StatusFlagType.FAILURE);
		
	
		if(cause.getClass().toString().toLowerCase().contains("validation"))
			_returnStatus.setStatusText(Constants.VALIDATION_FAILURE_MSG + "," + cause.getMessage().toString());
		else
	    _returnStatus.setStatusText(cause.getMessage().toString());

		
	    _return.setStatus(_returnStatus);
	    

	    
	    if (exchange.getProperty(Constants.CEERS_EVENT_ID) != null)
	    	_return.setEventId(exchange.getProperty(Constants.CEERS_EVENT_ID).toString());
	    
	    if (exchange.getProperty(Constants.CEERS_GLOBAL_TRANSACTION_ID) != null)
	    	_return.setGlobalId(exchange.getProperty(Constants.CEERS_GLOBAL_TRANSACTION_ID).toString());
    	
 
		exchange.getOut().setBody(_return);
	}

}
