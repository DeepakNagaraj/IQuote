ceers_route_tester: Camel CEERS Router Tester Project for Blueprint (OSGi) - Tim Schramer
=========================================================================================
A CEERS Audit Event is written to local directory using the CEERS Component call within the
route.  Change the value of "alternateLogFilePath" in blueprint.xml to control the location
or remove it completly to send Event to the CEERS Web Application.

System requirements
-------------------
Before building and running this exammple you need:

* Maven 3.1.1 or higher
* JDK 1.7 or 1.8
* JBoss Fuse 6
* utilities 1.0.1-SNAPSHOT or higher
* ceers 2.5.5-SNAPSHOT or higher

(See pom.xml and features\src\main\filtered-resources\features.xml for CEERS dependencies.)

To build this project use

    mvn clean install

To deploy the project in OSGi. For example using Apache Karaf.
You can run the following command from the shell:

  features:addurl mvn:com.boeing.ai.ceers_route_tester/ceers_route_tester-features/1.0.0-SNAPSHOT/xml/features
  features:install ceers_route_tester

Undeploy the Bundle
-------------------

To stop and undeploy the bundle in Fuse:

1. Enter `osgi:list` command to retrieve your bundle id
2. To stop and uninstall the bundle enter

        osgi:uninstall <id>