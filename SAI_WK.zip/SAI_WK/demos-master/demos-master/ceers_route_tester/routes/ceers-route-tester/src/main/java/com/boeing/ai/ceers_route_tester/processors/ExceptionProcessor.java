/*
 * Copyright 2016 (C) The Boeing Company
 * 
 * Created On   : 05-02-2016
 * Authors      : Tim Schramer
 * File         : ExceptionProcessor.java - Process Route Exceptions.
 *---------------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *---------------------------------------------------------------------------------
 * VERSION        AUTHOR                  DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                    CR NO
 *--------------|-----------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer          | New
 *              | 05-02-2016            | 
 *--------------|-----------------------|------------------------------------------
 */
/*-------------------------------------------------------------------------------*/
package com.boeing.ai.ceers_route_tester.processors;
/*-------------------------------------------------------------------------------*/
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.exception.ExceptionUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*-------------------------------------------------------------------------------*/
public class ExceptionProcessor implements Processor {

    private static final Logger LOG = LoggerFactory.getLogger(ExceptionProcessor.class);

    @Override
    public void process(Exchange exchange) {
        Throwable cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        String clazz = cause.getClass().getSimpleName();
        // do custom error handling if required based on clazz

        String errorMessage = cause.getMessage();
        // log message and print stack trace
        LOG.error(errorMessage);
        LOG.error(ExceptionUtils.getStackTrace(cause));
    }
}
