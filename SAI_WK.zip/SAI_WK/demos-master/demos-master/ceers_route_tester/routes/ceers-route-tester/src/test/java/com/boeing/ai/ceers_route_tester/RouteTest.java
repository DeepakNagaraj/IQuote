/*
 * Copyright 2016 (C) The Boeing Company
 * 
 * Created On   : 05-02-2016
 * Authors      : Tim Schramer
 * File         : RouteTest.java - Blueprint Unit Tester
 *---------------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *---------------------------------------------------------------------------------
 * VERSION        AUTHOR                  DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                    CR NO
 *--------------|-----------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer          | New
 *              | 05-02-2016            | 
 *--------------|-----------------------|------------------------------------------
 */
/*-------------------------------------------------------------------------------*/
package com.boeing.ai.ceers_route_tester;
/*-------------------------------------------------------------------------------*/
import org.apache.camel.test.blueprint.CamelBlueprintTestSupport;

import org.junit.Test;
/*-------------------------------------------------------------------------------*/
public class RouteTest extends CamelBlueprintTestSupport {

    @Override
    protected String getBlueprintDescriptor() {
        return "/OSGI-INF/blueprint/blueprint.xml";
    }

    @Test
    public void testRoute() throws Exception {
        // the route is timer based, so every 5th second a message is send
        // we should then expect at least one message
        getMockEndpoint("mock:result").expectedMinimumMessageCount(1);

        // assert expectations
        assertMockEndpointsSatisfied();
    }

}
