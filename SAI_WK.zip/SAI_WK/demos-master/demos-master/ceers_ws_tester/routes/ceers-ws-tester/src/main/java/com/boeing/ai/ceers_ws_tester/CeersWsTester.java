/*
 * Copyright 2016 (C) The Boeing Company
 * 
 * Created On   : 05-01-2016
 * Authors      : Tim Schramer
 * File         : CeersWsTester.java - Interface defines a single WebService method.
 *---------------------------------------------------------------------------------
 * Revision History (Release 1.0.0)
 *---------------------------------------------------------------------------------
 * VERSION        AUTHOR                  DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                    CR NO
 *--------------|-----------------------|------------------------------------------
 * -.-.-/1.0.0  | Tim Schramer          | New
 *              | 05-01-2016            | 
 *--------------|-----------------------|------------------------------------------
 */
/*-------------------------------------------------------------------------------*/
package com.boeing.ai.ceers_ws_tester;
/*-------------------------------------------------------------------------------*/
import javax.jws.WebService;
/*-------------------------------------------------------------------------------*/
// Add the @WebService annotation to mark this interface as the definition for our web service.
@WebService
public interface CeersWsTester {

    String generateEvents(String name) throws Exception;
}
