package ai.demos.contfeed;



/**
 * An interface for implementing Hello services.
 * add something 
 */

public interface Hello {

    String hello();
}
