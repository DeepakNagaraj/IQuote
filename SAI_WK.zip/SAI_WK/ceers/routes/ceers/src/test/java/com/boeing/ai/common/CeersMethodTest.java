/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : CeersMethodTest.java - Tester for CEERS API method calls.
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Updated tests to support AlternateLogging
 *              | 04-28-2016        | Event output option.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.components.ceers.CeersEventManagerImpl;
import com.boeing.ai.common.components.ceers.eventmanager.AuditEvent;
import com.boeing.ai.common.components.ceers.eventmanager.DataSensitivityType;
import com.boeing.ai.common.components.ceers.eventmanager.EventSeverity;
import com.boeing.ai.common.components.ceers.eventmanager.EventState;
import com.boeing.ai.common.components.ceers.eventmanager.EventTransferType;
import com.boeing.ai.common.components.ceers.eventmanager.NotificationEvent;
import com.boeing.ai.common.components.ceers.eventmanager.StateEvent;
import com.boeing.ai.common.components.ceers.exception.CeersException;

import java.lang.Thread;

import org.apache.camel.Exchange;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class CeersMethodTest {
    public static CeersEventManagerImpl em = new CeersEventManagerImpl();
    private static Boolean ignoreErrors = false;
    private static final Logger LOG = LoggerFactory.getLogger(Thread.currentThread().getStackTrace()[0].getClassName() );

    // Test sending Audit Event message
    public static String ceersAuditSend(Exchange exchange, String eventOutputDir) throws Exception {
        String eventID = "";

        try {

            LOG.info("About to make AuditEvent object");
            AuditEvent ae = em.newAuditEvent("CEERS_UNITTEST_SEND_AUDIT");
            ae.setApplicationName("CEERS_TESTER");
            ae.setIgnoreEventErrors(ignoreErrors);

            // UserData fields
            ae.setUserData("");
            ae.setUserDataField("StartAt0Length5", "BYTERANGE(0,5)");
            ae.setUserDataField("StartAt5Length10", "BYTERANGE(5,10)");

            // Extra MetaData field
            ae.setMetaDataField("ClassName", Thread.currentThread().getStackTrace()[0].getClassName());

            // Payload Info
            ae.setPayloadRefEventID("");
            ae.setPayloadMsgBuffer(exchange);
            ae.setPayloadLogAmount("BYTERANGE(0,20)");
            ae.setPayloadMsgHeaderField("HeaderField1", "value1");
            ae.setPayloadMsgHeaderField("HeaderField2", "value2");

            // Resubmit Info
            ae.setResubmitEventID("THIS");
            ae.setResubmitParametersField("Transport", "MQSC");
            ae.setResubmitParametersField("QmgrName", "MyQM");
            ae.setResubmitParametersField("QueueName", "MyQueue");

            // Transfer Type
            ae.setTransferType(EventTransferType.Send);

            // Alternate logging directory
            ae.setAlternateLogFilePath(eventOutputDir);

            // Send out the Audit Event
            eventID = em.sendAuditEvent(ae);
            LOG.info("AuditEvent, " + eventID + " Sent.");
        } catch (Exception e) {
            LOG.error("Exception while Unit Testing Audit send methods: " + e.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS Audit IgnoreErrors set to true. Unit testing not aborted.");
            } else {
                eventID = "";
            }
        }
        return eventID;
    }

    // Test sending State Event message
    public static String ceersStateSend(Exchange exchange, String eventOutputDir) throws Exception {
        String eventID = "";

        try {

            LOG.info("About to make StateEvent Object");
            StateEvent se = em.newStateEvent("CEERS_UNITTEST_SEND_STATE");
            se.setApplicationName("CEERS_TESTER");
            se.setIgnoreEventErrors(ignoreErrors);

            // UserData fields
            se.setUserData("");
            se.setUserDataField("DataName1", "DataValue1");
            se.setUserDataField("DataName2", "DataValue2");

            // Extra MetaData field
            se.setMetaDataField("ClassName", Thread.currentThread().getStackTrace()[0].getClassName());

            // Transaction State
            se.setTransactionState(EventState.Debug);

            // Alternate logging directory
            se.setAlternateLogFilePath(eventOutputDir);

            // Send out the State Event
            eventID = em.sendStateEvent(se);
            LOG.info("StateEvent, " + eventID + " Sent.");
        } catch (Exception e) {
            LOG.error("Exception while Unit Testing State send methods: " + e.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS State IgnoreErrors set to true. Unit testing not aborted.");
            } else {
                eventID = "";
            }
        }
        return eventID;
    }

    // Test sending Notification Event message including within an Exception.
    public static String ceersNotificationSend(Exchange exchange, String eventOutputDir) throws Exception {
        String eventID = "";

        try {

            LOG.info("About to make NotificationEvent Object");
            NotificationEvent ne = em.newNotificationEvent("CEERS_UNITTEST_SEND_NOTIFICATION");
            ne.setApplicationName("CEERS_TESTER");
            ne.setIgnoreEventErrors(ignoreErrors);

            // UserData fields
            ne.setUserData("");
            ne.setUserDataField("StartAt0Length5", "BYTERANGE(0,5)");
            ne.setUserDataField("StartAt5Length10", "BYTERANGE(5,10)");

            // Extra MetaData field
            ne.setMetaDataField("ClassName", Thread.currentThread().getStackTrace()[0].getClassName());

            // Payload Info
            ne.setPayloadRefEventID("");
            ne.setPayloadMsgBuffer(exchange);
            ne.setPayloadLogAmount("BYTERANGE(0,20)");
            ne.setPayloadMsgHeaderField("HeaderField1", "value1");
            ne.setPayloadMsgHeaderField("HeaderField2", "value2");

            // Resubmit Info
            ne.setResubmitEventID("THIS");
            ne.setResubmitParametersField("Transport", "MQSC");
            ne.setResubmitParametersField("QmgrName", "MyQM");
            ne.setResubmitParametersField("QueueName", "MyQueue");

            // Severity
            ne.setSeverity(EventSeverity.Warning);

            // Short Description
            ne.setShortDescription("Notification method test ShortDescription");

            // Detailed Description
            ne.setDetailedDescription("Notification method test DetailedDescription");

            // Alternate logging directory
            ne.setAlternateLogFilePath(eventOutputDir);

            // Send out the Notification Event
            eventID = em.sendNotificationEvent(ne);
            LOG.info("NotificationEvent, " + eventID + " Sent.");

            // Test Notification Event from Exception
            throw new CeersException("Test Exception for Notification Event");
        } catch (CeersException ce) {
            LOG.error(ce.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS IgnoreErrors set to true. Processing not aborted.");
            } else {
                // Send Notification Event with Exception info.
                NotificationEvent ne = em.newNotificationEvent("CEERS_UNITTEST_ERROR_NOTIFICATION", "TEST_GROUP", DataSensitivityType.BOEING_PROPRIETARY, EventSeverity.Error, "Test Exception handler", ce);
                ne.setApplicationName("CEERS_TESTER");
                ne.setIgnoreEventErrors(false);
                ne.setPayloadLogAmount("NONE");

                // Alternate logging directory
                ne.setAlternateLogFilePath(eventOutputDir);

                // Send out the Notification Event
                eventID = em.sendNotificationEvent(ne);
                LOG.info("NotificationExceptionEvent, " + eventID + " Sent.");
            }
        } catch (Exception e) {
            LOG.error("Exception while Unit Testing Notification send methods: " + e.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS Notification IgnoreErrors set to true. Unit testing not aborted.");
            } else {
                eventID = "";
            }
        }
        return eventID;
    }

    // Test Miscellaneous parameters by sending Notification Event message.
    public static String ceersMiscSend(Exchange exchange, String eventOutputDir) throws Exception {
        String eventID = "";

        try {
            LOG.info("About to start Misc Method Test");
            NotificationEvent ne = em.newNotificationEvent("CEERS_UNITTEST_SEND_MISC", EventSeverity.Severe, "Misc parameter method call test", "");
            ne.setApplicationName("CEERS_TESTER");
            ne.setIgnoreEventErrors(false);

            // Payload Info
            ne.setPayloadRefEventID("ORIGINAL");
            ne.setOriginalEventID(exchange.getProperty("CeersOriginalEventId", String.class));

            // Resubmit Info
            ne.setResubmitEventID("6fef2977-6dbc-4acf-81d9-b925e0677069");
            ne.setResubmitParametersField("Transport", "MQSC");
            ne.setResubmitParametersField("QmgrName", "MyQM");
            ne.setResubmitParametersField("QueueName", "MyQueue");

            // Alternate logging directory
            ne.setAlternateLogFilePath(eventOutputDir);

            // Send out the Notification Event
            eventID = em.sendNotificationEvent(ne);
            LOG.info("Misc NotificationEvent, " + eventID + " Sent.");

        } catch (Exception e) {
            LOG.error("Exception while Unit Testing Misc send methods: " + e.getMessage());
            if(ignoreErrors) {
                LOG.warn("CEERS Notification IgnoreErrors set to true. Unit testing not aborted.");
            } else {
                eventID = "";
            }
        }
        return eventID;
    }

}


