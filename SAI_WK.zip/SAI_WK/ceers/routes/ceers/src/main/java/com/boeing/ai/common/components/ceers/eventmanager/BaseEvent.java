/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : BaseEvent.java - BaseEvent Class exposed in CEERS API
 *                                 Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.components.ceers.eventmanager;
/*---------------------------------------------------------------------------*/
import com.boeing.ai.common.components.ceers.CeersUtils;
import com.boeing.ai.common.components.ceers.eventmanager.DataSensitivityType;
import com.boeing.ai.common.utilities.ClassInfo;

import java.net.InetAddress;

import java.util.GregorianCalendar;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
/*---------------------------------------------------------------------------*/
public class BaseEvent {
    private String eventID;
    private String globalTransactionID;
    private String eventGroupName;
    private String applicationName;
    private String componentName;
    private XMLGregorianCalendar timeStamp;
    private String serverName;
    private String environmentName;
    private String metadata;
    private String userdata;
    private String messageName;
    private DataSensitivityType dataSensitivity = DataSensitivityType.NONE;
    private boolean ignoreEventErrors;
    private boolean disableLogging;
    private String alternateLogFilePath;

    // Initializer - all events need a name.
    public BaseEvent(String messageName) throws Exception {
        /*String parentClassName = ClassInfo.getCallerCallerClassName();
        this.setEventID("");
        this.setGlobalTransactionID("");
        this.setEventGroupName("NotSpecified");
        this.setApplicationName("");
        this.setComponentName("");
        this.setTimeStamp((GregorianCalendar)GregorianCalendar.getInstance());
        this.setServerName(InetAddress.getLocalHost().getHostName());
        this.setMetaData("");
        this.setUserData("");
        this.setMessageName(messageName);
        this.setDataSensitivity(DataSensitivityType.RESTRICT);
        this.setIgnoreEventErrors(true);
        this.setDisableLogging(false);
        this.setAlternateLogFilePath("");*/
    }

    public String getEventID() throws Exception {
        return this.eventID;
    }
    @XmlElement
    public void setEventID(String value) throws Exception {
        this.eventID= value;
    }

    public String getGlobalTransactionID() throws Exception {
        return this.globalTransactionID;
    }
    @XmlElement
    public void setGlobalTransactionID(String value) throws Exception {
        this.globalTransactionID = value;
    }

    public String getEventGroupName() throws Exception {
        return this.eventGroupName;
    }
    @XmlElement
    public void setEventGroupName(String value) throws Exception {
        this.eventGroupName = value;
    }

    public String getApplicationName() throws Exception {
        return this.applicationName;
    }
    @XmlElement
    public void setApplicationName(String value) throws Exception {
        this.applicationName = value;
    }

    public String getMessageName() throws Exception {
        return this.messageName;
    }
    @XmlElement
    public void setMessageName(String value) throws Exception {
        this.messageName = value;
    }

    public String getComponentName() throws Exception {
        return this.componentName;
    }
    @XmlElement
    public void setComponentName(String value) throws Exception {
        this.componentName = value;
    }

    public XMLGregorianCalendar getTimeStamp() throws Exception {
        return this.timeStamp;
    }
    @XmlElement
    public void setTimeStamp(String value) throws Exception {
        XMLGregorianCalendar xgc=DatatypeFactory.newInstance().newXMLGregorianCalendar(value);
        this.setTimeStamp(xgc);
    }
    public void setTimeStamp(GregorianCalendar value) throws Exception {
        DatatypeFactory dtf = DatatypeFactory.newInstance();
        XMLGregorianCalendar xmlCal = dtf.newXMLGregorianCalendar(value);
        this.timeStamp = xmlCal;
    }
    public void setTimeStamp(XMLGregorianCalendar value) throws Exception {
        this.timeStamp = value;
    }

    public String getServerName() throws Exception {
        return this.serverName;
    }
    @XmlElement
    public void setServerName(String value) throws Exception {
        this.serverName = value;
    }

    public String getEnvironmentName() throws Exception {
        return this.environmentName;
    }
    @XmlElement
    public void setEnvironmentName(String value) throws Exception {
        this.environmentName= value;
    }

    public String getMetaData() throws Exception {
        return this.metadata;
    }
    @XmlElement
    public void setMetaData(String value) throws Exception {
        this.metadata = value;
    }

    public String getMetaDataFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this.metadata,name);
    }
    public void setMetaDataField(String name, String value) throws Exception {
        this.metadata = CeersUtils.setValueInPairString(this.metadata,name,value);
    }

    public String getUserData() throws Exception {
        return this.userdata;
    }
    @XmlElement
    public void setUserData(String value) throws Exception {
        this.userdata = value;
    }

    public String getUserDataFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this.userdata,name);
    }
    public void setUserDataField(String name, String value) throws Exception {
        this.userdata = CeersUtils.setValueInPairString(this.userdata,name,value);
    }

    public DataSensitivityType getDataSensitivity() throws Exception {
        return this.dataSensitivity;
    }
    @XmlElement
    public void setDataSensitivity(String sensitivity) throws Exception {
        if(sensitivity == null) sensitivity = "";
        sensitivity = sensitivity.toUpperCase();
        sensitivity = sensitivity.replace("", "");
        sensitivity = sensitivity.replace("-", "");
        sensitivity = sensitivity.replace(" ", "");
        if (sensitivity.contains("BOEING")) {
            this.setDataSensitivity(DataSensitivityType.BOEING_PROPRIETARY);
        } else if (sensitivity.contains("FAR12")) {
            this.setDataSensitivity(DataSensitivityType.FAR12);
        } else if (sensitivity.contains("EAR")) {
            this.setDataSensitivity(DataSensitivityType.EAR);
        } else if (sensitivity.contains("ITAR")) {
            this.setDataSensitivity(DataSensitivityType.ITAR);
        } else if (sensitivity.contains("NONE")) {
            this.setDataSensitivity(DataSensitivityType.NONE);
        } else if (!sensitivity.equals("RESTRICT")) {
            this.setDataSensitivity(DataSensitivityType.RESTRICT);
        }
    }
    public void setDataSensitivity(DataSensitivityType value) throws Exception {
        this.dataSensitivity = value;
    }

    public boolean getIgnoreEventErrors() throws Exception {
        return this.ignoreEventErrors;
    }
    @XmlElement
    public void setIgnoreEventErrors(boolean value) throws Exception {
        this.ignoreEventErrors = value;
    }

    public boolean getDisableLogging() throws Exception {
        return this.disableLogging;
    }
    @XmlElement
    public void setDisableLogging(boolean value) throws Exception {
        this.disableLogging = value;
    }

    public String getAlternateLogFilePath() throws Exception {
        return this.alternateLogFilePath;
    }
    @XmlElement
    public void setAlternateLogFilePath(String value) throws Exception {
        this.alternateLogFilePath = value;
    }

    public String displayEvent() throws Exception {
        return "BaseEvent {" +
        "EventID='" + getEventID() + '\'' +
        ",  GlobalTransactionID='" + getGlobalTransactionID() + '\'' +
        ",  EventGroupName='" + getEventGroupName() + '\'' +
        ",  ApplicationName='" + getApplicationName() + '\'' +
        ",  MessageName='" + getMessageName() + '\'' +
        ",  ComponentName='" + getComponentName() + '\'' +
        ",  TimeStamp='" + getTimeStamp().toString() + '\'' +
        ",  ServerName='" + getServerName() + '\'' +
        ",  EnvironmentName='" + getEnvironmentName() + '\'' +
        ",  MetaData='" + getMetaData() + '\'' +
        ",  UserData='" + getUserData() + '\'' +
        ",  DataSensitivity='" + getDataSensitivity().toString() + '\'' +
        ",  IgnoreEventErrors='" + getIgnoreEventErrors() + '\'' +
        ",  DisableLogging='" + getDisableLogging() + '\'' +
        ",  AlternateLogFilePath='" + getAlternateLogFilePath() + '\'' +
        "} ";
    }
}




