package com.boeing.ai.sqisvelocity.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class TokenPayloadConstructor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {

		Map<String, String> tokenServicePayloadmap = new HashMap<String, String>();
		// TBD payload values can be taken from config file / DB call
		tokenServicePayloadmap.put("userName", "SQISUSER");
		tokenServicePayloadmap.put("bemsID", "999999997");
		tokenServicePayloadmap.put("clientID", "SQIS");
		tokenServicePayloadmap.put("clientSecret", "sqis1stpwd");

		exchange.getIn().setBody(tokenServicePayloadmap);
		

	}

	

}
