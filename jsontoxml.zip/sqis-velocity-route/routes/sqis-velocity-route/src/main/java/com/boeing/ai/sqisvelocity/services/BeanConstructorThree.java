package com.boeing.ai.sqisvelocity.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;

public class BeanConstructorThree implements Processor{

	
	public Token token;

	public Token getToken() {
		return token;
	}

	public void setToken(Token token) {
		this.token = token;
	}

	@Override
	public void process(Exchange exchange) throws Exception {

		System.out.println(" Printing all values "+token.getId() + token.getName()+token.getToken());

		exchange.getIn().setBody(token);
		

	}

}
