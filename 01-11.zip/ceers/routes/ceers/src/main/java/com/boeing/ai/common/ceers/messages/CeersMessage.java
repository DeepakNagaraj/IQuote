/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : CeersEventManagerImpl.java - EventManager Implementation
 *                                             Converted from .NET API.
 *                                             Parent Class for CEERS Event
 *                                             objects exposed in API to send
 *                                             Events directly via method calls.
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.ceers.messages;
/*---------------------------------------------------------------------------*/

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/*---------------------------------------------------------------------------*/
@XmlRootElement
@XmlAccessorType(XmlAccessType.NONE)
public class CeersMessage {
    
	@XmlElement
	public EventType eventType;
	@XmlElement
	public AuditEvent auditEvent;
	@XmlElement
	public StateEvent stateEvent;
	@XmlElement
	public NotificationEvent notificationEvent;

	public EventType getEventType() throws Exception {
		return this.eventType;
	}

	public void setEventType(EventType value) throws Exception {
		this.eventType = value;
	}

	public AuditEvent getAuditEvent() throws Exception {
		return this.auditEvent;
	}

	public void setAuditEvent(AuditEvent value) throws Exception {
		this.auditEvent = value;
	}

	public StateEvent getStateEvent() throws Exception {
		return this.stateEvent;
	}

	public void setStateEvent(StateEvent value) throws Exception {
		this.stateEvent = value;
	}

	public NotificationEvent getNotificationEvent() throws Exception {
		return this.notificationEvent;
	}

	public void setNotificationEvent(NotificationEvent value) throws Exception {
		this.notificationEvent = value;
	}
}
