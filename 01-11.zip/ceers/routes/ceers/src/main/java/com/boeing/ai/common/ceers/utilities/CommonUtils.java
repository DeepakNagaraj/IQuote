package com.boeing.ai.common.ceers.utilities;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;


public class CommonUtils {

	public static Boolean verifyDirectory(String directory) {
        File verifydir;
        Boolean check = false;
        directory.isEmpty();
        if (StringUtils.isBlank(directory)) {
            check = false;
        } else {
            try {
                verifydir = new File(directory);
                if (!verifydir.exists()) {
                    verifydir.mkdirs();
                    check = true;
                } else if (verifydir.isDirectory()) {
                    check = true;
                } else {
                    check = false;
                }
            } catch (Exception e) {
                check = false;
            }
        }
        return check;
    }	
	
	
	public static String getCallerCallerClassName() {
        StackTraceElement[] stElements = Thread.currentThread().getStackTrace();
        String callerClassName = null;
        for (int i=1; i<stElements.length; i++) {
            StackTraceElement ste = stElements[i];
            if (!ste.getClassName().equals(CommonUtils.class.getName())&& ste.getClassName().indexOf("java.lang.Thread")!=0) {
                if (callerClassName==null) {
                    callerClassName = ste.getClassName();
                } else if (!callerClassName.equals(ste.getClassName())) {
                    return ste.getClassName();
                }
            }
        }
        return null;
    }
	
	public static final String[] Split(String str, char c1) {

        String[] rets = str.split("\\Q" + c1 + "\\E");
        if (str.endsWith(c1+"")) {
            // Add empty string for .Net
            ArrayList<String> ret_al = new ArrayList<String>(Arrays.asList(rets));
            ret_al.add("");
            rets = ret_al.toArray(new String [ret_al.size()]);
        }
        return rets;
    }
	
}
