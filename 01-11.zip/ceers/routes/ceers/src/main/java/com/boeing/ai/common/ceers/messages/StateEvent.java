/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : StateEvent.java - StateEvent Class exposed in CEERS API
 *                                  Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.ceers.messages;
import javax.xml.bind.annotation.XmlElement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.boeing.ai.common.ceers.messages.BaseEvent;
import com.boeing.ai.common.ceers.messages.EventState;
/*---------------------------------------------------------------------------*/
public class StateEvent extends BaseEvent {
    private static final Logger LOG = LoggerFactory.getLogger(Thread.currentThread().getStackTrace()[0].getClassName());

    private EventState transactionState = EventState.Started;
    private String additionalInfo;


    public StateEvent() throws Exception {
        super("NA");
        this.setTransactionState(EventState.Info);
        this.setAdditionalInfo("");
    }

    public StateEvent(String messageName) throws Exception {
        super(messageName);
        this.setTransactionState(EventState.Info);
        this.setAdditionalInfo("");
    }

    public EventState getTransactionState() throws Exception {
        return this.transactionState;
    }
    @XmlElement
    public void setTransactionState(EventState value) throws Exception {
        this.transactionState = value;
    }

    public String getAdditionalInfo() throws Exception {
        return this.additionalInfo;
    }
    @XmlElement
    public void setAdditionalInfo(String value) throws Exception {
        this.additionalInfo = value;
    }

    @Override
    public String displayEvent() throws Exception {
        return super.displayEvent() +
        "- StateEvent{" +
        ", TransactionState='" + getTransactionState().toString() + '\'' +
        ", AdditionalInfo='" + getAdditionalInfo() + '\'' +
        '}';
    }
}




