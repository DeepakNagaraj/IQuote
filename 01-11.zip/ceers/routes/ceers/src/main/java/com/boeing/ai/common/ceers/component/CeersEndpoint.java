/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 12-09-2016
 * Authors      : Alex Kretchetov, David Campbell, Rohan Mars, Tim Schramer
 * File         : CeersEndpoint .java - Represents Ceers endpoint.
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *-----------------------------------------------------------------------------
 * -.-.-/1.0.0  | Alex Kretchetov   | Initial Create.
 *              | David Campbell    |
 *              | Rohan Mars        |
 *              | 12-09-2016        |
 *--------------|-------------------|------------------------------------------
 * 1.0.0/2.0.0  | Tim Schramer      | Major update and additions.
 *              | Rohan Mars        | Added missing CEERS API functionality
 *              | 04-13-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Robust Unit tests. Added legacy .NET
 *              | Rohan Mars        | method calls. Additional functionality
 *              | 04-21-2016        | Restructured code.
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.ceers.component;
/*---------------------------------------------------------------------------*/
import org.apache.camel.Consumer;
import org.apache.camel.impl.DefaultEndpoint;
import org.apache.camel.Processor;
import org.apache.camel.Producer;
import org.apache.camel.spi.UriParam;
/*---------------------------------------------------------------------------*/
public class CeersEndpoint extends DefaultEndpoint {

    public CeersEndpoint() {
    }

    public CeersEndpoint(String uri, CeersComponent component) {
        super(uri, component);
    }

    public CeersEndpoint(String endpointUri) {
        super(endpointUri);
    }

    public Producer createProducer() throws Exception {
        return new CeersProducer(this);
    }

    public Consumer createConsumer(Processor processor) throws Exception {
        throw new UnsupportedOperationException("Ceers consumer pattern not supported: " + getEndpointUri());
    }

    @Override
    protected String createEndpointUri() {
        return eventType != null ? "ceers:" + eventType : "ceers";
    }

// Parameters for all Event Types (audit, state and notification).
    @UriParam
    private String eventType;
    @UriParam
    private String globalTxId;
    @UriParam
    private String eventGroup;
    @UriParam
    private String applicationName;
    @UriParam
    private String messageName;
    @UriParam
    private String serverName;
    @UriParam
    private String environmentName;
    @UriParam
    private String componentName;
    @UriParam
    private String eventTimestamp;
    @UriParam
    private String userdata;
    @UriParam
    private String dataSensitivity;

// Payload Parameters. Types audit and notification only.
    @UriParam
    private String refEventId;
    @UriParam
    private String referenceOriginalPayload;
    @UriParam
    private String originalEventId;
    @UriParam
    private String payloadLogAmount;
    @UriParam
    private String payloadMsgHeader;

// Resubmit Parameters. Types audit and notification only.
    @UriParam
    private String allowResubmit;
    @UriParam
    private String resubmitServiceName;
    @UriParam
    private String resubmitParameters;
    @UriParam
    private String resubmitEventId;

// Audit Event specific Parameters.
    @UriParam
    private String transferType;

// State Event specific Parameters.
    @UriParam
    private String transactionState;
    @UriParam
    private String additionalInfo;

// Notification Event specific Parameters.
    @UriParam
    private String severity;
    @UriParam
    private String shortDescription;
    @UriParam
    private String detailedMessage;

// Parameters to control Event processing.
    @UriParam
    private String disableLogging;
    @UriParam
    private String ignoreEventErrors;
    @UriParam
    private String alternateLogFilePath;
    

    public boolean isSingleton() {
        return true;
    }

    public String getEventType() {
        return eventType;
    }
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getGlobalTxId() {
        return globalTxId;
    }
    public void setGlobalTxId(String globalTxId) {
        this.globalTxId = globalTxId;
    }

    public String getEventGroup() {
        return eventGroup;
    }
    public void setEventGroup(String eventGroup) {
        this.eventGroup = eventGroup;
    }

    public String getApplicationName() {
        return applicationName;
    }
    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getMessageName() {
        return messageName;
    }
    public void setMessageName(String messageName) {
        this.messageName = messageName;
    }

    public String getServerName() {
        return serverName;
    }
    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getEnvironmentName() {
        return environmentName;
    }
    public void setEnvironmentName(String environmentName) {
        this.environmentName = environmentName;
    }

    public String getComponentName() {
        return componentName;
    }
    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    public String getEventTimestamp() {
        return eventTimestamp;
    }
    public void setEventTimestamp(String eventTimestamp) {
        this.eventTimestamp = eventTimestamp;
    }

    public String getUserdata() {
        return userdata;
    }
    public void setUserdata(String userdata) {
        this.userdata = userdata;
    }

    public String getDataSensitivity() {
        return dataSensitivity;
    }
    public void setDataSensitivity(String dataSensitivity) {
        this.dataSensitivity = dataSensitivity;
    }

    public String getRefEventId() {
        return refEventId;
    }
    public void setRefEventId(String refEventId) {
        this.refEventId = refEventId;
    }

    public String getReferenceOriginalPayload() {
        return referenceOriginalPayload;
    }
    public void setReferenceOriginalPayload(String referenceOriginalPayload) {
        this.referenceOriginalPayload = referenceOriginalPayload;
    }

    public String getOriginalEventId() {
        return originalEventId;
    }
    public void setOriginalEventId(String originalEventId) {
        this.originalEventId= originalEventId;
    }

    public String getPayloadLogAmount() {
        return payloadLogAmount;
    }
    public void setPayloadLogAmount(String payloadLogAmount) {
        this.payloadLogAmount = payloadLogAmount;
    }

    public String getPayloadMsgHeader() {
        return payloadMsgHeader;
    }
    public void setPayloadMsgHeader(String payloadMsgHeader) {
        this.payloadMsgHeader = payloadMsgHeader;
    }

    public String getAllowResubmit() {
        return allowResubmit;
    }
    public void setAllowResubmit(String allowResubmit) {
        this.allowResubmit = allowResubmit;
    }

    public String getResubmitServiceName() {
        return resubmitServiceName;
    }
    public void setResubmitServiceName(String resubmitServiceName) {
        this.resubmitServiceName = resubmitServiceName;
    }

    public String getResubmitParameters() {
        return resubmitParameters;
    }
    public void setResubmitParameters(String resubmitParameters) {
        this.resubmitParameters = resubmitParameters;
    }

    public String getResubmitEventId() {
        return resubmitEventId;
    }
    public void setResubmitEventId(String resubmitEventId) {
        this.resubmitEventId= resubmitEventId;
    }

    public String getTransferType() {
        return transferType;
    }
    public void setTransferType(String transferType) {
        this.transferType = transferType;
    }

    public String getTransactionState() {
        return transactionState;
    }
    public void setTransactionState(String transactionState) {
        this.transactionState = transactionState;
    }

    public String getAdditionalInfo() {
        return additionalInfo;
    }
    public void setAdditionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
    }

    public String getSeverity() {
        return severity;
    }
    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getShortDescription() {
        return shortDescription;
    }
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getDetailedMessage() {
        return detailedMessage;
    }
    public void setDetailedMessage(String detailedMessage) {
        this.detailedMessage = detailedMessage;
    }

    public String getDisableLogging() {
        return disableLogging;
    }
    public void setDisableLogging(String disableLogging) {
        this.disableLogging = disableLogging;
    }

    public String getIgnoreEventErrors() {
        return ignoreEventErrors;
    }
    public void setIgnoreEventErrors(String ignoreEventErrors) {
        this.ignoreEventErrors = ignoreEventErrors;
    }

    public String getAlternateLogFilePath() {
        return alternateLogFilePath;
    }
    public void setAlternateLogFilePath(String alternateLogFilePath) {
        this.alternateLogFilePath = alternateLogFilePath;
    }
   
    @Override
    public String toString() {
        return "CeersEndpoint{" +
               "eventType='" + eventType + '\'' +
               ", globalTxId='" + globalTxId + '\'' +
               ", eventGroup='" + eventGroup + '\'' +
               ", applicationName='" + applicationName + '\'' +
               ", messageName='" + messageName + '\'' +
               ", serverName='" + serverName + '\'' +
               ", environmentName='" + environmentName + '\'' +
               ", componentName='" + componentName + '\'' +
               ", eventTimestamp='" + eventTimestamp + '\'' +
               ", userdata='" + userdata + '\'' +
               ", dataSensitivity='" + dataSensitivity + '\'' +
               ", refEventId='" + refEventId + '\'' +
               ", referenceOriginalPayload='" + referenceOriginalPayload + '\'' +
               ", originalEventId='" + originalEventId + '\'' +
               ", payloadLogAmount='" + payloadLogAmount + '\'' +
               ", payloadMsgHeader='" + payloadMsgHeader + '\'' +
               ", allowResubmit='" + allowResubmit + '\'' +
               ", resubmitServiceName='" + resubmitServiceName + '\'' +
               ", resubmitParameters='" + resubmitParameters + '\'' +
               ", resubmitEventId='" + resubmitEventId + '\'' +
               ", transferType='" + transferType+ '\'' +
               ", transactionState='" + transactionState + '\'' +
               ", additionalInfo='" + additionalInfo + '\'' +
               ", severity='" + severity + '\'' +
               ", shortDescription='" + shortDescription + '\'' +
               ", detailedMessage='" + detailedMessage + '\'' +
               ", disableLogging='" + disableLogging + '\'' +
               ", ignoreEventErrors='" + ignoreEventErrors + '\'' +
               ", alternateLogFilePath='" + alternateLogFilePath + '\'' +
               '}';
    }
}


