/*
 * Copyright 2016 (C) The Boeing Company
 *
 * Created On   : 04-21-2016
 * Authors      : Tim Schramer
 * File         : NotificationEvent.java - NotificationEvent Class exposed in CEERS API
 *                                         Converted from .NET API
 *-----------------------------------------------------------------------------
 * Revision History (Release 2.5.5)
 *-----------------------------------------------------------------------------
 * VERSION        AUTHOR              DESCRIPTION OF CHANGE
 * OLD/NEW        DATE                CR NO
 *--------------|-------------------|------------------------------------------
 * 2.0.0/2.5.0  | Tim Schramer      | Added with version 2.5.0
 *              | 04-21-2016        |
 *--------------|-------------------|------------------------------------------
 * 2.5.0/2.5.5  | Tim Schramer      | Restructured to natively support Classes
 *              | 04-28-2016        | ported from .NET.
 *--------------|-------------------|------------------------------------------
 */
/*---------------------------------------------------------------------------*/
package com.boeing.ai.common.ceers.messages;
import com.boeing.ai.common.ceers.messages.BaseEvent;
import com.boeing.ai.common.ceers.messages.EventSeverity;
import com.boeing.ai.common.ceers.messages.PayloadType;
import com.boeing.ai.common.ceers.utilities.CeersUtils;

import javax.xml.bind.annotation.XmlElement;

import org.apache.camel.Exchange;
import org.apache.camel.Message;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class NotificationEvent extends BaseEvent {
    private static final Logger LOG = LoggerFactory.getLogger(Thread.currentThread().getStackTrace()[0].getClassName());

    private EventSeverity severity = EventSeverity.Severe;
    private String shortDescription;
    private String detailedDescription;
    private String resubmitEventID;
    private String resubmitServiceName;
    private String resubmitParameters;
    private String payloadRefEventID;
    private Object payloadMsgBuffer;
    private PayloadType payloadMsgType;
    private String payloadLogAmount;
    private String payloadMsgHeader;
    private String originalEventID;

    // Initializer - invoke base initializer with the name.
    public NotificationEvent() throws Exception {
        super("NA");
        this.setSeverity(EventSeverity.Info);
        this.setShortDescription("");
        this.setDetailedDescription("");
        this.setResubmitEventID("");
        this.setResubmitServiceName("");
        this.setResubmitParameters("");
        this.setPayloadRefEventID("");
        this.setPayloadMsgBuffer(null);  // Also sets payloadMsgType
        this.setPayloadLogAmount("ALL");
        this.setPayloadMsgHeader("");
        this.setOriginalEventID("");
    }

    public NotificationEvent(String messageName) throws Exception {
        super(messageName);
        this.setSeverity(EventSeverity.Info);
        this.setShortDescription("");
        this.setDetailedDescription("");
        this.setResubmitEventID("");
        this.setResubmitServiceName("");
        this.setResubmitParameters("");
        this.setPayloadRefEventID("");
        this.setPayloadMsgBuffer(null);  // Also sets payloadMsgType
        this.setPayloadLogAmount("ALL");
        this.setPayloadMsgHeader("");
        this.setOriginalEventID("");
    }

    public EventSeverity getSeverity() throws Exception {
        return this.severity;
    }
    @XmlElement
    public void setSeverity(EventSeverity value) throws Exception {
        this.severity = value;
    }

    public String getShortDescription() throws Exception {
        return this.shortDescription;
    }
    @XmlElement
    public void setShortDescription(String value) throws Exception {
        this.shortDescription = value;
    }

    public String getDetailedDescription() throws Exception {
        return this.detailedDescription;
    }
    @XmlElement
    public void setDetailedDescription(String value) throws Exception {
        this.detailedDescription = value;
    }

    public String getResubmitEventID() throws Exception {
        return this.resubmitEventID;
    }
    @XmlElement
    public void setResubmitEventID(String value) throws Exception {
        this.resubmitEventID = value;
    }

    public String getResubmitServiceName() throws Exception {
        return this.resubmitServiceName;
    }
    @XmlElement
    public void setResubmitServiceName(String value) throws Exception {
        this.resubmitServiceName = value;
    }

    public String getResubmitParameters() throws Exception {
        return this.resubmitParameters;
    }
    @XmlElement
    public void setResubmitParameters(String value) throws Exception {
        this.resubmitParameters = value;
    }

    public String getResubmitParametersFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this.resubmitParameters,name);
    }
    public void setResubmitParametersField(String name, String value) throws Exception {
        this.resubmitParameters = CeersUtils.setValueInPairString(this.resubmitParameters,name,value);
    }

    public Object getPayloadMsgBuffer() throws Exception {
        return this.payloadMsgBuffer;
    }
    public String getPayloadMsgBufferString() throws Exception {
        if(this.payloadMsgBuffer == null)
            return "";
        return this.payloadMsgBuffer.toString();
    }
    @XmlElement
    public void setPayloadMsgBuffer(Object messageObj) throws Exception {
        if (messageObj instanceof Exchange) {
            Exchange exchange = (Exchange)messageObj;
            messageObj = exchange.getIn();
        }
        if (messageObj instanceof Message) {
            Message message = (Message)messageObj;
            messageObj = message.getBody(String.class);
        }
        if (!(messageObj instanceof String)) {
            messageObj = null;
        }
        this.payloadMsgBuffer = messageObj;
        if (messageObj == null)
            this.setPayloadMsgType(PayloadType.None);
        else
            this.setPayloadMsgType(PayloadType.MessageExchange);
    }
    public void setPayloadMsgBuffer(byte[] message) throws Exception {
        this.payloadMsgBuffer = message;
        if (message == null)
            this.setPayloadMsgType(PayloadType.None);
        else
            this.setPayloadMsgType(PayloadType.ByteArray);
    }

    public String getPayloadRefEventID() throws Exception {
        return this.payloadRefEventID;
    }
    @XmlElement
    public void setPayloadRefEventID(String value) throws Exception {
        this.payloadRefEventID = value;
    }

    public PayloadType getPayloadMsgType() throws Exception {
        return this.payloadMsgType;
    }
    @XmlElement
    public void setPayloadMsgType(PayloadType value) throws Exception {
        this.payloadMsgType = value;
    }

    public String getPayloadLogAmount() throws Exception {
        return this.payloadLogAmount;
    }
    @XmlElement
    public void setPayloadLogAmount(String value) throws Exception {
        this.payloadLogAmount = value;
    }

    public String getPayloadMsgHeader() throws Exception {
        return this.payloadMsgHeader;
    }
    @XmlElement
    public void setPayloadMsgHeader(String value) throws Exception {
        this.payloadMsgHeader = value;
    }

    public String getPayloadMsgHeaderFieldValue(String name) throws Exception {
        return CeersUtils.getValueInPairString(this.payloadMsgHeader,name);
    }
    public void setPayloadMsgHeaderField(String name, String value) throws Exception {
        this.payloadMsgHeader = CeersUtils.setValueInPairString(this.payloadMsgHeader,name,value);
    }

    public String getOriginalEventID() throws Exception {
        return this.originalEventID;
    }
    @XmlElement
    public void setOriginalEventID(String value) throws Exception {
        this.originalEventID= value;
    }

    @Override
    public String displayEvent() throws Exception {
        return super.displayEvent() +
        "- NotificationEvent{" +
        ", Severity='" + getSeverity().toString() + '\'' +
        ", ShortDescription='" + getShortDescription() + '\'' +
        ", DetailedDescription='" + getDetailedDescription() + '\'' +
        ", ResubmitEventID='" + getResubmitEventID() + '\'' +
        ", ResubmitServiceName='" + getResubmitServiceName() + '\'' +
        ", ResubmitParameters='" + getResubmitParameters() + '\'' +
        ", PayloadMsgBuffer='" + getPayloadMsgBufferString() + '\'' +
        ", PayloadRefEventID='" + getPayloadRefEventID() + '\'' +
        ", PayloadMsgType='" + getPayloadMsgType().toString() + '\'' +
        ", PayloadLogAmount='" + getPayloadLogAmount() + '\'' +
        ", PayloadMsgHeader='" + getPayloadMsgHeader() + '\'' +
        ", OriginalEventID='" + getOriginalEventID() + '\'' +
        '}';
    }
}



