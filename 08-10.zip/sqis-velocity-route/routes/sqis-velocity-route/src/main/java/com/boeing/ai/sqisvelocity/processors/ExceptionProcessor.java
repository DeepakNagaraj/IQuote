package com.boeing.ai.sqisvelocity.processors;
/*---------------------------------------------------------------------------*/
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.exception.ExceptionUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/*---------------------------------------------------------------------------*/
public class ExceptionProcessor implements Processor {

    private static final Logger LOG = LoggerFactory.getLogger(ExceptionProcessor.class);

    @Override
    public void process(Exchange exchange) {
        Throwable cause = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Throwable.class);
        String clazz = cause.getClass().getSimpleName();
        // do custom error handling if required based on clazz

        String errorMessage = cause.getMessage();
        // log message and print stack trace
        LOG.error(errorMessage);
        LOG.error(ExceptionUtils.getStackTrace(cause));
    }
}


