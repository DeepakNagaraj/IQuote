package com.boeing.ai.sqisvelocity.services;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.google.gson.Gson;

public class TokenPayloadConstructor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		
		Map<String,String> tokenServicePayloadmap = new HashMap<String,String>();
		//TBD payload values can be taken from config file / DB call
		tokenServicePayloadmap.put("userName", "SQISUSER");
		tokenServicePayloadmap.put("bemsID", "999999997");
		tokenServicePayloadmap.put("clientID", "SQIS");
		tokenServicePayloadmap.put("clientSecret", "sqis1stpwd");
		
		
		Gson gson = new Gson();
        String tokenServicePayload = gson.toJson(tokenServicePayloadmap);

		exchange.getIn().setBody(tokenServicePayload);
		
		exchange.getIn().setHeader("ch-service", "ch-generateToken");
		exchange.getIn().setHeader("ch-timestamp", "2016-10-25T17:21:36.000Z");
		exchange.getIn().setHeader("ch-datasensitivity", "EAR");
		exchange.getIn().setHeader("ch-action", "POST /api/v1/mesusers/authenticate");
		
		

	}

}
