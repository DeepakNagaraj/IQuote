package com.boeing.ai.sqisvelocity.services;

public class Token {

	private String id;
	private String name;
	private String token;
	private String timetoLive;
	private String bemsId;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getTimetoLive() {
		return timetoLive;
	}
	public void setTimetoLive(String timetoLive) {
		this.timetoLive = timetoLive;
	}
	public String getBemsId() {
		return bemsId;
	}
	public void setBemsId(String bemsId) {
		this.bemsId = bemsId;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return id+name+token+bemsId;
	}
	
}
