package com.boeing.ai.sqisvelocity.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;

public class BeanConstructorOne implements Processor {
	
	@Autowired
	public Token token;

	@Override
	public void process(Exchange exchange) throws Exception {

		token.setId("12345");
		token.setName("SQISToken");

		exchange.getIn().setBody(token);
		

	}

	

}
