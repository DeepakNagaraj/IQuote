package com.boeing.ai.sqisvelocity.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;

public class BeanConstructorThree implements Processor{

	@Autowired
	public Token token;

	@Override
	public void process(Exchange exchange) throws Exception {

		System.out.println(" Printint all values "+token.getId() + token.getTimetoLive()+token.getToken());

		exchange.getIn().setBody(token);
		

	}

}
