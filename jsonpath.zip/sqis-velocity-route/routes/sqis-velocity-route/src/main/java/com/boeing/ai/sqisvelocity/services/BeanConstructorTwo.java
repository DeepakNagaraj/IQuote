package com.boeing.ai.sqisvelocity.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.beans.factory.annotation.Autowired;

public class BeanConstructorTwo implements Processor{

	public Token token;

	public Token getToken() {
		return token;
	}

	public void setToken(Token token) {
		this.token = token;
	}

	@Override
	public void process(Exchange exchange) throws Exception {

		token.setBemsId("SQIS2346");
		token.setToken("afsfkj1323213m23224#^@^@#(#JDJd");

		exchange.getIn().setBody(token);
		

	}

}
