package com.boeing.ai.sqisvelocity.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class BeanConstructorOne implements Processor {
	
	
	public Token token;

	public Token getToken() {
		return token;
	}

	public void setToken(Token token) {
		this.token = token;
	}

	@Override
	public void process(Exchange exchange) throws Exception {

		token.setId("12345");
		token.setName("SQISToken");

		exchange.getIn().setBody(token);
		

	}

	

}
