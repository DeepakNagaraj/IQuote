package com.boeing.ai.sqisvelocity.services;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class TokenPayloadConstructor implements Processor {

	@Override
	public void process(Exchange exchange) throws Exception {
		String json = "[{\"userName\":\"SQISUSER\",\"bemsID\":\"SQISUER\",\"clientID\":\"SQIS\",\"clientSecret\":\"Password@123\"}]";
		JsonArray jArray = new JsonParser().parse(json).getAsJsonArray();
		/*for (int i = 0; i < jArray.size(); i++) {
			JsonObject jsonObject = jArray.get(i).getAsJsonObject();
			System.out.println(jsonObject.get("userName"));
			System.out.println(jsonObject.get("bemsID"));
			System.out.println(jsonObject.get("clientID"));
			System.out.println(jsonObject.get("clientSecret"));
			System.out.println("*********");

		}
		;*/
		exchange.getIn().setBody(jArray, JsonArray.class);

	}

}
