package com.boeing.ai.common.sqisvelocity;

import org.apache.camel.EndpointInject;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.blueprint.CamelBlueprintTestSupport;
import org.junit.Test;

public class SqisRouteTest extends CamelBlueprintTestSupport {

	@EndpointInject(uri = "mock:output")
	protected MockEndpoint outputEndpoint;

	@Test
	public void testCamelRoute() throws Exception {

		outputEndpoint.setExpectedCount(2);

		// Validate our expectations
		assertMockEndpointsSatisfied();
	}

	@Override
	public boolean isUseAdviceWith() {
		return true;
	}

	@Override
	protected void doPostSetup() throws Exception {
		context.getRouteDefinition("SQIS_to_TokenService").adviceWith(context, new AdviceWithRouteBuilder() {
			@Override
			public void configure() throws Exception {

				/*weaveById("sqisqueue").replace().to("vm://localhost");
				weaveById("sqisfile").replace().to(outputEndpoint);*/
			}
		});
		context.start();
	}

	@Override
	protected String getBlueprintDescriptor() {
		return "/OSGI-INF/blueprint/blueprintTokenService.xml";
	}

}
