package com.boeing.ai.sqisvelocity.services;

import javax.xml.bind.annotation.XmlElement;

public class Data {
	private String token;

	private String expiry;

	public String getToken() {
		return token;
	}
    
	@XmlElement
	public void setToken(String token) {
		this.token = token;
	}

	public String getExpiry() {
		return expiry;
	}
    
	@XmlElement
	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}

	@Override
	public String toString() {
		return "ClassPojo [token = " + token + ", expiry = " + expiry + "]";
	}
}
