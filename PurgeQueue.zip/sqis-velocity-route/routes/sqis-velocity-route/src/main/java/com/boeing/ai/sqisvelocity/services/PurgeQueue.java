package com.boeing.ai.sqisvelocity.services;

import java.util.HashMap;
import java.util.Map;

import javax.management.MBeanServerConnection;
import javax.management.MBeanServerInvocationHandler;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;

import org.apache.activemq.broker.jmx.QueueViewMBean;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

public class PurgeQueue implements Processor {

	
	@Override
	public void process(Exchange exchange) throws Exception {
		JMXServiceURL url = new JMXServiceURL("service:jmx:rmi://0.0.0.0:44444/jndi/rmi://0.0.0.0:1099/karaf-root");

		Map env = new HashMap<>();
		String[] creds = { "admin", "admin" };
		env.put(JMXConnector.CREDENTIALS, creds);

		JMXConnector jmxc = JMXConnectorFactory.connect(url, env);
		MBeanServerConnection conn = jmxc.getMBeanServerConnection();
		ObjectName name = new ObjectName(
				"org.apache.activemq:type=Broker,brokerName=amq,destinationType=Queue,destinationName=testQueue");
		/*
		 * BrokerViewMBean mbean = (BrokerViewMBean)
		 * MBeanServerInvocationHandler.newProxyInstance(conn, name,
		 * BrokerViewMBean.class, true);
		 */
		QueueViewMBean queueMbean = (QueueViewMBean) MBeanServerInvocationHandler.newProxyInstance(conn, name,
				QueueViewMBean.class, true);
		queueMbean.purge();
		// System.out.println("Statistics for broker " + mbean.getBrokerId() + "
		// - " + mbean.getBrokerName());
		System.out.println("***  testQueue Purged Successfully   ***");

	}

}
