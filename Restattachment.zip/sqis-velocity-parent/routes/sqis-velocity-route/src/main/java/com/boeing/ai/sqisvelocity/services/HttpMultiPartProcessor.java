package com.boeing.ai.sqisvelocity.services;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.camel.CamelExchangeException;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.Processor;
import org.apache.camel.component.file.GenericFile;
import org.apache.camel.component.http4.HttpConstants;
import org.apache.camel.component.http4.helper.HttpHelper;
import org.apache.camel.util.ExchangeHelper;
import org.apache.camel.util.IOHelper;
import org.apache.http.HttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.entity.FileEntity;
import org.apache.http.entity.InputStreamEntity;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.InputStreamBody;
import org.apache.http.entity.mime.content.StringBody;

public class HttpMultiPartProcessor implements Processor {
	private HttpEntity createRequestEntity(Exchange exchange) throws CamelExchangeException {
		HttpEntity answer = exchange.getIn().getBody(HttpEntity.class);
		try {
			Message in = exchange.getIn();
			Object data = exchange.getIn().getBody();

			if (data != null) {
				String contentType = ExchangeHelper.getContentType(exchange);

				if (contentType != null && HttpConstants.CONTENT_TYPE_JAVA_SERIALIZED_OBJECT.equals(contentType)) {
					// serialized java object
					Serializable obj = in.getMandatoryBody(Serializable.class);
					// write object to output stream
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					HttpHelper.writeObjectToStream(bos, obj);
					ByteArrayEntity entity = new ByteArrayEntity(bos.toByteArray());
					entity.setContentType(HttpConstants.CONTENT_TYPE_JAVA_SERIALIZED_OBJECT);
					IOHelper.close(bos);
					answer = entity;
				} else if (data instanceof File || data instanceof GenericFile) {
					// file based (could potentially also be a FTP file etc)
					File file = in.getBody(File.class);
					if (file != null) {
						answer = new FileEntity(file, contentType);
					}
				} else if (data instanceof String) {
					// be a bit careful with String as any type can most likely
					// be converted to String
					// so we only do an instanceof check and accept String if
					// the body is really a String
					// do not fallback to use the default charset as it can
					// influence the request
					// (for example application/x-www-form-urlencoded forms
					// being sent)
					String charset = IOHelper.getCharsetName(exchange, false);
					StringEntity entity = new StringEntity((String) data, charset);
					entity.setContentType(contentType);
					answer = entity;
				}

				// fallback as input stream
				if (answer == null) {
					// force the body as an input stream since this is the
					// fallback
					InputStream is = in.getMandatoryBody(InputStream.class);
					InputStreamEntity entity = new InputStreamEntity(is, -1);
					entity.setContentType(contentType);
					answer = entity;
				}
			}
		} catch (UnsupportedEncodingException e) {
			throw new CamelExchangeException("Error creating RequestEntity from message body", exchange, e);
		} catch (IOException e) {
			throw new CamelExchangeException("Error serializing message body", exchange, e);
		}
		return answer;
	}

	@Override
	public void process(Exchange exchange) throws Exception {
		HttpEntity entity;
		if (exchange.getIn().hasAttachments()) {
			String contentType = ExchangeHelper.getContentType(exchange);
			Object data = exchange.getIn().getBody();
			ContentBody content = null;
			List<TempFile> files = new ArrayList<TempFile>();
			for (String filename : exchange.getIn().getAttachments().keySet()) {
				TempFile tempFile = new TempFile(exchange.getIn().getAttachment(filename).getInputStream(), filename);
				files.add(tempFile);
			}

			if (contentType != null && HttpConstants.CONTENT_TYPE_JAVA_SERIALIZED_OBJECT.equals(contentType)) {
				Serializable obj = exchange.getIn().getMandatoryBody(Serializable.class);
				// write object to output stream
				ByteArrayOutputStream bos = new ByteArrayOutputStream();
				HttpHelper.writeObjectToStream(bos, obj);

				IOHelper.close(bos);
				content = new ByteArrayBody(bos.toByteArray(), null);

			} else if (data instanceof File || data instanceof GenericFile) {
				// file based (could potentially also be a FTP file etc)
				File f = exchange.getIn().getBody(File.class);
				if (f != null) {
					content = new FileBody(f);
				}
			} else if (data instanceof String) {
				content = new StringBody((String) data);
			}
			if (content == null) {
				// force the body as an input stream since this is the fallback
				InputStream is = exchange.getIn().getMandatoryBody(InputStream.class);
				content = new InputStreamBody(is, "");
			}

			MultipartEntity multipartEntity = new MultipartEntity();
			if (content != null) {
				multipartEntity.addPart("content", content);
			}
			for (TempFile file : files) {
				FileBody body = new FileBody(file.getTempFile());
				body.getFilename();
				multipartEntity.addPart("file",
						new FileBody(file.getTempFile(), file.getOriginalFilename(), "application/octet-stream", null));
			}
			entity = multipartEntity;
		} else {
			entity = createRequestEntity(exchange);
		}

		exchange.getOut().copyFrom(exchange.getIn());
		exchange.getOut().setBody(entity);
	}

}
