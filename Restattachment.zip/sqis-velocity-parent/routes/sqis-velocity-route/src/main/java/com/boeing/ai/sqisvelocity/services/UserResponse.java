package com.boeing.ai.sqisvelocity.services;

import java.util.Map;

public class UserResponse {

	private Map<String, String> data;
/*	private String token;
	private String expiry;
*/	private String message;
	private String status;
	public Map getData() {
		return data;
	}
	public void setData(Map data) {
		this.data = data;
	}
/*	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getExpiry() {
		return expiry;
	}
	public void setExpiry(String expiry) {
		this.expiry = expiry;
	}
*/	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

/*	 @Override
	 public String toString() {
	  StringBuilder builder = new StringBuilder();
	  builder.append("UserResponse [data=");
	  builder.append(data);
	  builder.append(", token=");
	  builder.append(token);
	  builder.append(", expiry=");
	  builder.append(expiry);
	  builder.append(", message=");
	  builder.append(message);
	  builder.append(", status=");
	  builder.append(status);
	  builder.append("]");
	  return builder.toString();
	 }	
*/
	
	public String getUserToken(){
		System.out.println("Inside getUserToken" );

		if(data==null)
			return "no token";
		else if(data.isEmpty()){
			return data.get("token");
		}
		else
			return "no token";
	}
	
	 @Override
	 public String toString() {
	  StringBuilder builder = new StringBuilder();
	  builder.append("UserResponse [data=");
	  builder.append(data);
	  builder.append(", message=");
	  builder.append(message);
	  builder.append(", status=");
	  builder.append(status);
	  builder.append("]");
	  return builder.toString();
	 }
}
